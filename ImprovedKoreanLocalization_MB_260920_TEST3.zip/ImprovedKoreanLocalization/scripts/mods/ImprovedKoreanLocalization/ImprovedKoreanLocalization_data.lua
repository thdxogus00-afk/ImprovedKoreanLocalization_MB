local mod = get_mod("ImprovedKoreanLocalization")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
	options = {
        widgets = {
		    {
    			setting_id    = "translation_mode",
    			type          = "dropdown",
    			default_value = "default",
    			options = {
    			{text = "settings_default", value = "default"},
    			{text = "settings_custom",  value = "custom"},
    		    },
			    tooltip = "translation_mode_tooltip"
            }
	    }
	}
}