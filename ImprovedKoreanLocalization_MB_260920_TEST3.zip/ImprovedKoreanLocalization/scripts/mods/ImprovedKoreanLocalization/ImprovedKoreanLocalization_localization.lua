return {
    mod_name = {
        en = "Improved Korean Localization",
		ko = "한국어 현지화 개선",
    },
    mod_description = {
        en = "This mod fixes Korean language that needs to be fixed due to incorrect localization.",
		ko = "잘못된 현지화로 인해 수정이 필요한 한국어를 개선하는 모드입니다.",
    },
	translation_mode = {
        en = "Translation Style",
		ko = "번역 스타일",
    },
	translation_mode_tooltip = {
        en = "Select a translation style.(Require Restart)",
		ko = "번역 스타일을 선택합니다.(재시작 필요)",
    },
	settings_default = {
        en = "Transliteration",
		ko = "음차 번역",
    },
	settings_custom = {
        en = "Semantic Translation",
		ko = "완전 번역",
    },
}
