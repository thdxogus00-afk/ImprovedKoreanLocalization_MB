return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`` encountered an error loading the Darktide Mod Framework.")

		new_mod("ImprovedKoreanLocalization", {
			mod_script       = "ImprovedKoreanLocalization/scripts/mods/ImprovedKoreanLocalization/ImprovedKoreanLocalization",
			mod_data         = "ImprovedKoreanLocalization/scripts/mods/ImprovedKoreanLocalization/ImprovedKoreanLocalization_data",
			mod_localization = "ImprovedKoreanLocalization/scripts/mods/ImprovedKoreanLocalization/ImprovedKoreanLocalization_localization",
		})
	end,
	packages = {},
}
