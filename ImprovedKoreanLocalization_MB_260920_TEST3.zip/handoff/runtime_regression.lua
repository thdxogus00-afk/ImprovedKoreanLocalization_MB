-- Engine-facing dependencies are stubs; WTL and string interpolation are real source.
local assertion_count, output_checks, interpolation_checks = 0, 0, 0
local function check(value, message)
    assertion_count = assertion_count + 1
    assert(value, message)
end
function table.clear(t) for k in pairs(t) do t[k] = nil end end
function table.enum(...) local t = {}; for i,v in ipairs({...}) do t[v]=i end; return t end
function class() return {} end
function callback(fn, ...)
    local initial = table.pack(...)
    return function(...)
        local args = {}
        for i=1,initial.n do args[i] = initial[i] end
        local tail = table.pack(...)
        for i=1,tail.n do args[initial.n+i] = tail[i] end
        return fn(table.unpack(args,1,initial.n+tail.n))
    end
end
local missing_context = 0
Log = {error=function() missing_context = missing_context + 1 end}
local macros = setmetatable({}, {__index=function(_, name)
    return function(param) return '<MACRO:'..name..':'..tostring(param)..'>' end
end})
local manager_class
function require(name)
    if name == 'scripts/managers/localization/localization_macros' then return macros end
    if name == 'scripts/managers/localization/localization_manager' then return manager_class end
    error('Unexpected require: '..name)
end
manager_class = dofile(REF..'/localization_manager.lua')
local translation_mode, ikl_enabled, wtl_enabled = 'default', true, true
local hooks, registered, notices = {}, {}, {}
local ikl = {
    get=function(_, setting) if setting=='translation_mode' then return translation_mode end end,
    is_enabled=function() return ikl_enabled end,
    notify=function(_,text) notices[#notices+1]=text end,
}
local wtl = {
    get=function() return false end,
    is_enabled=function() return wtl_enabled end,
    persistent_table=function() return registered end,
    io_dofile=function() return {} end,
    hook=function(_,_,name,fn) hooks[name]=fn end,
    localize=function(_,key) return key end,
    command=function() end,
}
local dmf = {mods={ImprovedKoreanLocalization=ikl}}
function get_mod(name)
    if name=='ImprovedKoreanLocalization' then return ikl end
    if name=='WhatTheLocalization' then return wtl end
    if name=='DMF' then return dmf end
    error('Unexpected mod: '..name)
end
Managers = {localization={_language='ko',_string_cache={}}}
dofile(REF..'/WhatTheLocalization.lua')
dofile(MAIN)
check(#ikl.localization_templates == EXPECTED_TEMPLATES, 'Template count')
local fixtures = dofile(FIXTURES)
local function identity(_,_,raw) return raw end
local function get_raw(key,raw)
    return hooks._process_string(identity, Managers.localization, key, raw, {})
end
local function get_formatted(key, raw, context)
    return hooks._process_string(manager_class._process_string, Managers.localization, key, raw, context)
end
for _, setting in ipairs({'default','custom'}) do
    translation_mode = setting
    ikl.on_all_mods_loaded()
    for _, lang in ipairs({'ko','en'}) do
        Managers.localization._language = lang
        wtl.reload_templates()
        for _, f in ipairs(fixtures) do
            local raw = lang=='ko' and f[2] or f[3]
            local expected = lang=='en' and raw or (setting=='default' and f[4] or f[5])
            check(get_raw(f[1],raw)==expected, 'Output mismatch: '..setting..'/'..lang..'/'..f[1])
            output_checks = output_checks + 1
            if lang=='ko' and f[6] then
                local formatted, err = get_formatted(f[1],raw,f[7])
                check(err==nil and not formatted:find(':undefined',1,true), 'Interpolation: '..f[1])
                interpolation_checks = interpolation_checks + 1
            end
        end
    end
end
check(missing_context==0,'Missing interpolation context')
Managers.localization._language = 'ko'
wtl.reload_templates()
local push_key = 'loc_talent_cryptic_push_stagger_stamina_desc'
local push = get_formatted(push_key,'raw',{stamina='60%',push_strength='+70%'})
check(push:find('스태미나가 60% 이상',1,true)~=nil,'Stamina condition binding')
check(push:find('충격이 +70%',1,true)~=nil,'Push impact binding')
local spread = get_formatted('loc_talent_cryptic_no_braced_movement_penalty_desc','raw',
    {movement_speed_modifier='-50%',spread='-30%'})
check(spread:find('페널티: -50%',1,true)~=nil,'Signed movement penalty')
check(spread:find('탄 분산: -30%',1,true)~=nil,'Signed spread')
local title = get_formatted('loc_achievement_broker_enemies_hit_by_flash_grenade_name','raw',{})
check(not title:find('undefined',1,true) and not title:find('{tier}',1,true),'No extra tier token')
-- Translation disable/re-enable and WTL disable/re-enable must restore lookup behavior.
ikl_enabled = false
ikl.on_disabled()
for _,f in ipairs(fixtures) do
    check(get_raw(f[1],f[2])==f[2],'Disabled translation: '..f[1])
    output_checks = output_checks + 1
end
ikl_enabled = true
ikl.on_enabled()
for _,f in ipairs(fixtures) do
    check(get_raw(f[1],f[2])==f[5],'Re-enabled translation: '..f[1])
    output_checks = output_checks + 1
end
wtl_enabled = false
wtl.on_disabled()
check(get_raw(push_key,'original')=='original','WTL disable')
wtl_enabled = true
wtl.on_enabled()
check(get_raw(push_key,'original')~='original','WTL re-enable')
-- The inherited mod applies a changed style after restarting; preserve that contract.
translation_mode = 'default'
ikl.on_setting_changed('translation_mode')
check(#notices==1 and notices[1]:find('재시작',1,true)~=nil,'Restart notice')
check(mode=='custom','Style remains unchanged until reinitialization')
ikl.on_all_mods_loaded()
check(mode=='default','Style after reinitialization')
return string.format('{"assertions":%d,"output_checks":%d,"new_translation_interpolation_checks":%d,"fixture_keys":%d,"missing_context_errors":%d}',
    assertion_count,output_checks,interpolation_checks,#fixtures,missing_context)
