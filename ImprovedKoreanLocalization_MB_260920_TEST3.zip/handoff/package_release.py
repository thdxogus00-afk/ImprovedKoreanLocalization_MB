"""Create a deterministic ZIP from this release directory, with per-file hashes."""
import hashlib
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent.parent

def main():
    if len(sys.argv) != 2: raise SystemExit('Usage: python handoff/package_release.py OUTPUT.zip')
    output = Path(sys.argv[1]).resolve()
    if output == ROOT or ROOT in output.parents:
        raise SystemExit('Output ZIP must be outside the release directory')
    files = sorted(p for p in ROOT.rglob('*') if p.is_file()
                   and '__pycache__' not in p.parts and p.name != 'SHA256SUMS.txt'
                   and not p.name.endswith(('.pyc','.zip')))
    # Retain archived TEST2 SHA256SUMS if any; the top-level list covers everything.
    archived_sums = sorted(p for p in ROOT.rglob('SHA256SUMS.txt') if p.parent != ROOT)
    files = sorted(set(files + archived_sums))
    sums = ROOT / 'SHA256SUMS.txt'
    sums.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files), encoding='utf-8')
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files+[sums]):
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), date_time=(2026,9,20,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    print(output)
    print('bytes',output.stat().st_size)
    print('sha256',hashlib.sha256(output.read_bytes()).hexdigest())

if __name__ == '__main__': main()
