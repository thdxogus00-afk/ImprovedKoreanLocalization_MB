"""Rebuild TEST3 from the byte-exact TEST2 baseline and explicit new decisions."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MOD_REL = Path('scripts/mods/ImprovedKoreanLocalization/ImprovedKoreanLocalization.lua')

def lua_string(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\r', '\\r').replace('\n', '\\n').replace('\t', '\\t') + '"'

def render_extension(changes):
    lines = ['', '', '-- MB continuation 260920 TEST3; see handoff/CHANGES_TEST3.json.',
             '-- Original work: Polarmingo / DARKS0UND. Continuation: Songshin; review assistance: Codex.',
             '-- The entire TEST2 file above is preserved byte for byte.', 'do',
             '    local function reviewed_handler(default_text, custom_text)',
             '        return function(locale, value)',
             '            if locale ~= "ko" then return value end',
             '            if mode == "custom" then return custom_text end',
             '            return default_text', '        end', '    end',
             '    local reviewed_entries = {']
    for c in changes:
        lines.append('        {' + ', '.join(lua_string(c[k]) for k in ('key','final_ko_default','final_ko_custom')) + '},')
    lines += ['    }', '    for index, entry in ipairs(reviewed_entries) do',
              '        table.insert(mod.localization_templates, {',
              '            id = "mb_260920_review_" .. index,',
              '            loc_keys = {entry[1]}, locales = {"ko"},',
              '            handle_func = reviewed_handler(entry[2], entry[3]),',
              '        })', '    end', 'end', '']
    return '\r\n'.join(lines).encode('utf-8')

def main():
    manifest = json.loads((HERE / 'MANIFEST.json').read_text())
    changes = json.loads((HERE / 'CHANGES_TEST3.json').read_text())
    baseline = HERE / 'previous_TEST2/ImprovedKoreanLocalization'
    original = (baseline / MOD_REL).read_bytes()
    assert hashlib.sha256(original).hexdigest() == manifest['previous_main_sha256']
    assert len(changes) == len({c['key'] for c in changes})
    output = ROOT / 'ImprovedKoreanLocalization'
    shutil.copytree(baseline, output, dirs_exist_ok=True)
    (output / MOD_REL).write_bytes(original + render_extension(changes))
    print(json.dumps({'rebuilt':str(output / MOD_REL), 'sha256':hashlib.sha256((output / MOD_REL).read_bytes()).hexdigest()}))

if __name__ == '__main__': main()
