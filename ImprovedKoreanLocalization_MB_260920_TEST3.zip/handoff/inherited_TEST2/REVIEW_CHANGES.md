# TEST2 수정 내역

기존 원문·번역 및 두 번역 모드의 수정 결과입니다. 실게임 표시 확인 전 시험판입니다.

## 1. loc_ability_psyker_chain_lightning_description

유형: 기존 수정

**현재 영문**

Unleash a torrent of Bio-Lightning - a fast, channelled attack that Locks to and Stuns an Enemy while dealing Damage. This spreads to nearby Enemies. Charge to increase Spread rate and Damage.

**기존 기본 번역**

적에게 피해를 입히면서, 제자리에 고정시키고 기절시키며, 근처의 적에게 퍼져나가는 생체 번개의 급류를 방출합니다. 충전하면 퍼져나가는 속도와 대미지가 증가합니다.

**수정 기본 번역**

생체 번개의 급류를 방출합니다. 빠르게 대상을 포착해 피해를 주고 기절시키는 지속 시전 공격이며, 근처의 적에게 퍼져 나갑니다. 충전하면 확산 속도와 대미지가 증가합니다.

수정 이유: Locks to를 적을 제자리에 고정하는 별도 효과로 중복 해석하지 않도록 수정

## 2. loc_ability_psyker_smite_description_new

유형: 기존 수정

**현재 영문**

Charge up your Psychic Power and release it to deal high Damage to a Single Enemy.

**기존 기본 번역**

사이킥 능력을 충전했다 해방하여 단일 대상에게 큰 대미지를 입힙니다. 플랙 및 갑각 방어구를 입은 적에게 효과적입니다.

**수정 기본 번역**

사이킥 능력을 충전한 뒤 해방하여 단일 대상에게 큰 대미지를 입힙니다.

수정 이유: 현재 원문에 없는 방어구별 효율 설명 제거

## 3. loc_ability_zealot_stealth_rending_description

유형: 기존 수정

**현재 영문**

Enter Stealth for {duration:%s}s. While in Stealth gain {movement_speed:%s} Movement Speed, {backstab_damage:%s} Backstab Damage, {finesse_damage:%s} Finesse Damage, {crit_chance:%s} Critical Chance & {rending:%s} Melee Rending. Attacking makes you leave Stealth.

Base Cooldown: {cooldown:%s}s

**기존 기본 번역**

{duration:%s}초 동안 은신 상태가 됩니다. 은신 상태일 때 이동 속도가 {movement_speed:%s}, 후방 공격 대미지가 {backstab_damage:%s}, 기교 대미지가 {finesse_damage:%s}, 치명타 확률이 {crit_chance:%s}, 근접 공격의 찢기가 {rending:%s} 증가합니다. 공격을 하면 은신 상태게 해제됩니다.

기본 쿨다운: {cooldown:%s}초

**수정 기본 번역**

{duration:%s}초 동안 은신 상태가 됩니다. 은신 상태일 때 이동 속도가 {movement_speed:%s}, 후방 공격 대미지가 {backstab_damage:%s}, 기교 대미지가 {finesse_damage:%s}, 치명타 확률이 {crit_chance:%s}, 근접 공격의 찢기가 {rending:%s} 증가합니다. 공격을 하면 은신 상태가 해제됩니다.

기본 쿨다운: {cooldown:%s}초

수정 이유: 오타 수정

## 4. loc_achievement_adamant_block_enemies_desc

유형: 기존 수정

**현재 영문**

Block Damage from {amount:%s} unique enemies.

**기존 기본 번역**

유니크 적 250명 대미지 막기

**수정 기본 번역**

서로 다른 적 {amount:%s}명의 공격 대미지 막기

수정 이유: unique를 특수 적으로 오해하지 않도록 수정하고 목표 변수 복원

## 5. loc_achievement_adamant_kill_during_stance_desc

유형: 기존 수정

**현재 영문**

Kill {amount:%s} enemies during {talent_name:%s}.

**기존 기본 번역**

교정자의 자세 도중 적 250명 처치하기

**수정 기본 번역**

{talent_name:%s} 활성화 중 적 {amount:%s}명 처치하기

수정 이유: 능력 이름과 목표 수량 변수 복원

## 6. loc_achievement_adamant_kill_electrocuted_desc

유형: 기존 수정

**현재 영문**

Kill {amount:%s} Electrocuted enemies.

**기존 기본 번역**

감전된 적 500명 처치하기

**수정 기본 번역**

감전된 적 {amount:%s}명 처치하기

수정 이유: 고정 목표값을 현재 원문의 변수로 복원

## 7. loc_achievement_adamant_kill_pounced_enemies_desc

유형: 기존 수정

**현재 영문**

Kill {amount:%s} enemies pounced by your Cyber-Mastiff.

**기존 기본 번역**

사이버 마스티프가 덮친 적 750명 처치하기

**수정 기본 번역**

사이버 마스티프가 덮친 적 {amount:%s}명 처치하기

수정 이유: 고정 목표값을 현재 원문의 변수로 복원

## 8. loc_achievement_adamant_knock_chargers_desc

유형: 기존 수정

**현재 영문**

Have your Cyber-Mastiff Knock Away {amount:%s} Mutants and Poxbursters. Counts once per Enemy.

**기존 기본 번역**

사이버 마스티프로 돌연변이 및 폭스워커 보머 {amount:%s}명 쓰러뜨리기(적당 1회로 합산)

**수정 기본 번역**

사이버 마스티프로 돌연변이 및 폭스버스터 {amount:%s}명 쓰러뜨리기(적당 1회로 합산)

수정 이유: Poxburster 용어 통일

## 9. loc_achievement_adamant_saved_from_dog_desc

유형: 기존 수정

**현재 영문**

Get Rescued from a Pox Hound that has pounced on you, by your Cyber-Mastiff.

**기존 기본 번역**

카오스 하운드에게 덮쳐졌을 때 내 사이버 마스티프로부터 구출 받기

**수정 기본 번역**

폭스 하운드에게 덮쳐졌을 때 내 사이버 마스티프로부터 구출 받기

수정 이유: 현재 원문의 Pox Hound 반영

## 10. loc_achievement_adamant_stagger_elites_with_bash_desc

유형: 기존 수정

**현재 영문**

Stagger {amount:%s} Elite or Specialist Enemies using {talent_name:%s}.

**기존 기본 번역**

{talent_name:%s}로 비틀거리는 엘리트 또는 스페셜리스트 적 {amount:%s}명 처치하기

**수정 기본 번역**

{talent_name:%s}로 엘리트나 스페셜리스트 {amount:%s}명 비틀거리게 하기

수정 이유: 처치가 아닌 비틀거림 조건 반영

## 11. loc_achievement_adamant_time_allies_buffed_by_buff_drone_description

유형: 기존 수정

**현재 영문**

Buff allies using the Nuncio Aquila for a total duration of {target} seconds.

**기존 기본 번역**

눈시오 아퀼라를 사용하여 {target}초 동안 아군에게 버프 주기

**수정 기본 번역**

눈시오 아퀼라로 아군에게 총 {target}초 동안 강화 효과 부여하기

수정 이유: 누적 시간 조건 명시

## 12. loc_achievement_adamant_time_enemies_electrocuted_by_shockmine_description

유형: 기존 수정

**현재 영문**

Stun enemies using the Voltaic Shock Mine for a total duration of {target} seconds.

**기존 기본 번역**

전기 충격 지뢰를 사용하여 {target}초 동안 적 기절시키기

**수정 기본 번역**

전기 충격 지뢰로 적을 총 {target}초 동안 기절시키기

수정 이유: 누적 시간 조건 명시

## 13. loc_achievement_coherency_toughness_description

유형: 기존 수정

**현재 영문**

Replenish {target} Toughness from Coherency.

**기존 기본 번역**

단결로 강인함을 {target}만큼 소생시키기

**수정 기본 번역**

단결로 강인함을 {target}만큼 회복하기

수정 이유: 강인함 회복 용어 수정

## 14. loc_achievement_expeditions_complete_opportunities_total_description

유형: 추가 ID 덮어쓰기

**현재 영문**

Complete {target} Sites of Interest.

**기존 기본 번역**

{target}곳의 주요 지점을 완료하십시오.

**수정 기본 번역**

주요 지점 {target}곳 완료하기

수정 이유: 기존 모드의 고행 목표 문체에 맞춤

## 15. loc_achievement_expeditions_spend_in_shop_description

유형: 추가 ID 덮어쓰기

**현재 영문**

Exchange {target} Salvage for items in Deadsider Sanctuaries.

**기존 기본 번역**

데드사이드 거주민 안식처에서 {target}개의 폐품을 아이템으로 교환하십시오.

**수정 기본 번역**

데드사이드 거주민 안식처에서 폐품 {target}개를 아이템으로 교환하기

수정 이유: 기존 모드의 고행 목표 문체에 맞춤

## 16. loc_achievement_horde_complete_all_maps_description

유형: 기존 수정

**현재 영문**

Complete Mortis Trials in {target:%s} Theatres of Mortification.

**기존 기본 번역**

모든 고행의 극장에서 몰티스 시련 완료하기

**수정 기본 번역**

고행의 극장 {target:%s}곳에서 몰티스 시련 완료하기

수정 이유: 모든 맵으로 고정한 문구를 현재 목표 변수로 복원

## 17. loc_achievement_mission_auric_flawless_description

유형: 기존 수정

**현재 영문**

As a team complete an Auric mission without anyone getting downed.

**기존 기본 번역**

아무도 쓰러지지 않고 저주 위협에서 금빛 수준 임무 완료하기

**수정 기본 번역**

아무도 쓰러지지 않고 금빛 수준 임무 완료하기

수정 이유: 현재 원문에 없는 난이도 조건 제거

## 18. loc_achievement_mission_auric_flawless_maelstrom_x_description

유형: 기존 수정

**현재 영문**

Complete an Auric Maelstrom mission without anyone getting downed.

**기존 기본 번역**

아무도 쓰러지지 않고 저주 위협에서 금빛 수준 마엘스트롬 임무 완료하기

**수정 기본 번역**

아무도 쓰러지지 않고 금빛 수준 마엘스트롬 임무 완료하기

수정 이유: 현재 원문에 없는 난이도 조건 제거

## 19. loc_achievement_mission_auric_x_name

유형: 기존 수정

**현재 영문**

Auric Level Operative {tier}

**기존 기본 번역**

금빛 수준 요원

**수정 기본 번역**

금빛 수준 요원 {tier}

수정 이유: 고행 이름의 단계 변수 복원

## 20. loc_achievement_mission_twins_killed_no_mines_triggered_description

유형: 기존 수정

**현재 영문**

Complete the Orthus Offensive final battle without triggering more than {amount} mines.

**기존 기본 번역**

오르투스 공략 최종 전투에서 지뢰를 {amount}회 이상 발동하지 않고 완료하기

**수정 기본 번역**

오르투스 공략 최종 전투에서 지뢰 발동 횟수를 {amount}회 이하로 유지하며 완료하기

수정 이유: 허용 상한의 경계 조건 수정

## 21. loc_achievement_ogryn_2_killed_corruptor_with_grenade_impact_description

유형: 기존 수정

**현재 영문**

Kill a Corruptor by hitting it in the eye with your grenade box.

**기존 기본 번역**

수류탄으로 눈을 맞춰 타락의 근원 처치하기

**수정 기본 번역**

수류탄 상자로 타락의 근원의 눈을 맞혀 처치하기

수정 이유: 일반 수류탄이 아닌 수류탄 상자 조건 복원

## 22. loc_achievement_ogryn_feel_no_pain_kills_at_max_description

유형: 기존 수정

**현재 영문**

Kill {target} enemies while at {amount} stacks or higher of Feel No Pain.

**기존 기본 번역**

무통 중첩이 {amount}회인 상태로 적 {target}명을 처치하기

**수정 기본 번역**

무통 중첩이 {amount}회 이상인 상태로 적 {target}명을 처치하기

수정 이유: 이상 조건 누락 복원

## 23. loc_achievement_ogryn_kills_during_barrage_threshold_description

유형: 기존 수정

**현재 영문**

Kill {amount} enemies, {target} times, during a single activation of Point-Blank Barrage.

**기존 기본 번역**

조준 사격이 1회 활성화된 동안 적 {target}명 처치를 50번 반복하기

**수정 기본 번역**

조준 사격을 한 번 활성화한 동안 적 {amount}명 처치하기를 {target}번 달성하기

수정 이유: 처치 수와 반복 횟수 변수를 올바른 위치로 복원; 하드코딩 50 제거

## 24. loc_achievement_ogryn_team_toughness_restored_aura_description

유형: 기존 수정

**현재 영문**

Restore a total of {target} Toughness to you or allies in coherency with Stay Close.

**기존 기본 번역**

자신 또는 가까이 붙어있는 단결 상태의 아군의 강인함을 {target}만큼 회복하기

**수정 기본 번역**

곁에 머물러라 효과로 자신 또는 단결 상태의 아군의 강인함을 총 {target} 회복하기

수정 이유: Stay Close라는 오라 이름을 단순 거리 조건으로 옮긴 오류 수정

## 25. loc_achievement_pox_hounds_pushed_description

유형: 기존 수정

**현재 영문**

Push {target} Pox Hounds in midair.
[Counts only once per Pox Hound]

**기존 기본 번역**

폭스 하운드를 {target}번 밀쳐내기(폭스 하운드당 1번만 인정)

**수정 기본 번역**

공중에 있는 폭스 하운드 {target}마리 밀쳐내기(폭스 하운드당 한 번만 인정)

수정 이유: 공중에 있는 대상이라는 조건 복원

## 26. loc_achievement_psyker_2_kill_boss_solo_with_smite_description

유형: 기존 수정

**현재 영문**

While on Heresy threat or higher kill a Monstrosity after damaging {target} of its health with your Brain Burst.

**기존 기본 번역**

배교 위협 이상의 임무에서 뇌 폭발만으로 흉물에게 {target}% 이상 대미지를 준 뒤 처치하기

**수정 기본 번역**

배교 이상의 위협에서 뇌 폭발로 흉물 체력의 {target}만큼 대미지를 준 뒤 해당 흉물 처치하기

수정 이유: 원문에 없는 이상 조건과 추가 백분율 기호 제거

## 27. loc_achievement_psyker_kills_during_overcharge_stance_description

유형: 기존 수정

**현재 영문**

Kill {target} enemies under the effects of a single Scrier's Gaze activation.

**기존 기본 번역**

예지자의 시선 효과가 발동된 적 {target}명을 처치하기

**수정 기본 번역**

예지자의 시선을 한 번 활성화한 동안 적 {target}명 처치하기

수정 이유: 1회 활성화 조건 복원 및 효과 적용 대상 수정

## 28. loc_achievement_subcategory_twins_mission_label

유형: 기존 수정

**현재 영문**

Special Assignments

**기존 기본 번역**

오르투스 공략

**수정 기본 번역**

특별 임무

수정 이유: 특별 임무 전체 분류를 특정 임무 이름으로 옮긴 오류 수정

## 29. loc_achievement_team_win_without_ally_downed_longer_then_x_description

유형: 기존 수정

**현재 영문**

As a team complete a mission on Heresy Threat or higher without being downed more than {downed_times} times.

**기존 기본 번역**

팀으로 배교 이상 위협에서 {downed_times}번 이상 다운되지 않고 임무 완료하기

**수정 기본 번역**

팀 전체가 쓰러진 횟수를 {downed_times}회 이하로 유지하며 배교 이상의 위협에서 임무 완료하기

수정 이유: 허용 상한의 경계 조건 수정

## 30. loc_achievement_total_blessings_unlocked_description

유형: 기존 수정

**현재 영문**

Unlock a Total of {amount} Unique Blessings.

**기존 기본 번역**

유니크 축복 {amount}개 잠금 해제하기

**수정 기본 번역**

서로 다른 축복 총 {amount}개 잠금 해제하기

수정 이유: unique를 고유 등급으로 오해하지 않도록 표현

## 31. loc_achievement_total_mastery_description

유형: 기존 수정

**현재 영문**

Reach a Total Mastery Level of {level}.

**기존 기본 번역**

마스터리 레벨 {level} 도달하기

**수정 기본 번역**

마스터리 레벨 합계 {level} 달성하기

수정 이유: 여러 무기 마스터리의 합계 조건 복원

## 32. loc_achievement_veteran_2_easy_2_description

유형: 기존 수정

**현재 영문**

Replenish {target} total ammunition to allies using Scavenger.

**기존 기본 번역**

청소부 오라를 사용하여 아군에게 탄약을 총 {target}번 보충하기

**수정 기본 번역**

청소부 오라로 아군에게 총 {target}의 탄약 보급하기

수정 이유: 보급 횟수가 아닌 탄약 총량 조건 반영

## 33. loc_achievement_veteran_2_hard_2_description

유형: 기존 수정

**현재 영문**

On Heresy Threat or higher, keep Volley Fire active for over {time} seconds {target} times.

**기존 기본 번역**

배교 이상의 위협에서 일제사격을 {time}초 이상 유지를 {target}번 수행하기

**수정 기본 번역**

배교 이상의 위협에서 일제사격을 {time}초 넘게 유지하기를 {target}번 달성하기

수정 이유: over 경계 조건과 문장 구조 수정

## 34. loc_achievement_veteran_2_medium_1_description

유형: 기존 수정

**현재 영문**

On Malice Threat or higher, kill {target} enemies that have been marked by Executioner's Stance.

**기존 기본 번역**

악의 이상의 위협에서 일제사격으로 표시된 적을 {target}명을 처치하기

**수정 기본 번역**

악의 이상의 위협에서 집행자의 자세로 강조 표시된 적 {target}명 처치하기

수정 이유: 현재 원문의 Executioner's Stance 반영

## 35. loc_achievement_veteran_2_medium_2_description

유형: 기존 수정

**현재 영문**

On Malice Threat or higher, kill {target} ranged enemies that are over {distance} meters away.

**기존 기본 번역**

악의 이상의 위협에서 {distance}미터 이상 떨어진 곳에 있는 적 {target}명을 처치하기

**수정 기본 번역**

악의 이상의 위협에서 {distance}미터보다 멀리 있는 원거리 적 {target}명 처치하기

수정 이유: 원거리 적이라는 목표 유형과 거리 초과 조건 복원

## 36. loc_achievement_veteran_2_no_missed_shots_empty_ammo_description

유형: 기존 수정

**현재 영문**

Complete a Mission on Heresy Threat or higher with no Ammo remaining, and {accuracy} accuracy.

**기존 기본 번역**

배교 위협 이상의 임무에서 탄약이 하나도 안 남은 상태와 {accuracy}% 명중률로 임무 완료하기

**수정 기본 번역**

배교 이상의 위협에서 탄약이 남지 않은 상태로 명중률 {accuracy}를 달성하며 임무 완료하기

수정 이유: 현재 원문에 없는 백분율 기호의 중복 가능성 제거

## 37. loc_achievement_veteran_2_unbounced_grenade_kills_description

유형: 기존 수정

**현재 영문**

Hit {target} enemies with a Frag Grenade without it bouncing.

**기존 기본 번역**

파편 수류탄으로 튕기지 않고 적 {target}명을 처치하기

**수정 기본 번역**

파편 수류탄이 튕기기 전에 적 {target}명에게 명중시키기

수정 이유: 처치가 아닌 명중 조건 반영

## 38. loc_achievement_veteran_kills_with_improved_tag_description

유형: 기존 수정

**현재 영문**

Kill {target} enemies tagged by Focus Target!

**기존 기본 번역**

대상 주시로 적 {target}명을 태그하기

**수정 기본 번역**

대상 주시로 표시된 적 {target}명 처치하기

수정 이유: 태그가 아닌 처치 조건 복원

## 39. loc_achievement_veteran_team_damage_amplified_description

유형: 기존 수정

**현재 영문**

Kill {target} enemies while affected by Fire Team. Kills made by any affected team member also count.

**기존 기본 번역**

스트라이크 팀의 영향을 받은 적 {target}명을 처치하기(영향을 받은 팀원들의 처치 수도 합산)

**수정 기본 번역**

화력 팀 효과를 받는 동안 적 {target}명 처치하기(해당 효과를 받는 팀원의 처치도 포함)

수정 이유: Fire Team 오라를 스트라이크 팀 및 적에게 걸리는 효과로 옮긴 오류 수정

## 40. loc_achievement_zealot_2_hard_1_description

유형: 기존 수정

**현재 영문**

On Heresy Threat or higher, kill {target} Elite or Specialist enemies with Powered Melee Attacks (Chain or Power weapons).

**기존 기본 번역**

배교 이상의 위협에서 체인 또는 파워 무기를 사용해 강력한 근접 공격으로 엘리트 또는 스페셜리스트 적 {target}명을 처치하기

**수정 기본 번역**

배교 이상의 위협에서 체인 또는 파워 무기의 동력 활성화 근접 공격으로 엘리트나 스페셜리스트 {target}명 처치하기

수정 이유: Powered를 일반 강공격으로 오해하지 않도록 수정

## 41. loc_achievement_zealot_2_healed_up_after_resisting_death_description

유형: 기존 수정

**현재 영문**

On Heresy threat or higher, heal to {target} Health with life gained solely from the Holy Revenant Talent.

**기존 기본 번역**

배교 위협 이상의 임무에서 신성한 레버넌트 재능만으로 {target}% 체력까지 회복하기

**수정 기본 번역**

배교 이상의 위협에서 신성한 레버넌트 재능으로 얻은 회복만으로 체력 {target}까지 회복하기

수정 이유: 현재 원문의 서식화된 목표값 보존

## 42. loc_achievement_zealot_2_health_on_last_segment_enough_during_mission_description

유형: 기존 수정

**현재 영문**

Complete a full mission on Heresy Threat or higher in under {time_window} minutes, with less than a Wound's worth of Health remaining for {health}% of the time.

**기존 기본 번역**

배교 위협 이상의 미션에서 남은 체력의 {health}%만큼 부상을 가진 상태로 임무를 {time_window}분 안에 완료하기

**수정 기본 번역**

배교 이상의 위협에서 임무를 {time_window}분 미만으로 완료하되, 임무 시간의 {health}% 동안 남은 체력을 부상 한 칸 분량 미만으로 유지하기

수정 이유: 임무 시간 비율과 남은 체력 조건을 뒤섞은 오류 수정

## 43. loc_achievement_zealot_aura_backstab_kills_while_alone_description

유형: 기존 수정

**현재 영문**

Kill {target} Ranged enemies with backstab, while not in Coherency while under the effect of the Loner ability.

**기존 기본 번역**

단결 상태가 아닐 때 백스탭으로 원거리 적 {target}명을 처치하기

**수정 기본 번역**

외톨이 능력의 효과를 받으며 아군과 단결하지 않은 상태에서, 후방 공격으로 원거리 적 {target}명 처치하기

수정 이유: Loner 능력 조건 누락 복원

## 44. loc_achievement_zealot_kills_with_fire_grenade_description

유형: 기존 수정

**현재 영문**

Burn {target} enemies using the Immolation Grenade.

**기존 기본 번역**

희생 수류탄으로 적 {target}명을 처치하기

**수정 기본 번역**

희생 수류탄으로 적 {target}명 불태우기

수정 이유: Burn을 처치로 옮긴 오류 수정

## 45. loc_achievement_zone_mission_destructibles_description

유형: 기존 수정

**현재 영문**

Destroy {target} Heretical Idols within {zone_name}.

**기존 기본 번역**

{zone_name}에서 이교도 우상 파괴하기

**수정 기본 번역**

{zone_name}에서 이교도 우상 {target}개 파괴하기

수정 이유: 목표 수량 누락 복원

## 46. loc_action_interaction_inactive_pocketable_equipped

유형: 기존 수정

**현재 영문**

Already equipped

**기존 기본 번역**

이미 가지고 있습니다.

**수정 기본 번역**

이미 장착 중입니다.

수정 이유: 보유 여부가 아니라 장착 상태 표시

## 47. loc_adamant_female_c__surrounded_response_01

유형: 기존 수정

**현재 영문**

Not one step back!

**기존 기본 번역**

사방에 찌꺼기들이군! [웃음]

**수정 기본 번역**

한 발짝도 물러서지 마라!

수정 이유: 현재 원문과 다른 대사 수정

## 48. loc_adamant_lowerbody_c_var_01

유형: 기존 수정

**현재 영문**

Arbitrator Officer Fatigues (Lucis)

**기존 기본 번역**

아비트레이터 베테랑 의상(루시스)

**수정 기본 번역**

아비트레이터 장교 의상(루시스)

수정 이유: Officer와 Veteran 구분

## 49. loc_adamant_lowerbody_c_var_02

유형: 기존 수정

**현재 영문**

Arbitrator Officer Fatigues (Noctis)

**기존 기본 번역**

아비트레이터 베테랑 의상(녹티스)

**수정 기본 번역**

아비트레이터 장교 의상(녹티스)

수정 이유: Officer와 Veteran 구분

## 50. loc_adamant_male_c__surrounded_response_01

유형: 기존 수정

**현재 영문**

Not one step back!

**기존 기본 번역**

사방에 찌꺼기들이군! [웃음]

**수정 기본 번역**

한 발짝도 물러서지 마라!

수정 이유: 현재 원문과 다른 대사 수정

## 51. loc_autogun_p2_cs001

유형: 기존 수정

**현재 영문**

Braced Autogun (Crucis Nightshade Camo)

**기존 기본 번역**

브레이스드 오토건(크루시스 나이트셰이드 위장)

**수정 기본 번역**

브레이스드 오토건(크루시스 나이트셰이드 위장)

**기존 / 수정 커스텀 번역**

버팀목 오토건(크루시스 나이트셰이드 위장)

→ 견착식 오토건(크루시스 나이트셰이드 위장)

수정 이유: Braced의 무기 견착 의미 반영

## 52. loc_autogun_p2_cs002

유형: 기존 수정

**현재 영문**

Braced Autogun (Fire Wastes Camo)

**기존 기본 번역**

브레이스드 오토건(화염 황무지 위장)

**수정 기본 번역**

브레이스드 오토건(화염 황무지 위장)

**기존 / 수정 커스텀 번역**

버팀목 오토건(화염 황무지 위장)

→ 견착식 오토건(화염 황무지 위장)

수정 이유: Braced의 무기 견착 의미 반영

## 53. loc_barber_a__mission_raid_den_entrance_c_03

유형: 기존 수정

**현재 영문**

You wouldn't expect me to incriminate myself like that, now would you?

**기존 기본 번역**

설마 저도 그런 불법 행위를 저질렀을 거라고 생각하시는 건 아니죠?

**수정 기본 번역**

제가 그렇게 제 죄를 스스로 털어놓을 거라고 기대하시는 건 아니겠죠?

수정 이유: incriminate myself의 뜻 복원

## 54. loc_boon_vendor_a__concourse_exchange_20_b_01

유형: 기존 수정

**현재 영문**

Or any tactics at all, perhaps?

**기존 기본 번역**

아니면 아무 전략도 안 쓰는 건 어떤가요?

**수정 기본 번역**

아니면 무슨 전술이든 좀 써보시는 건 어떤가요?

수정 이유: any tactics의 제안을 무전술 제안으로 뒤집은 오류 수정

## 55. loc_boon_vendor_a__hub_intro_penance_b_01

유형: 기존 수정

**현재 영문**

It is my solemn duty to stand in witness to your deeds and to record the penances you undertake. 

**기존 기본 번역**

저는 그대들의 임무를 관찰하고 그대들의 참회를 지켜보는 신성한 임무를 명받았습니다.

**수정 기본 번역**

그대들의 행적을 지켜보고 수행하는 고행을 기록하는 것이 저의 엄숙한 의무입니다.

수정 이유: 기록 임무의 누락 복원

## 56. loc_boon_vendor_a__mission_habs_redux_market_a_02

유형: 기존 수정

**현재 영문**

Blessed Emperor, receive the souls of the righteous dead with favour.

**기존 기본 번역**

자비로우신 황제 폐하시여, 정의로운 죽음을 따뜻하게 맞아주소서.

**수정 기본 번역**

자비로우신 황제 폐하시여, 의롭게 죽은 이들의 영혼을 따뜻하게 맞아주소서.

수정 이유: 죽은 이들의 영혼이라는 목적어 복원

## 57. loc_boon_vendor_a__mission_habs_redux_start_zone_d_03

유형: 기존 수정

**현재 영문**

I am Interrogator Rannick's protege. He bid me attend.

**기존 기본 번역**

저는 심문관 라닉 님의 후임입니다. 대신 가달라고 하셨지요.

**수정 기본 번역**

저는 심문관 라닉 님의 제자입니다. 그분의 지시로 참석했지요.

수정 이유: protege를 후임으로 옮긴 오류 수정

## 58. loc_boon_vendor_a__mission_resurgence_brief_c_03

유형: 기존 수정

**현재 영문**

My authority flows from Interrogator Rannick and the Emperor. Together you and I shall strike a blow for Atoma.

**기존 기본 번역**

제 권위는 심문관 라닉 님과 황제 폐하께서 주셨습니다. 저희 모두 힘을 합쳐 아토마에 일격을 날려봅시다.

**수정 기본 번역**

제 권위는 심문관 라닉 님과 황제 폐하께서 주셨습니다. 우리 모두 힘을 합쳐 아토마를 위해 일격을 가합시다.

수정 이유: 아토마를 위한 공격을 아토마에 대한 공격으로 옮긴 오류 수정

## 59. loc_boon_vendor_a__mission_resurgence_statue_riga_consora_a_02

유형: 기존 수정

**현재 영문**

Without Riga Consora, the Galatine Rift campaign would have ended in disaster.

**기존 기본 번역**

리가 콘소라가 사라지면서 갈라틴 균열 작전은 파멸로 끝났지요.

**수정 기본 번역**

리가 콘소라가 없었다면 갈라틴 균열 작전은 재앙으로 끝났을 겁니다.

수정 이유: 가정문을 실제 역사적 사건으로 옮긴 오류 수정

## 60. loc_breed_display_name_renegade_radio_operator

유형: 추가 ID 덮어쓰기

**현재 영문**

Scab Radio Operator

**기존 기본 번역**

Scab Radio Operator

**수정 기본 번역**

스캡 통신병

수정 이유: 한국어 덤프에도 영어로 남아 있는 병종명 번역

## 61. loc_chaos_armored_infected_breed_name

유형: 추가 ID 덮어쓰기

**현재 영문**

Armoured Groaner

**기존 기본 번역**

무장 그로너

**수정 기본 번역**

장갑 그로너

수정 이유: Armoured와 Armed를 구분

## 62. loc_circumstance_darkness_more_resistance_description

유형: 기존 수정

**현재 영문**

We've noted high Enemy concentration in the Mission Zone. Don't expect to see them coming.

**기존 기본 번역**

임무 지역에 적이 밀집해 있다고 합니다. 그럴 줄은 예상하지 못했는데요.

**수정 기본 번역**

임무 구역에 적이 밀집해 있습니다. 적들이 다가오는 모습을 미리 볼 수 있으리라 기대하지 마세요.

수정 이유: 시야 경고를 예상하지 못한 적 밀집으로 옮긴 오류 수정

## 63. loc_circumstance_plasma_smugglers_darkness_description

유형: 기존 수정

**현재 영문**

Reports indicate heavily armed plasma squads in the mission area. Visibility reduced.

**기존 기본 번역**

보고에 의하면 임무 지역에 중장갑 플라즈마 부대가 출몰한다고 합니다. 시야 범위가 감소합니다.

**수정 기본 번역**

보고에 의하면 임무 지역에 중무장 플라즈마 부대가 출몰한다고 합니다. 시야 범위가 감소합니다.

수정 이유: heavily armed를 방어구로 옮긴 오류 수정

## 64. loc_commissar_a__mission_train_first_interstitial_03_a_01

유형: 기존 수정

**현재 영문**

You appear to be cutting this fine. I do not care for it.

**기존 기본 번역**

이 정도는 괜찮아 보이는군. 난 상관없다.

**수정 기본 번역**

시간을 아주 아슬아슬하게 맞추려는군. 마음에 들지 않아.

수정 이유: cutting it fine와 do not care for it을 정반대로 옮긴 오류 수정

## 65. loc_contract_vendor_a__concourse_exchange_01_b_01

유형: 기존 수정

**현재 영문**

And what, pray, is the point of giving them airs?

**기존 기본 번역**

이 녀석들에게 바람을 쐬게 해주는 게 무슨 의미지?

**수정 기본 번역**

그런데 이 녀석들을 우쭐하게 만들어서 대체 무슨 소용이지?

수정 이유: give airs를 바람 쐬기로 옮긴 오류 수정

## 66. loc_contract_vendor_a__contract_vendor_distance_dislikes_character_08

유형: 기존 수정

**현재 영문**

Don't dawdle! Report to me for a suitable contract at once!

**기존 기본 번역**

꾸물거리지 말고, 당장 적절한 계약을 보고하도록!

**수정 기본 번역**

꾸물거리지 말고 와! 네게 맞는 계약을 받으러 당장 내게 보고하도록!

수정 이유: 계약을 배정받으러 오는 지시를 계약 보고로 옮긴 오류 수정

## 67. loc_contract_vendor_a__mission_rise_banter_one_b_04

유형: 기존 수정

**현재 영문**

In my day we had a lot more respect for our elders. And when we didn't, we at least put effort into our insults.

**기존 기본 번역**

내가 젊었을 때에는 모든 어르신들을 존중했었지. 존중하지 않는다 해도, 면전에 대놓고 욕을 하지는 않았어.

**수정 기본 번역**

내 젊을 때는 어른들을 훨씬 더 존중했지. 그렇지 않을 때에도 적어도 모욕할 말은 성의 있게 골랐다고.

수정 이유: insults에 공을 들였다는 농담 복원

## 68. loc_contract_vendor_a__mission_rise_demolisher_melk_02_a_01

유형: 기존 수정

**현재 영문**

I don't suppose anyone has time to note the serial number of that Leman Russ? Everything must be accounted for.

**기존 기본 번역**

리만 러스에 적힌 일련번호는 아무도 확인해보지 않았겠지? 모든 책임을 물어야겠군.

**수정 기본 번역**

저 리만 러스의 일련번호를 적어둘 시간 있는 사람은 없겠지? 모든 물자는 빠짐없이 기록해야 하니까.

수정 이유: 물자 기록 의무를 책임 추궁으로 옮긴 오류 수정

## 69. loc_contract_vendor_a__mission_rise_start_b_03

유형: 기존 수정

**현재 영문**

I cannot believe it! Treachery aboard Grendyl's chosen vessel!

**기존 기본 번역**

믿을 수가 없군! 그렌딜 님께서 직접 선택하신 배에서 월권 행위라니!

**수정 기본 번역**

믿을 수가 없군! 그렌딜 님께서 직접 선택하신 배에서 배신 행위라니!

수정 이유: treachery의 뜻 복원

## 70. loc_contract_vendor_a__mission_rise_start_d_03

유형: 기존 수정

**현재 영문**

You can defy me, but what about Grendyl?

**기존 기본 번역**

나는 무시할 수 있을지 몰라도, 과연 그레딜 님은 어떨까?

**수정 기본 번역**

나는 무시할 수 있을지 몰라도, 과연 그렌딜 님은 어떨까?

수정 이유: 인명 오타 수정

## 71. loc_contract_vendor_a__mission_rise_start_d_04

유형: 기존 수정

**현재 영문**

Your defiance will melt once Grendyl learns of this!

**기존 기본 번역**

그렌딜 님이 너의 월권 행위를 알면 즉시 널 녹여버리실걸!

**수정 기본 번역**

그렌딜 님께서 이 일을 아시면 네 반항심도 눈 녹듯 사라질 거다!

수정 이유: 반항심이 사라진다는 비유를 실제 처형 방법으로 옮긴 오류 수정

## 72. loc_corruption_tutorial_desc

유형: 기존 수정

**현재 영문**

{#color(130,66,170)}Corruption{#reset()} reduces {#color(216,237,190)}Maximum Health{#reset()}. If you are downed when your last Wound is {#color(130,66,170)}Corrupted{#reset()}, you are incapacitated and captured.

{#color(130,66,170)}Corruption{#reset()} is caused by certain attacks, items or being downed.

**기존 기본 번역**

{#color(130,66,170)}부패{#reset()}는 {#color(216,237,190)}최대 체력{#reset()}을 낮춥니다. 부상이 {#color(130,66,170)}부패{#reset()}한 상태에서 쓰러지면 활동 불능이 되며 적에게 사로잡힙니다.

{#color(130,66,170)}부패{#reset()}는 특정 공격이나 아이템, 쓰러지면 발생합니다.

**수정 기본 번역**

{#color(130,66,170)}부패{#reset()}는 {#color(216,237,190)}최대 체력{#reset()}을 낮춥니다. 마지막 부상 칸까지 {#color(130,66,170)}부패{#reset()}한 상태에서 쓰러지면 활동 불능이 되며 적에게 사로잡힙니다.

{#color(130,66,170)}부패{#reset()}는 특정 공격이나 아이템, 쓰러지면 발생합니다.

수정 이유: 마지막 부상 칸 조건 누락 복원

## 73. loc_enemy_wolfer_adjutant_a__mission_armoury_side_streets_01_b_02

유형: 기존 수정

**현재 영문**

Vox array's showing failures, sir. Search teams can't coordinate.

**기존 기본 번역**

복스 배열에 오류가 발생했습니다. 탐색 팀에서 위치를 잡을 수 없습니다.

**수정 기본 번역**

복스 배열에 고장이 발생했습니다. 수색팀이 공조하지 못하고 있습니다.

수정 이유: 수색팀의 협력 불가를 위치 확인 불가로 옮긴 오류 수정

## 74. loc_enginseer_a__info_servo_skull_deployed_01

유형: 기존 수정

**현재 영문**

Servo-skull operating within ... acceptable parameters.

**기존 기본 번역**

안에 있는 서보 스컬에서... 적절한 수치가 탐지됩니다.

**수정 기본 번역**

서보 스컬이... 허용 가능한 범위 안에서 작동하고 있습니다.

수정 이유: within parameters를 내부 위치로 옮긴 오류 수정

## 75. loc_enginseer_a__mission_habs_redux_market_approach_a_01

유형: 기존 수정

**현재 영문**

[Shudder of Pain] Unhappy machine spirits sing their loss all about you.

**기존 기본 번역**

[고통에 몸을 떤다] 불행한 기계령들께서 당신에 대한 상실의 노래를 하고 있습니다.

**수정 기본 번역**

[고통에 몸을 떤다] 불행한 기계령들이 당신들 주위에서 상실을 노래합니다.

수정 이유: all about you의 공간 의미 수정

## 76. loc_enginseer_a__mission_habs_redux_market_approach_a_03

유형: 기존 수정

**현재 영문**

Unfunction rules this desolate quarter. Barbarism of the first order.

**기존 기본 번역**

이 황량한 곳을 지배하는 건 상실된 기능뿐입니다. 제1규칙이 미개함이 되어버렸습니다.

**수정 기본 번역**

이 황량한 구역은 기능 상실이 지배합니다. 극도의 야만입니다.

수정 이유: of the first order를 제1규칙으로 옮긴 오류 수정

## 77. loc_enginseer_a__mission_habs_redux_market_c_01

유형: 기존 수정

**현재 영문**

Apologies, shipmistress. I fear great age has made me forgetful ... and also made me forgetful it has.

**기존 기본 번역**

죄송합니다, 선장님. 연세 때문에 기억력이 좋지 않으신 거 같습니다. 기억력이 많이... 저하되셨습니다.

**수정 기본 번역**

죄송합니다, 선장님. 나이가 많아지니 제가 깜빡하는군요... 게다가 깜빡하기도 하고 말입니다.

수정 이유: 화자의 노쇠와 반복 농담을 상대의 기억력 비난으로 옮긴 오류 수정

## 78. loc_enginseer_a__mission_raid_closer_c_01

유형: 기존 수정

**현재 영문**

The fusion grid screams at the abuses of tech-scuttle minds and heretic hands. It is in agony.

**기존 기본 번역**

퓨전 그리드가 기술만능주의자들과 이교도들의 손에 비명을 지르고 있습니다. 고통스러워 합니다.

**수정 기본 번역**

퓨전 그리드가 기술을 파괴하는 자들과 이교도들의 손에 학대받아 비명을 지릅니다. 고통받고 있습니다.

수정 이유: 파괴자를 기술만능주의자로 옮긴 오류 수정

## 79. loc_enginseer_a__mission_raid_production_genesis_chamber_a_02

유형: 기존 수정

**현재 영문**

Data-haul implies a genesis chamber is close. Reduce it to unfunction, and with haste.

**기존 기본 번역**

데이터 수집 결과 제네시스 챔버는 닫혀 있는 듯 합니다. 기능을 못하게 만드십시오. 서둘러야 합니다.

**수정 기본 번역**

수집한 데이터에 따르면 제네시스 챔버가 근처에 있습니다. 서둘러 기능을 정지시키십시오.

수정 이유: close의 거리 의미를 닫힌 상태로 옮긴 오류 수정

## 80. loc_enginseer_a__mission_raid_production_habs_b_03

유형: 기존 수정

**현재 영문**

A child's render of a blessed manufactorum, flawed and a-failing.

**기존 기본 번역**

축복받은 매뉴팩토룸을 어린애가 완전히 망가뜨려놨군요.

**수정 기본 번역**

축복받은 매뉴팩토룸을 어린애가 흉내 낸 꼴이군요. 결함투성이에, 무너져가고 있습니다.

수정 이유: child's render를 아이에 의한 파괴로 옮긴 오류 수정

## 81. loc_enginseer_a__mission_raid_streets_a_01

유형: 기존 수정

**현재 영문**

Strike Team? Proceed hastily. Refine your course by divination of auspex shadow and electro-whispers, shall I.

**기존 기본 번역**

스트라이크 팀? 서둘러 이동하십시오. 아우스펙스의 그림자와 전자적 속삭임에 귀를 기울이십시오.

**수정 기본 번역**

스트라이크 팀? 서둘러 이동하십시오. 제가 아우스펙스의 그림자와 전자적 속삭임을 읽어 경로를 조정하겠습니다.

수정 이유: 경로를 해석하는 주체 복원

## 82. loc_enginseer_a__mission_train_briefing_c_01

유형: 기존 수정

**현재 영문**

First to suffer will be the soldiers of the Moebian 53rd. Taken the Terminus as a staging ground have they. Act now, must we.

**기존 기본 번역**

가장 먼저 뫼비안 53연대의 병사들에게 고통을 주십시오. 터미누스를 자신들의 무대로 삼은 자들입니다. 즉시 시행하십시오.

**수정 기본 번역**

가장 먼저 피해를 입을 자들은 뫼비안 53연대의 병사들입니다. 그들은 터미누스를 집결지로 쓰고 있습니다. 즉시 행동해야 합니다.

수정 이유: 피해를 입을 아군을 공격하라는 명령으로 옮긴 오류 수정

## 83. loc_enginseer_a__mission_train_briefing_c_02

유형: 기존 수정

**현재 영문**

Intend the blow to fall against the Moebian 53rd, do they. Prevent this [growl] importunism must you.

**기존 기본 번역**

뫼비안 53연대를 쓰러뜨릴 일격을 선사하십시오. 이 [으르렁] 방해꾼들을 제거해야 합니다.

**수정 기본 번역**

놈들은 뫼비안 53연대를 노리고 있습니다. 이 [으르렁] 횡포를 막아야 합니다.

수정 이유: 적의 공격 계획을 아군 공격 지시로 옮긴 오류 수정

## 84. loc_enginseer_a__mission_train_briefing_c_03

유형: 기존 수정

**현재 영문**

The Moebian 53rd are their primary target. Salvation must be your intent. Omnissiah guide you, little pre-servitors.

**기존 기본 번역**

뫼비안 53연대가 당신의 첫 목표입니다. 당신이 구원해줘야 합니다. 옴니시아께서 인도하시기를, 예비 서비터 여러분.

**수정 기본 번역**

놈들의 주된 목표는 뫼비안 53연대입니다. 당신들은 그들을 구해야 합니다. 옴니시아께서 인도하시기를, 예비 서비터 여러분.

수정 이유: their를 your로 옮겨 공격 대상의 주체가 바뀐 오류 수정

## 85. loc_enginseer_a__mission_train_first_interstitial_03_b_01

유형: 기존 수정

**현재 영문**

Time is relative. Success is inevitable.

**기존 기본 번역**

시간이 중요합니다. 성공은 가장 중요합니다.

**수정 기본 번역**

시간은 상대적입니다. 성공은 필연적입니다.

수정 이유: relative와 inevitable의 뜻 복원

## 86. loc_enginseer_a__mission_train_outro_success_b_02

유형: 기존 수정

**현재 영문**

Spare a thought for the spirit of Transit Mover RX-590. Freed at last.

**기존 기본 번역**

끝내 해방된 수송 장치 RTX-590을 위해 잠시 묵념하겠습니다.

**수정 기본 번역**

끝내 해방된 수송 장치 RX-590을 위해 잠시 묵념하겠습니다.

수정 이유: 현재 원문의 열차 식별번호 철자 수정

## 87. loc_enginseer_a__mission_train_outro_success_b_03

유형: 기존 수정

**현재 영문**

Alas that Transit Mover RX-590 could not be saved.

**기존 기본 번역**

안타깝게도 RTX-590은 구원 받지 못했습니다.

**수정 기본 번역**

안타깝게도 RX-590은 구원 받지 못했습니다.

수정 이유: 현재 원문의 열차 식별번호 철자 수정

## 88. loc_enginseer_a__mission_train_second_interstitial_01_d_01

유형: 기존 수정

**현재 영문**

Which is not to say that there are not complications.

**기존 기본 번역**

그렇다고 일이 더 복잡해지는 건 아닙니다.

**수정 기본 번역**

그렇다고 문제가 없다는 뜻은 아닙니다.

수정 이유: 이중 부정으로 문제가 있다는 의미 복원

## 89. loc_enginseer_a__mission_train_second_interstitial_03_b_01

유형: 기존 수정

**현재 영문**

Would you care for status to be conveyed in binharic or gothic?

**기존 기본 번역**

보고서는 이진법으로 드릴까요, 고딕체로 드릴까요?

**수정 기본 번역**

현황을 바이너릭으로 전해드릴까요, 고딕어로 전해드릴까요?

수정 이유: 사용 언어를 글꼴로 옮긴 오류 수정

## 90. loc_enginseer_a__southwark_hub_conversation_06_b_01

유형: 기존 수정

**현재 영문**

Ahhhhh ... Troublesome systems are these, given to flights of fancy and superiority. Soothe them I shall with proper ritual.

**기존 기본 번역**

아... 고급스러운 비행선들에 비해 참으로 골치 아픈 시스템입니다. 제가 이들을 달래기 위한 제대로 된 의식을 준비하겠습니다.

**수정 기본 번역**

아... 공상과 우월감에 빠지기 쉬운 골칫덩이 시스템들이군요. 올바른 의식으로 제가 달래보겠습니다.

수정 이유: flights of fancy를 고급 비행선으로 옮긴 오류 수정

## 91. loc_eor_stay_in_party_vote_text

유형: 기존 수정

**현재 영문**

Merge Strike Teams?

**기존 기본 번역**

이 스트라이크 팀으로 계속하시겠습니까?

**수정 기본 번역**

스트라이크 팀을 합치시겠습니까?

수정 이유: Merge의 팀 합류 의미 명시

## 92. loc_explicator_a__event_demolition_first_corruptor_destroyed_b_03

유형: 기존 수정

**현재 영문**

You need to kill all of them to make this work!

**기존 기본 번역**

어디 볼까... 그래! 자라난 악마의 물질이 하나 남았어!

**수정 기본 번역**

이걸 작동시키려면 전부 없애야 해!

수정 이유: 현재 원문과 다른 대사 수정

## 93. loc_explicator_a__hub_idle_2nd_phase_conversation_seventeen_a_01

유형: 기존 수정

**현재 영문**

Commodore? I've a few special issue items I need sourcing.

**기존 기본 번역**

준장? 조달해야 하는 특별한 문제가 있는 항목이 몇 가지 있어.

**수정 기본 번역**

준장? 구해야 할 특별 지급품이 몇 가지 있어.

수정 이유: special issue를 특별한 문제로 옮긴 오류 수정

## 94. loc_explicator_a__hub_idle_2nd_phase_conversation_twenty_b_01

유형: 기존 수정

**현재 영문**

Tell me about it. But unless you can bend Rannick's ear, nothing's going to change.

**기존 기본 번역**

말해 봐. 하지만 라닉 님의 마음을 돌릴 수 없다면, 아무것도 변하지 않을 거다.

**수정 기본 번역**

내 말이. 하지만 라닉 님이 귀를 기울이게 하지 못하면 아무것도 달라지지 않아.

수정 이유: Tell me about it의 동감 관용 표현 복원

## 95. loc_explicator_a__hub_intro_gun_shop_b_01

유형: 기존 수정

**현재 영문**

I've cleared you for access to the Armoury Exchange. From there, you can requisition reconditioned weaponry recovered from the field. 

**기존 기본 번역**

무기 거래소 이용을 승인했다. 그곳에서 현장에서 확보한 무기를 수리할 수 있을 거야.

**수정 기본 번역**

무기 거래소 이용을 승인했다. 그곳에서 전장에서 회수해 정비한 무기를 지급받을 수 있을 거야.

수정 이유: 무기 지급을 수리 기능으로 옮긴 오류 수정

## 96. loc_explicator_a__mission_archives_deep_archives_b_01

유형: 기존 수정

**현재 영문**

All right, this is the Deep Archives. Keep your discipline and head downwards.

**기존 기본 번역**

좋아, 여기가 딥 아카이브다. 정신 똑바로 차리고 시선은 아래만 보도록.

**수정 기본 번역**

좋아, 여기가 딥 아카이브다. 규율을 지키며 아래로 이동해.

수정 이유: head downwards를 시선 방향으로 옮긴 오류 수정

## 97. loc_explicator_a__mission_archives_deep_archives_b_03

유형: 기존 수정

**현재 영문**

You're at the Deep Archives, and not before time. Keep descending.

**기존 기본 번역**

딥 아카이브에 오긴 했는데, 시간이 많진 않아. 계속 내려가.

**수정 기본 번역**

딥 아카이브에 이제야 도착했군. 계속 내려가.

수정 이유: not before time을 시간 부족으로 옮긴 오류 수정

## 98. loc_explicator_a__mission_archives_end_event_complete_04

유형: 기존 수정

**현재 영문**

You're done there. You've given us plenty to work with. Time to extract.

**기존 기본 번역**

할 일은 끝났다. 작업할 거리를 많이 챙겨왔군. 정보를 가져올 시간이야.

**수정 기본 번역**

거기서 할 일은 끝났어. 쓸 만한 자료를 충분히 확보했다. 탈출할 시간이야.

수정 이유: extract의 철수 의미 복원

## 99. loc_explicator_a__mission_armoury_briefing_c_01

유형: 기존 수정

**현재 영문**

The Moebians are running stimms out of the district, the handover being in the old amphitheatre. This is a possible contagion vector for the Blight, so we want samples to analyse.

**기존 기본 번역**

뫼비안 녀석들이 이곳에 있는 원형 경기장에서 자극제를 나눠주고 있어. 그게 역병의 시초일지 몰라. 그 샘플을 회수해서 분석해야 해.

**수정 기본 번역**

뫼비안 녀석들이 이곳에 있는 원형 경기장에서 자극제를 나눠주고 있어. 그게 역병의 전파 경로일지 몰라. 그 샘플을 회수해서 분석해야 해.

수정 이유: contagion vector를 최초 발생원으로 단정한 번역 수정

## 100. loc_explicator_a__mission_armoury_briefing_c_02

유형: 기존 수정

**현재 영문**

The Moebian stimm trade seems to be a contagion vector for the Blight, so you're to raid the amphitheatre and get us some samples for study.

**기존 기본 번역**

뫼비안이 거래하는 자극제가 역병의 시초일지 몰라. 원형 경기장으로 가서 분석할 샘플을 확보해오도록.

**수정 기본 번역**

뫼비안이 거래하는 자극제가 역병의 전파 경로일지 몰라. 원형 경기장으로 가서 분석할 샘플을 확보해오도록.

수정 이유: contagion vector를 최초 발생원으로 단정한 번역 수정

## 101. loc_explicator_a__mission_cartel_elevator_conversation_one_line_two_03

유형: 기존 수정

**현재 영문**

Don't waste your time thinking about the cartel. Atoma's a better place for their fall.

**기존 기본 번역**

카르텔 생각하느라 시간 낭비하지 마. 아토마는 놈들의 몰락을 위한 더 나은 곳이지.

**수정 기본 번역**

카르텔 생각으로 시간 낭비하지 마. 놈들이 몰락한 덕에 아토마가 더 나아졌으니까.

수정 이유: 몰락의 결과와 목적을 뒤섞은 오류 수정

## 102. loc_explicator_a__mission_complex_brief_a_01

유형: 기존 수정

**현재 영문**

Your mission is to access the comms-plex dish atop Archivum Sycorax and relay an encrypted report.

**기존 기본 번역**

네 임무는 아르키붐 사이코랙스 꼭대기에 있는 통신 시설 안테나에 접근해서 암호화된 보고서를 전달하는 거야.

**수정 기본 번역**

네 임무는 아르키붐 시코락스 꼭대기에 있는 통신 시설 안테나에 접근해서 암호화된 보고서를 전달하는 거야.

수정 이유: 동일 장소의 고유명사 통일

## 103. loc_explicator_a__mission_complex_brief_a_03

유형: 기존 수정

**현재 영문**

It's a simple enough mission: proceed to Archivum Sycorax and use the comms-plex dish to transmit an encrypted report.

**기존 기본 번역**

간단한 임무야. 아르키붐 사이코랙스로 가서 통신 시설 안테나를 사용해 암호화된 보고서를 전송하는 거지.

**수정 기본 번역**

간단한 임무야. 아르키붐 시코락스로 가서 통신 시설 안테나를 사용해 암호화된 보고서를 전송하는 거지.

수정 이유: 동일 장소의 고유명사 통일

## 104. loc_explicator_a__mission_complex_brief_a_04

유형: 기존 수정

**현재 영문**

Your mission is to relay an encrypted report using the Archivum Sycorax comms-plex dish.

**기존 기본 번역**

네 임무는 아르키붐 사이코랙스의 통신 시설 안테나를 써서 암호화된 보고서를 전달하는 거야.

**수정 기본 번역**

네 임무는 아르키붐 시코락스의 통신 시설 안테나를 써서 암호화된 보고서를 전달하는 거야.

수정 이유: 동일 장소의 고유명사 통일

## 105. loc_explicator_a__mission_complex_transmitter_02

유형: 기존 수정

**현재 영문**

This is a job for your data-interrogators. Break through the traitors' conditioning and align the dish.

**기존 기본 번역**

너희의 데이터 탐색 장치가 활약해야 하는 일이야. 배신자들의 훈련을 돌파해서 안테나를 연동시켜.

**수정 기본 번역**

데이터 탐색 장치가 나설 차례야. 배신자들의 설정을 뚫고 안테나의 방향을 맞춰.

수정 이유: 시스템 설정과 안테나 정렬의 의미 수정

## 106. loc_explicator_a__mission_enforcer_end_event_conversation_one_b_04

유형: 기존 수정

**현재 영문**

Enforcers never made much difference down here. Not when it was needed.

**기존 기본 번역**

경비원이 있어도 여기는 달라지지 않았어. 경비원이 필요했던 순간조차 말이야.

**수정 기본 번역**

인포서이 있어도 여기는 달라지지 않았어. 인포서이 필요했던 순간조차 말이야.

수정 이유: enforcers 명칭 통일

## 107. loc_explicator_a__mission_forge_first_objective_04

유형: 기존 수정

**현재 영문**

Find the supply elevator, and be quick about it. You're bound to draw attention. You always do.

**기존 기본 번역**

화물 엘리베이터를 찾아. 서둘러야 해. 놈들이 너희를 주시할 거야. 항상 지켜보고 있으니까.

**수정 기본 번역**

보급 엘리베이터를 찾아. 서둘러. 너희는 적의 이목을 끌 테니까. 늘 그렇듯이.

수정 이유: you always do의 주체와 선행 동작 복원

## 108. loc_explicator_a__mission_raid_den_inside_a_03

유형: 기존 수정

**현재 영문**

We're clearly dealing with an established set up. The enforcers have been looking the other way for some time.

**기존 기본 번역**

이곳은 꽤 오랫동안 운영된 시설 같아. 행동대원들이 꽤 오랫동안 이곳을 봐주고 있었던 것 같군.

**수정 기본 번역**

이곳은 꽤 오랫동안 운영된 시설 같아. 인포서들이 꽤 오랫동안 이곳을 봐주고 있었던 것 같군.

수정 이유: enforcers 명칭 통일

## 109. loc_explicator_a__mission_rails_end_event_conversation_one_b_03

유형: 기존 수정

**현재 영문**

She who holds the Logistratum controls everything that comes in and out of this hive sector.

**기존 기본 번역**

로지스트라툼을 장악한 여자가 이 하이브 구역으로 들어오고 나가는 모든 것들을 통제하고 있어.

**수정 기본 번역**

로지스트라툼을 장악하는 자가 이 하이브 구역을 드나드는 모든 것을 통제하지.

수정 이유: 일반적인 통제권 설명을 특정 여성의 현재 점유로 단정한 번역 수정

## 110. loc_explicator_a__mission_stockpile_elevator_conversation_one_b_03

유형: 기존 수정

**현재 영문**

Rannick says it's testing its strength - seeing how far it can extrude into the mortal world.

**기존 기본 번역**

라닉 님께선 그게 힘을 시험해 본 거라고 말씀하셨어. 필멸의 세상 속 어디까지 밀려날 수 있는 지 본 거라고 말이야.

**수정 기본 번역**

라닉 님 말로는 힘을 시험하는 거래. 필멸의 세계로 얼마나 뻗어 나올 수 있는지 보는 거지.

수정 이유: extrude into의 진입 방향 수정

## 111. loc_explicator_a__mission_stockpile_survive_event_end_02

유형: 기존 수정

**현재 영문**

No tears for that lot. Continue with the mission.

**기존 기본 번역**

감동 받을 필요없어. 임무나 진행하도록.

**수정 기본 번역**

저들을 위해 눈물 흘릴 필요 없어. 임무를 계속해.

수정 이유: 애도를 감동으로 옮긴 오류 수정

## 112. loc_explicator_a__mission_stockpile_survive_event_start_02

유형: 기존 수정

**현재 영문**

You're being watched. They'll attack as soon as you call the elevator.

**기존 기본 번역**

너희는 감시받고 있거든. 엘레베이터를 호출하면 바로 공격 받을 거야.

**수정 기본 번역**

너희는 감시받고 있거든. 엘리베이터를 호출하면 바로 공격 받을 거야.

수정 이유: 표기 수정

## 113. loc_forcestaff_p1_m1_deluxe

유형: 기존 수정

**현재 영문**

Trauma Force Staff (Mortis Operative)

**기존 기본 번역**

포스 스태프(몰티스 요원)

**수정 기본 번역**

보이드블래스트 포스 스태프(몰티스 요원)

수정 이유: 기존 모드의 현행 무기 계열 이름 통일

## 114. loc_havoc_onboarding_order_description

유형: 기존 수정

**현재 영문**

The higher an Assignment's Rank, the more difficult the deployment. Completing an Assignment equal to or up to 4 Ranks higher than your current Rank immediately increases your Assignment Rank by 1.

Completing an Assignment 5 Ranks higher than your current one increases yours by 2.

Completing an Assignment 10 Ranks higher than your current one increases yours by 3.

**기존 기본 번역**

임무 랭크가 높을수록 파견 난이도도 높아집니다. 현재 랭크보다 4단계 이상 높은 임무를 완료하면 즉시 1단계가 올라갑니다.

현재 랭크보다 5단계 이상 높은 임무를 완료하면 2단계가 올라갑니다.

현재 랭크보다 10단계 이상 높은 임무를 완료하면 3단계가 올라갑니다.

**수정 기본 번역**

임무 랭크가 높을수록 파견 난이도도 높아집니다. 현재 랭크와 같거나 최대 4단계 높은 임무를 완료하면 임무 랭크가 즉시 1단계 올라갑니다.

현재 랭크보다 5단계 높은 임무를 완료하면 2단계 올라갑니다.

현재 랭크보다 10단계 높은 임무를 완료하면 3단계 올라갑니다.

수정 이유: 현재 원문의 같음~4단계 상한을 4단계 이상으로 옮긴 오류 수정

## 115. loc_havoc_onboarding_party_description

유형: 기존 수정

**현재 영문**

Havoc Assignments do not use automatic matchmaking. You must form a Strike Team before starting a Havoc Assignment.

If you fail a Havoc Assignment equal to or higher than your current Assignment Rank, you lose one deployment, represented by losing a skull. Losing all three deployments demotes your Assignment Rank by one.

**기존 기본 번역**

하복 임무는 자동 매치메이킹을 사용하지 않습니다. 하복 임무를 시작하기 전에 스트라이크 팀을 구성해야 합니다.

하복 임무에 실패하는 경우, 해골로 표시되는 파견 횟수 1회를 잃습니다. 파견 횟수 3회를 모두 잃으면 임무 랭크를 1단계 강등합니다.

**수정 기본 번역**

하복 임무는 자동 매치메이킹을 사용하지 않습니다. 시작하기 전에 스트라이크 팀을 구성해야 합니다.

현재 임무 랭크와 같거나 더 높은 하복 임무에 실패하면 해골로 표시되는 파견 횟수를 한 번 잃습니다. 세 번을 모두 소진하면 임무 랭크가 한 단계 내려갑니다.

수정 이유: 실패 시 파견 횟수 차감이 적용되는 랭크 조건 복원

## 116. loc_interrogator_a__hammersmith_hub_announcement_09_b_01

유형: 추가 ID 덮어쓰기

**현재 영문**

Ah yes. I'd forgotten about that particular ... opportunity.

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

아, 그렇지. 그 특별한... 기회를 잊고 있었군.

수정 이유: 원문이 확보된 추가 대사 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 117. loc_lasgun_p3_m1_desc

유형: 기존 수정

**현재 영문**

Accatran lasguns are typified by their short, almost carbine-like profile, and high rate of fire, which make them ideal for use in the confines of boarding actions, cityfights, or trench warfare.

**기존 기본 번역**

아카트란 라스건은 짧고 거의 카빈과 유사한 외형과 높은 연사력으로 대표되며, 이는 승차 액션, 시가전 또는 참호전에서 사용하기에 이상적입니다.

**수정 기본 번역**

아카트란 라스건은 짧고 거의 카빈과 유사한 외형과 높은 연사력으로 대표되며, 이는 승함전, 시가전 또는 참호전에서 사용하기에 이상적입니다.

수정 이유: boarding actions를 차량 승차로 옮긴 오류 수정

## 118. loc_loading_hint_026

유형: 기존 수정

**현재 영문**

Kill, in the Emperor's name

**기존 기본 번역**

황제 폐하의 이름으로 죽어라

**수정 기본 번역**

황제 폐하의 이름으로 적을 죽여라

수정 이유: Kill을 죽으라는 명령으로 옮긴 반대 의미 수정

## 119. loc_loading_hint_127

유형: 추가 ID 덮어쓰기

**현재 영문**

Let no betrayal go unpunished

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

어떤 배신도 처벌 없이 넘기지 마라

수정 이유: 원문이 확보된 추가 로딩 문구 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 120. loc_loading_hint_235

유형: 기존 수정

**현재 영문**

Do your part for the Master of Mankind

**기존 기본 번역**

그대는 인류의 주인님을 위한 일을 하고 있는가

**수정 기본 번역**

인류의 주인님을 위해 그대의 본분을 다하라

수정 이유: 원문의 명령형 의미 반영

## 121. loc_loading_hint_252

유형: 기존 수정

**현재 영문**

The Emperor knows, the Emperor is watching

**기존 기본 번역**

불관용은 황제 폐하께서 우리에게 내려주신 은총이다

**수정 기본 번역**

황제 폐하께서는 알고 계시고, 보고 계신다

수정 이유: 해당 ID의 현재 영문·기본 한국어와 다른 문구를 덮어쓴 오류 수정

## 122. loc_loading_hint_299

유형: 기존 수정

**현재 영문**

As the Emperor protects, so must we

**기존 기본 번역**

황제 폐하께서 보호하시는 한, 우리는 안전하다

**수정 기본 번역**

황제 폐하께서 보호하시듯, 우리도 보호해야 한다

수정 이유: 보호할 의무를 안전 보장으로 옮긴 오류 수정

## 123. loc_medicae_servitor_a__medicae_servitor_idle_full_a_15

유형: 기존 수정

**현재 영문**

There is no hope save that which the Emperor provide.

**기존 기본 번역**

황제 폐하의 자비 외에 생존은 불가능합니다.

**수정 기본 번역**

황제 폐하께서 주시는 것 외에 다른 희망은 없습니다.

수정 이유: hope를 생존 가능성으로 한정한 번역 수정

## 124. loc_mission_board_main_objective_cooling_description

유형: 기존 수정

**현재 영문**

HL-17-36 is heading towards a power systems failure. Access the operations array and use cryonic rods to flush the system.

**기존 기본 번역**

HL-17-36의 전원 시스템이 장애를 일으키려 해. 수술 배열에 접속해서 냉각봉을 이용해 시스템을 점검하도록.

**수정 기본 번역**

HL-17-36의 전력 시스템이 고장 나려 한다. 연산 배열에 접속해서 냉각봉으로 시스템을 세척하도록.

수정 이유: operations array와 flush의 기술적 의미 수정

## 125. loc_mission_board_main_objective_enforcer_description

유형: 기존 수정

**현재 영문**

The Kill Target's in the Torrent's Enforcer Station. Navigate the sewers, reach the streets and take them out.

**기존 기본 번역**

제거 대상은 토렌트 인포서 초소에 있다. 하수도를 지나 길에 도착해 그들을 유인하도록.

**수정 기본 번역**

제거 대상은 토렌트 인포서 초소에 있다. 하수도를 지나 길에 도착해 놈들을 처치하도록.

수정 이유: take them out을 유인으로 옮긴 오류 수정

## 126. loc_mission_board_main_objective_waterstockpile_description

유형: 기존 수정

**현재 영문**

The heretics are poisoning Tertium's water. Get into the silo and restore a clean water supply.

**기존 기본 번역**

이교도들이 테르티움의 상수원을 오염시킬 계획이라고 한다. 사일로로 들어가 깨끗한 물 보급을 위해 복원시키도록.

**수정 기본 번역**

이교도들이 테르티움의 물을 오염시키고 있다. 사일로에 진입해 깨끗한 물 공급을 복구하도록.

수정 이유: 현재 진행 중인 오염을 계획으로 옮긴 오류 수정

## 127. loc_mission_board_mission_locked_requirement

유형: 기존 수정

**현재 영문**

Complete {campaign_name:%s} {chapters:%s} to access this mission.

**기존 기본 번역**

이 임무를 완료하려면 {campaign_name:%s} {chapters:%s}를 완료하세요.

**수정 기본 번역**

이 임무를 이용하려면 {campaign_name:%s} {chapters:%s}를 완료하세요.

수정 이유: 임무 완료 조건이 아니라 접근 조건

## 128. loc_mission_board_view_options_private_game_desc

유형: 기존 수정

**현재 영문**

Private Game: Prevents Players from Matchmaking into your current Strike Team.

Requires a Strike Team of at least two Players to enable.

{#color(255,0,0)}Enabling Private Game will disable Quickplay Matchmaking!{#reset()}

**기존 기본 번역**

비공개 게임: 무작위 플레이어가 현재 스트라이크 팀에 들어오지 못하게 막습니다.

스트라이크 팀에서 최소 두 명 이상이 이 옵션을 활성화해야 합니다.

**수정 기본 번역**

비공개 게임: 다른 플레이어가 매치메이킹으로 현재 스트라이크 팀에 들어오지 못하게 합니다.

활성화하려면 스트라이크 팀에 플레이어가 최소 두 명 있어야 합니다.

{#color(255,0,0)}비공개 게임을 활성화하면 빠른 플레이 매치메이킹을 사용할 수 없습니다!{#reset()}

수정 이유: 팀원 두 명이 각각 옵션을 켜야 한다는 오역과 빠른 플레이 제한 누락 수정

## 129. loc_mourningstar_confessor_a__mourningstar_announcement_a_04

유형: 기존 수정

**현재 영문**

All recruits must report for physical assessment prior and post mission. No exceptions.

**기존 기본 번역**

모든 신입은 임무를 시작하기 전에 신체 검진을 받아야 한다. 예외는 없다.

**수정 기본 번역**

모든 신입은 임무 전후로 신체 검진을 받아야 한다. 예외는 없다.

수정 이유: 임무 후 검진 조건 누락 복원

## 130. loc_mourningstar_confessor_a__mourningstar_announcement_a_05

유형: 기존 수정

**현재 영문**

We are the instruments of the Imperium's design. We will serve our purpose without question.

**기존 기본 번역**

우리는 황제 폐하의 설계에 쓰이는 도구들이다. 아무 질문 없이 임무를 수행해야 한다.

**수정 기본 번역**

우리는 제국의 계획을 실현하는 도구다. 의문 없이 본분을 다해야 한다.

수정 이유: 원문의 제국과 의무 이행 의미 반영

## 131. loc_mourningstar_servitor_a__hub_flight_deck_announcement_29

유형: 기존 수정

**현재 영문**

Sabotage Mission Harbex-14-Alpha authorised. All active strike teams to Hangar Bay Beta-6

**기존 기본 번역**

방해 공작 임무 하벡스-14-알파 승인. 모든 활동 기동대는 격납고 구역 에타-6으로.

**수정 기본 번역**

방해 공작 임무 하벡스-14-알파 승인. 모든 활동 기동대는 격납고 구역 베타-6으로.

수정 이유: 목적지 Beta-6 식별자 오역 수정

## 132. loc_mourningstar_servitor_c__hub_news_announcement_27

유형: 기존 수정

**현재 영문**

Salvage operations underway in Habzone HL-70-22. Mechanicus support requested.

**기존 기본 번역**

거주 구역 HL-70-22에서 구조 작전이 진행 중입니다. 메카니쿠스의 지원을 요청합니다.

**수정 기본 번역**

거주 구역 HL-70-22에서 회수 작전이 진행 중입니다. 메카니쿠스의 지원을 요청합니다.

수정 이유: salvage 작전의 의미 구분

## 133. loc_mourningstar_servitor_c__hub_news_announcement_28

유형: 기존 수정

**현재 영문**

Salvage operations underway in Habzone HL-70-28. Mechanicus support requested.

**기존 기본 번역**

거주 구역 HL-70-28에서 구조 작전이 진행 중입니다. 메카니쿠스의 지원을 요청합니다.

**수정 기본 번역**

거주 구역 HL-70-28에서 회수 작전이 진행 중입니다. 메카니쿠스의 지원을 요청합니다.

수정 이유: salvage 작전의 의미 구분

## 134. loc_mourningstar_servitor_c__hub_news_announcement_29

유형: 기존 수정

**현재 영문**

Salvage operations underway in Habzone HL-14-66. Mechanicus support requested.

**기존 기본 번역**

거주 구역 HL-14-66에서 구조 작전이 진행 중입니다. 메카니쿠스의 지원을 요청합니다.

**수정 기본 번역**

거주 구역 HL-14-66에서 회수 작전이 진행 중입니다. 메카니쿠스의 지원을 요청합니다.

수정 이유: salvage 작전의 의미 구분

## 135. loc_mourningstar_servitor_c__hub_news_announcement_30

유형: 기존 수정

**현재 영문**

Salvage operations underway in Habzone HL-6-66. Rites of Exorcism required.

**기존 기본 번역**

거주 구역 HL-6-66에서 구조 작전이 진행 중입니다. 메카니쿠스의 지원을 요청합니다.

**수정 기본 번역**

거주 구역 HL-6-66에서 회수 작업 진행 중. 구마 의식이 필요하다.

수정 이유: salvage 및 Rites of Exorcism을 각각 구조와 포괄적 지원으로 옮긴 오류 수정

## 136. loc_mourningstar_soldier_male_c__hub_idle_greeting_dislike_a_07

유형: 기존 수정

**현재 영문**

Zola's done scraping the barrel. We're onto dregs.

**기존 기본 번역**

드렉을 상대해야 하는데 졸라 님은 쓰레기를 가져오시는군.

**수정 기본 번역**

졸라 님이 바닥까지 긁어모으시더니, 이제 찌꺼기까지 데려오시는군.

수정 이유: 불량 신입에 대한 비유를 적 병종과의 전투로 옮긴 오류 수정

## 137. loc_mourningstar_wing_commander_a__mourningstar_announcement_a_02

유형: 기존 수정

**현재 영문**

If you do not have security clearance, keep to your designated zones. 

**기존 기본 번역**

보안 권한이 없으면, 원래 목적지로 이동하라.

**수정 기본 번역**

보안 허가가 없다면 지정된 구역 안에 머물러라.

수정 이유: 이동 지시로 바뀐 구역 제한 명령 수정

## 138. loc_mourningstar_wing_commander_a__mourningstar_announcement_a_14

유형: 기존 수정

**현재 영문**

Returning mission team inbound in two hours and sixteen minutes. All support crews to their stations. Emperor be praised!

**기존 기본 번역**

2시간 16분 뒤 임무 팀이 귀환한다. 모든 지원 승무원들은 스테이션으로 이동하라. 황제 페하를 찬양하라!

**수정 기본 번역**

2시간 16분 뒤 임무 팀이 귀환한다. 모든 지원 승무원들은 스테이션으로 이동하라. 황제 폐하를 찬양하라!

수정 이유: 오타 수정

## 139. loc_mourningstar_wing_commander_a__mourningstar_announcement_a_19

유형: 기존 수정

**현재 영문**

Augur returns show high orbital debris in fourth and seventh quadrants. Stay alert.

**기존 기본 번역**

관측 결과에서 4분위와 7분위에서 고궤도 잔해가 발견되었다. 모두 주의하도록.

**수정 기본 번역**

관측 결과, 제4·제7구역에서 고궤도 잔해가 발견되었다. 모두 주의하도록.

수정 이유: quadrants의 구역 의미 반영

## 140. loc_mourningstar_wing_commander_a__mourningstar_announcement_a_20

유형: 기존 수정

**현재 영문**

Ordnance teams Secundus through Septimus prepare primary magazines for sanctification.

**기존 기본 번역**

군수팀 세쿤두스와 셉티무스는 정화를 위한 주 무기 탄약을 준비하도록.

**수정 기본 번역**

군수팀 세쿤두스부터 셉티무스까지, 주 탄약고의 축성 준비를 하라.

수정 이유: 팀 범위와 primary magazines의 뜻 복원

## 141. loc_notification_helped_collectible_picked_up

유형: 기존 수정

**현재 영문**

Helped {player_names:%s} find a Martyr's Skull.

**기존 기본 번역**

{player_names:%s} 요원이 순교자의 두개골 발견을 도움

**수정 기본 번역**

{player_names:%s} 요원이 순교자의 두개골을 찾도록 도왔습니다.

수정 이유: 도움을 준 사람과 받은 사람의 관계 수정

## 142. loc_npc_full_name_interrogator_a

유형: 추가 ID 덮어쓰기

**현재 영문**

Interrogator Rannick

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

심문관 라닉

수정 이유: 기존 인물 호칭과 통일

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 143. loc_npc_full_name_sergeant_a

유형: 추가 ID 덮어쓰기

**현재 영문**

Sergeant Major Morrow

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

모로우 원사

수정 이유: 기존 인물 호칭과 통일

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 144. loc_npc_short_name_interrogator_a

유형: 추가 ID 덮어쓰기

**현재 영문**

Rannick

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

라닉

수정 이유: 기존 인물 이름과 통일

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 145. loc_npc_short_name_sergeant_a

유형: 추가 ID 덮어쓰기

**현재 영문**

Morrow

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

모로우

수정 이유: 기존 인물 이름과 통일

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 146. loc_npc_short_name_shipmistress_a

유형: 추가 ID 덮어쓰기

**현재 영문**

Brahms

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

브람스

수정 이유: 기존 인물 이름과 통일

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 147. loc_npc_short_name_vocator_a

유형: 추가 ID 덮어쓰기

**현재 영문**

Vox Announcer

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

복스 방송원

수정 이유: 원문이 확보된 화자 이름 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 148. loc_objective_fm_armoury_brewery_header

유형: 기존 수정

**현재 영문**

Proceed through the Brewery

**기존 기본 번역**

주조장 통과하기

**수정 기본 번역**

양조장 통과하기

수정 이유: Brewery를 주조장으로 옮긴 오류 수정

## 149. loc_objective_fm_resurgence_start_header

유형: 기존 수정

**현재 영문**

Locate the Skylink bridge

**기존 기본 번역**

스카이링크 다리 배치하기

**수정 기본 번역**

스카이링크 다리 찾기

수정 이유: locate를 배치로 옮긴 오류 수정

## 150. loc_objective_side_mission_grimoire_desc

유형: 기존 수정

**현재 영문**

Seize Grimoires

**기존 기본 번역**

마도서 2권을 회수하세요.

**수정 기본 번역**

마도서를 회수하세요.

수정 이유: 현재 원문에 없는 고정 수량 제거

## 151. loc_ogryn_a__come_back_to_squad_05

유형: 기존 수정

**현재 영문**

Ain't good enough for your company?

**기존 기본 번역**

네 중대로는 충분하지 않은 거야?

**수정 기본 번역**

내가 같이 다니기엔 부족하다는 거야?

수정 이유: company를 군대의 중대로 옮긴 오류 수정

## 152. loc_ogryn_a__enemy_kill_grenadier_05

유형: 기존 수정

**현재 영문**

Crunched the Bomber!

**기존 기본 번역**

보머를 부셔버렸어!

**수정 기본 번역**

보머를 부숴 버렸어!

수정 이유: 맞춤법 수정

## 153. loc_ogryn_a__heard_enemy_chaos_spawn_03

유형: 기존 수정

**현재 영문**

Rotbag!

**기존 기본 번역**

살덩이!

**수정 기본 번역**

부패덩어리!

수정 이유: Rotbag 적 명칭 통일

## 154. loc_ogryn_a__lore_hadron_four_a_03

유형: 기존 수정

**현재 영문**

Know where you stand with Tech-Lady.

**기존 기본 번역**

테크레이디가 있으면 내가 어디 있어야 하는지 알 수 있지.

**수정 기본 번역**

테크레이디는 속내를 알기 쉬워.

수정 이유: know where you stand 관용 표현 수정

## 155. loc_ogryn_a__mission_cartel_reach_bazaar_01

유형: 기존 수정

**현재 영문**

Was taught a word for this. "In - ter - knee - sign" fighting, no?

**기존 기본 번역**

배운 적이 있어. "무-릎-꿇-고" 싸우는 거지, 아니야?

**수정 기본 번역**

배운 적이 있어. 이런 걸 "내-부-상-잔"이라고 했지, 맞나?

수정 이유: internecine을 무릎 꿇기로 옮긴 오류 수정; 더듬는 말투 유지

## 156. loc_ogryn_a__mission_cooling_elevator_conversation_three_line_one_01

유형: 기존 수정

**현재 영문**

Factory will need workers, or stay silent.

**기존 기본 번역**

공장은 노동자를 필요 하거나, 잠들어 있을 거야.

**수정 기본 번역**

공장을 돌리려면 노동자가 필요해. 없으면 멈춰 있을 거야.

수정 이유: 노동자 필요 조건이 잘못 연결된 문장 수정

## 157. loc_ogryn_a__mission_cooling_production_line_02

유형: 기존 수정

**현재 영문**

Leman Russ tanks strong, like Ogryn. Not as good for conversation.

**기존 기본 번역**

리만 러스 전차는 오그린처럼 강해. 나처럼 대화도 잘 못하지.

**수정 기본 번역**

리만 러스 전차는 오그린처럼 강해. 대화는 오그린보다 못하지.

수정 이유: 비교 대상과 의미를 반대로 옮긴 오류 수정

## 158. loc_ogryn_a__mission_forge_elevator_conversation_two_c_02

유형: 기존 수정

**현재 영문**

Hah! Enemy will need tanks to face me.

**기존 기본 번역**

하! 적들의 전차는 날 상대해야 할 거야.

**수정 기본 번역**

하! 적들이 날 상대하려면 전차가 필요할 거야.

수정 이유: 전차가 주어가 되는 오류 수정

## 159. loc_ogryn_a__mission_rails_end_event_conversation_three_c_02

유형: 기존 수정

**현재 영문**

Not such goody-two-shoes after all!

**기존 기본 번역**

그렇게 좋은 신발이 아니군!

**수정 기본 번역**

알고 보니 그렇게 모범생은 아니었군!

수정 이유: goody-two-shoes를 신발로 직역한 오류 수정

## 160. loc_ogryn_a__mission_scavenge_interior_01

유형: 기존 수정

**현재 영문**

Broken by hive quakes. Could be dangerous.

**기존 기본 번역**

하이브 지진에 의해 부셔졌군. 위험할 수도 있어.

**수정 기본 번역**

하이브 지진에 의해 부서졌군. 위험할 수도 있어.

수정 이유: 맞춤법 수정

## 161. loc_ogryn_a__seen_enemy_shocktrooper_02

유형: 기존 수정

**현재 영문**

Gotta Shotgun!

**기존 기본 번역**

샷거너를 잡아!

**수정 기본 번역**

샷거너다!

수정 이유: Got a의 적 발견 표현을 공격 지시로 옮긴 오류 수정

## 162. loc_ogryn_b__heard_enemy_chaos_spawn_06

유형: 기존 수정

**현재 영문**

It's a bleeding Rotbag!

**기존 기본 번역**

피나는 부패덩어리야!

**수정 기본 번역**

망할 부패덩어리야!

수정 이유: 강조용 bleeding을 실제 출혈로 옮긴 오류 수정

## 163. loc_ogryn_b__mission_cargo_hab_feed_lines_01

유형: 기존 수정

**현재 영문**

Little cargo trains? Like trains.

**기존 기본 번역**

작은 화물 기차야? 기차 같은데.

**수정 기본 번역**

작은 화물 기차야? 나 기차 좋아해.

수정 이유: Like trains의 선호 표현 복원

## 164. loc_ogryn_b__mission_cartel_reach_bazaar_02

유형: 기존 수정

**현재 영문**

Fighting each other? None left for us!

**기존 기본 번역**

서로 싸웠었나? 아무도 안 남았어!

**수정 기본 번역**

서로 싸웠었나? 우리가 죽일 놈이 안 남았어!

수정 이유: 오그린 몫의 적이 없다는 의미 복원

## 165. loc_ogryn_b__mission_forge_elevator_conversation_one_a_02

유형: 기존 수정

**현재 영문**

These tanks better be karking worth it.

**기존 기본 번역**

이 전차는 좀 더 나아.

**수정 기본 번역**

이 전차들이 이 고생을 할 만한 값어치는 있어야 할 텐데.

수정 이유: better be worth it의 의미 복원

## 166. loc_ogryn_b__seen_enemy_grenadier_08

유형: 기존 수정

**현재 영문**

Crush that Bomber!

**기존 기본 번역**

망할 보머!

**수정 기본 번역**

저 보머를 박살내!

수정 이유: Crush 공격 지시 복원

## 167. loc_ogryn_b__seen_enemy_shocktrooper_03

유형: 기존 수정

**현재 영문**

Wallop that Shotgunner!

**기존 기본 번역**

저 샷거너를 쏴버려!

**수정 기본 번역**

저 샷거너를 때려눕혀!

수정 이유: Wallop을 사격으로 한정한 번역 수정

## 168. loc_ogryn_c__conversation_tech_priest_one_a_02

유형: 기존 수정

**현재 영문**

Tech-Priest ok?

**기존 기본 번역**

테크프리스트 맞아?

**수정 기본 번역**

테크프리스트 괜찮아?

수정 이유: 상태를 묻는 말을 신원 확인으로 옮긴 오류 수정

## 169. loc_ogryn_c__enemy_kill_grenadier_08

유형: 기존 수정

**현재 영문**

We got the Bomber lads!

**기존 기본 번역**

보머 친구를 처치했어!

**수정 기본 번역**

보머를 잡았어, 친구들!

수정 이유: lads 호칭을 보머의 수식어로 옮긴 오류 수정

## 170. loc_ogryn_c__head_shot_01

유형: 기존 수정

**현재 영문**

Right in the noggin!

**기존 기본 번역**

황즈에 폐하께서 칭찬해주실 거야!

**수정 기본 번역**

머리통에 제대로 맞혔다!

수정 이유: 원문과 관계없는 황제 칭찬 대사 및 오타 수정

## 171. loc_ogryn_c__mission_cartel_old_hab_01

유형: 기존 수정

**현재 영문**

Run down old habs falling apart...

**기존 기본 번역**

낡은 하이브가 무너져 내리는군...

**수정 기본 번역**

낡은 거주 구역이 무너져 내리는군...

수정 이유: hab을 하이브로 옮긴 오류 수정

## 172. loc_ogryn_c__mission_enforcer_traders_row_01

유형: 기존 수정

**현재 영문**

I'll take a packet o' Scurrier legs and a bucket o' yer best!

**기존 기본 번역**

스커리어 다리 한 봉지와 최고의 한 통을 가져갈게!

**수정 기본 번역**

스커리어 다리 한 봉지랑 제일 좋은 술 한 통 줘!

수정 이유: 주문하는 문장에서 빠진 목적어 보완

## 173. loc_ogryn_c__mission_forge_elevator_conversation_one_c_02

유형: 기존 수정

**현재 영문**

They take a shot and keep fighting... like Ogryn!

**기존 기본 번역**

저 전차들은 쏘기도 하고 계속 싸워... 오그린처럼!

**수정 기본 번역**

저 전차들은 총에 맞아도 계속 싸워... 오그린처럼!

수정 이유: take a shot을 사격으로 옮긴 오류 수정

## 174. loc_ogryn_c__mission_station_station_hall_01

유형: 기존 수정

**현재 영문**

Not a bad effort at messing this place up...

**기존 기본 번역**

여길 엉망으로 만드는 건 일도 아니지...

**수정 기본 번역**

여길 엉망으로 만드는 데 꽤 공들였군...

수정 이유: 이미 벌어진 파괴에 대한 평을 능력 자랑으로 옮긴 오류 수정

## 175. loc_ogryn_c__seen_enemy_berserker_06

유형: 기존 수정

**현재 영문**

Rager! Drop 'em!

**기존 기본 번역**

레이저다! 떨어뜨려!

**수정 기본 번역**

레이저다! 쓰러뜨려!

수정 이유: Drop 적 처치 지시 수정

## 176. loc_ogryn_c__seen_enemy_berserker_08

유형: 기존 수정

**현재 영문**

Rager! Put 'em down!

**기존 기본 번역**

레이저다! 쓰려뜨려!

**수정 기본 번역**

레이저다! 쓰러뜨려!

수정 이유: 오타 수정

## 177. loc_ogryn_c__seen_enemy_berserker_09

유형: 기존 수정

**현재 영문**

Rager! Get 'em!

**기존 기본 번역**

레이저다! 조심해!

**수정 기본 번역**

레이저다! 잡아!

수정 이유: Get 적 공격 지시 복원

## 178. loc_ogryn_c__seen_enemy_berserker_10

유형: 기존 수정

**현재 영문**

Rager! Get 'em lads!

**기존 기본 번역**

레이저다! 조심해, 친구들!

**수정 기본 번역**

레이저다! 잡아, 친구들!

수정 이유: Get 적 공격 지시 복원

## 179. loc_ogryn_c__seen_enemy_grenadier_03

유형: 기존 수정

**현재 영문**

Bomber... get 'em!

**기존 기본 번역**

보머다... 조심해!

**수정 기본 번역**

보머다... 잡아!

수정 이유: Get 적 공격 지시 복원

## 180. loc_ogryn_c__seen_enemy_grenadier_08

유형: 기존 수정

**현재 영문**

Let me get me mitts on that Bomber...[growl]

**기존 기본 번역**

보머 장갑 가져 갈래...[으르렁]

**수정 기본 번역**

저 보머를 내 손으로 잡기만 하면...[으르렁]

수정 이유: get my mitts on을 장갑 가져가기라고 옮긴 오류 수정

## 181. loc_party_join_you_are_in_onboarding

유형: 기존 수정

**현재 영문**

Could not join Strike Team, you are currently playing the onboarding.

**기존 기본 번역**

스트라이크 팀에 참가하지 못했습니다. 현재 플레이 중입니다.

**수정 기본 번역**

스트라이크 팀에 참가하지 못했습니다. 현재 도입부를 플레이 중입니다.

수정 이유: 일반 플레이가 아니라 onboarding 중인 제한임을 명시

## 182. loc_past_auspex_operator_a__story_echo_morrow_21_c_01

유형: 기존 수정

**현재 영문**

Brunt found a dataslate: Vin Morrow, late of the Armageddon Steel Legions.

**기존 기본 번역**

브런트가 데이터슬레이트를 찾았습니다. 빈센트 모로우, 이미 전멸한 아마겟돈 스틸 리전 소속입니다.

**수정 기본 번역**

브런트가 데이터슬레이트를 찾았습니다. 빈 모로우, 전 아마겟돈 스틸 리전 소속입니다.

수정 이유: late of를 부대 전멸로 옮긴 오류 수정; 원문 이름 Vin 반영

## 183. loc_past_brother_a__story_echo_zola_01_b_01

유형: 기존 수정

**현재 영문**

The Emperor's calling me to war.

**기존 기본 번역**

황제 폐하께서 우릴 전장으로 부르시니까.

**수정 기본 번역**

황제 폐하께서 날 전장으로 부르시니까.

수정 이유: 원문의 단수 화자 반영

## 184. loc_past_enemy_nemesis_wolfer_a__story_echo_morrow_28_c_01

유형: 기존 수정

**현재 영문**

[Grunt] We need ammunition. Heavy tanks. Not bureaucrats and dataslates.

**기존 기본 번역**

[신음] 우리에겐 탄약이 필요해. 대형 전차도. 행정이나 데이터슬레이트는 필요 없어.

**수정 기본 번역**

[신음] 우리에겐 탄약이 필요해. 대형 전차도. 관료나 데이터슬레이트는 필요 없어.

수정 이유: bureaucrats는 행정 업무가 아니라 관료를 뜻함

## 185. loc_past_explicator_a__story_echo_zola_21_a_01

유형: 기존 수정

**현재 영문**

Racketeering. Smuggling. Suborning enforcers. It won't take much to get the Arbitrators interested.

**기존 기본 번역**

도박, 밀수, 인포서 매수. 조정자들이 이 얘기를 들으면 관심이 생길 거 같거든.

**수정 기본 번역**

갈취, 밀수, 인포서 매수. 이 정도면 아비트레이터들의 관심을 끌기엔 충분하겠지.

수정 이유: racketeering 오역 및 Arbitrators 명칭 통일

## 186. loc_past_explicator_a__story_echo_zola_28_d_01

유형: 기존 수정

**현재 영문**

I'm glad to hear it.

**기존 기본 번역**

좋은 의견이네요.

**수정 기본 번역**

그 말을 들으니 기쁘네요.

수정 이유: 긍정적인 소식에 대한 응답을 제안 평가로 옮긴 오류 수정

## 187. loc_past_interrogator_a__story_echo_morrow_17_c_01

유형: 기존 수정

**현재 영문**

And you're sure that's an Ordo Malleus distress hymnal?

**기존 기본 번역**

오르도 말레우스 님의 구조 요청 송가가 확실한가?

**수정 기본 번역**

오르도 말레우스의 구조 요청 송가가 확실한가?

수정 이유: 조직명을 인명처럼 옮긴 존칭 수정

## 188. loc_past_legion_trooper_a__story_echo_morrow_07_c_01

유형: 기존 수정

**현재 영문**

Captain Vanderack!

**기존 기본 번역**

반데라크 대위님을 위하여!

**수정 기본 번역**

반데라크 대위님!

수정 이유: 호명에 원문에 없는 위하여라는 구호를 추가한 부분 수정

## 189. loc_past_sergeant_a__story_echo_morrow_07_b_01

유형: 기존 수정

**현재 영문**

Captain Vanderack!

**기존 기본 번역**

반데라크 대위님을 위하여!

**수정 기본 번역**

반데라크 대위님!

수정 이유: 호명에 원문에 없는 위하여라는 구호를 추가한 부분 수정

## 190. loc_past_sergeant_a__story_echo_morrow_34_e_01

유형: 기존 수정

**현재 영문**

Already did. We're here to get you out ... He said you'd have a waspish tongue. His words.

**기존 기본 번역**

이미 말했잖아. 널 데리러 온 거야. 네 말투는 벌이 쏘는 것 같다고 하시던데. 그분 말로는.

**수정 기본 번역**

이미 말했잖아. 널 데리러 온 거야... 네 말에 가시가 있을 거라더군. 그분께서 말이야.

수정 이유: waspish tongue의 관용 표현 수정

## 191. loc_pilot_a__cs_prologue_four_02_01

유형: 기존 수정

**현재 영문**

Stand by, Zola. The guidance is out. I need a minute to recalibrate.

**기존 기본 번역**

대기하세요, 졸라 님. 안내가 종료되었어요. 재보정할 시간이 필요해요.

**수정 기본 번역**

대기하세요, 졸라 님. 유도 장치가 고장났어요. 재보정할 시간이 필요해요.

수정 이유: guidance 장치 고장을 안내 종료로 옮긴 오류 수정

## 192. loc_pilot_a__info_extraction_04

유형: 기존 수정

**현재 영문**

Storm Raptor to the rescue! Yee-ha!

**기존 기본 번역**

스톰 랩터를 구출하라! 이-하!

**수정 기본 번역**

스톰 랩터가 구조하러 간다! 이-하!

수정 이유: 구조 주체와 대상이 뒤바뀐 오류 수정

## 193. loc_pilot_a__info_valkyrie_approach_12

유형: 기존 수정

**현재 영문**

Get aboard, before we are overrun!

**기존 기본 번역**

가버리기 전에 타!

**수정 기본 번역**

적에게 압도당하기 전에 타!

수정 이유: 탑승 지연의 위험을 다른 의미로 옮긴 오류 수정

## 194. loc_pilot_a__mission_archives_mid_conversation_two_b_01

유형: 기존 수정

**현재 영문**

Like most of the Imperium, Archivum Sycorax is surprisingly durable.

**기존 기본 번역**

다른 제국과 마찬가지로, 아르키붐 시코락스도 깜짝 놀랄 만큼 튼튼하지.

**수정 기본 번역**

제국의 다른 시설들처럼 아르키붐 시코락스도 놀랄 만큼 튼튼하지.

수정 이유: 대상을 여러 제국으로 옮긴 오류 수정

## 195. loc_pilot_a__mission_archives_mid_conversation_two_b_02

유형: 기존 수정

**현재 영문**

That's the Imperium for you. Built to last, and to endure.

**기존 기본 번역**

오래 살아남아 견디기 위해 지어진 게, 너희와 어울리는 제국이야.

**수정 기본 번역**

제국이란 그런 곳이지. 오래 버티고 견디도록 만들어졌어.

수정 이유: that's the Imperium for you 관용 표현 수정

## 196. loc_pilot_a__mission_complex_elevator_conversation_2_b_01

유형: 기존 수정

**현재 영문**

There's an auspex-stealthed outpost responsible for relaying information to Grendyl's other operatives. I can't tell you more.

**기존 기본 번역**

그렌딜 님의 다른 첩보원에게 정보를 전달하기 위해 아우스펙스가 숨겨놓은 전초 기지가 있어. 더는 말해줄 수 없어.

**수정 기본 번역**

그렌딜 님의 다른 요원들에게 정보를 전달하는 전초 기지가 있어. 아우스펙스에 탐지되지 않도록 위장된 곳이지. 더는 말해줄 수 없어.

수정 이유: 탐지를 피하는 대상을 은폐 수단으로 옮긴 오류 수정

## 197. loc_pilot_a__mission_complex_elevator_here_03

유형: 기존 수정

**현재 영문**

Elevator's here. Looks like you live to fight another day.

**기존 기본 번역**

엘리베이터가 여기 있어! 넌 꼭 싸우기 위해 사는 사람 같네.

**수정 기본 번역**

엘리베이터가 왔어. 살아남아서 다음에도 싸울 수 있겠네.

수정 이유: live to fight another day 관용 표현 수정

## 198. loc_pilot_a__mission_complex_elevator_here_04

유형: 기존 수정

**현재 영문**

That's the elevator and you're still alive. I lose my bet, but I forgive you.

**기존 기본 번역**

저기 엘레베이터가 왔는데 아직 살아있네. 내기에는 졌지만 용서하겠어.

**수정 기본 번역**

저기 엘리베이터가 왔는데 아직 살아있네. 내기에는 졌지만 용서하겠어.

수정 이유: 표기 수정

## 199. loc_pilot_a__mission_complex_skyfire_cutout_01

유형: 기존 수정

**현재 영문**

Kill that breaker. It feeds power to the skyfire on the roof.

**기존 기본 번역**

차단기를 부셔버려. 그게 지붕에 있는 스카이파이어에 동력을 공급하고 있어.

**수정 기본 번역**

차단기를 부숴 버려. 그게 지붕에 있는 스카이파이어에 동력을 공급하고 있어.

수정 이유: 맞춤법 수정

## 200. loc_pilot_a__mission_complex_transmitter_01

유형: 기존 수정

**현재 영문**

There's transmitter. You'll need to align it with your data-interrogators!

**기존 기본 번역**

송신기가 있어. 데이터 탐색 장치와 연동해!

**수정 기본 번역**

송신기가 있어. 데이터 탐색 장치로 방향을 맞춰야 해!

수정 이유: 안테나 정렬을 기기 연동으로 옮긴 오류 수정

## 201. loc_pilot_a__mission_complex_transmitter_02

유형: 기존 수정

**현재 영문**

You can align the dish using your data-interrogators.

**기존 기본 번역**

네 데이터 탐색 장치를 사용하면 안테나를 연동할 수 있어.

**수정 기본 번역**

데이터 탐색 장치로 안테나의 방향을 맞출 수 있어.

수정 이유: 안테나 정렬을 기기 연동으로 옮긴 오류 수정

## 202. loc_pilot_a__mission_complex_transmitter_04

유형: 기존 수정

**현재 영문**

The dish isn't aligned, but we can fix that. Or rather you can. Time for your data-interrogators!

**기존 기본 번역**

안테나가 연동되지 않았지만, 우리가 고칠 수 있어. 아니면 너희가 할 수 있겠지. 네 데이터 탐색 장치가 활약할 시간이야!

**수정 기본 번역**

안테나 방향이 안 맞지만, 고칠 수 있어. 정확히는 너희가 고칠 거지. 데이터 탐색 장치가 나설 차례야!

수정 이유: 안테나 정렬을 기기 연동으로 옮긴 오류 수정

## 203. loc_pilot_a__mission_resurgence_brief_c_03

유형: 기존 수정

**현재 영문**

The Aegis Station there is old, but once you've removed any squatters, we can use it.

**기존 기본 번역**

이지스 스테이션을 정화하고 지원팀이 올 때까지 이교도들을 막아.

**수정 기본 번역**

저 이지스 스테이션은 낡았지만, 무단 점거자들만 쫓아내면 우리가 쓸 수 있어.

수정 이유: 다른 임무 대사를 복사한 번역을 현재 원문으로 수정

## 204. loc_pilot_a__mission_station_briefing_b_03

유형: 기존 수정

**현재 영문**

Head to the market. Splice into the auto-scheduler, and redirect the Sanction Redactus Target's train to Chasm Terminus.

**기존 기본 번역**

시장으로 가. 자동 스케쥴러를 조작해서 생션 레닥투스 목표의 기차를 캐즘 터미누스로 보내.

**수정 기본 번역**

시장으로 가. 자동 스케줄러를 조작해서 생션 레닥투스 목표의 기차를 캐즘 터미누스로 보내.

수정 이유: 표기 수정

## 205. loc_pilot_a__mission_station_interrogate_splice_point_01

유형: 기존 수정

**현재 영문**

You've kicked the nest. Better get the splice underway!

**기존 기본 번역**

벌집을 건드렸네. 어서 아래쪽의 분기 장치로 가!

**수정 기본 번역**

벌집을 건드렸네. 어서 선로 전환 작업을 시작해!

수정 이유: get underway를 아래쪽으로 이동하는 뜻으로 옮긴 오류 수정

## 206. loc_pilot_a__mission_strain_mid_event_conversation_three_b_03

유형: 기존 수정

**현재 영문**

If I thought you were going to carriers, would I be exfiltrating you after the mission?

**기존 기본 번역**

만약 너희가 함선에 갈 거라고 생각했다면, 내가 임무가 끝난 후 너희를 탈출시키겠어?

**수정 기본 번역**

너희가 보균자일 거라고 생각했다면, 임무가 끝난 뒤 내가 데리러 가겠어?

수정 이유: 문맥상 질병 보균자인 carriers를 함선으로 옮긴 오류 수정; 영문 문법에 누락이 있어 문맥 해석 포함

확인 메모: 영문 going to carriers는 문법상 불완전하며, 감염 지역 탈출 대사라는 문맥을 참고한 해석. 음성 확인 권장.

## 207. loc_pilot_a__mission_strain_mid_event_conversation_two_b_03

유형: 기존 수정

**현재 영문**

I cannot tell you what I do not know. Trust to prayer. Let the Emperor preserve you.

**기존 기본 번역**

지금은 내가 아는 걸 말해줄 수 없어. 기도를 믿어라. 그리고 황제 폐하께서 가호하시길.

**수정 기본 번역**

나도 모르는 건 알려줄 수 없어. 기도에 의지해. 황제 폐하께서 지켜주시길.

수정 이유: 모르는 정보를 숨기는 정보로 옮긴 오류 수정

## 208. loc_pilot_a__mission_strain_mid_event_conversation_two_b_04

유형: 기존 수정

**현재 영문**

It is no mortal contagion, or so I hear. You must have faith.

**기존 기본 번역**

이건 치명적인 오염은 아니라고 하던데. 그러니 믿음을 가져.

**수정 기본 번역**

필멸자의 질병은 아니라더군. 믿음을 가져야 해.

수정 이유: 초자연적 전염을 사망 위험이 없는 전염으로 단정한 번역 수정

## 209. loc_pilot_a__prologue_end_event_02_01

유형: 기존 수정

**현재 영문**

Come on… Don't you fall apart on me now!

**기존 기본 번역**

제발... 지금 저한테서 떨어지지 마세요!

**수정 기본 번역**

제발... 지금 망가지면 안 돼!

수정 이유: 자기 기체에 대한 말을 상대와 떨어지는 행동으로 옮긴 오류 수정

## 210. loc_pilot_a__tech_priest_info_call_extraction_response_01

유형: 기존 수정

**현재 영문**

Do not get your cogs in a twist. I am going!

**기존 기본 번역**

잘 보고 배우라고, 테크프리스트!

**수정 기본 번역**

톱니바퀴 꼬지 말라고. 지금 가고 있으니까!

수정 이유: 현재 원문과 다른 대사 수정; 기계교 인물에 대한 비유 보존

## 211. loc_pilot_a__tech_priest_info_call_extraction_response_10

유형: 기존 수정

**현재 영문**

Clanky almost sounded worried. Imagine that?

**기존 기본 번역**

삐걱거리는 소리가 거의 걱정스럽게 들리는걸. 상상해 봐?

**수정 기본 번역**

우리 깡통 양반이 걱정하는 말투네. 상상이 가?

수정 이유: Clanky라는 호칭을 실제 삐걱거리는 소리로 옮긴 오류 수정

## 212. loc_popup_button_continue_game

유형: 추가 ID 덮어쓰기

**현재 영문**

Cancel

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

취소

수정 이유: 버튼 ID의 continue가 아니라 실제 영문 Cancel을 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 213. loc_popup_button_quit_game

유형: 추가 ID 덮어쓰기

**현재 영문**

Quit Game

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

게임 종료

수정 이유: 원문이 확보된 종료 UI 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 214. loc_popup_description_quit_game

유형: 추가 ID 덮어쓰기

**현재 영문**

Are you sure you want to quit the game?

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

게임을 종료하시겠습니까?

수정 이유: 원문이 확보된 종료 UI 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 215. loc_popup_header_quit_game

유형: 추가 ID 덮어쓰기

**현재 영문**

Quit Game

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

게임 종료

수정 이유: 원문이 확보된 종료 UI 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 216. loc_psyker_female_a__enemy_kill_berserker_08

유형: 기존 수정

**현재 영문**

Rager's dead. I prefer his mind that way.

**기존 기본 번역**

레이저가 죽었어. 훨씬 낫네.

**수정 기본 번역**

레이저가 죽었어. 저놈 머릿속은 저 상태가 더 마음에 드는군.

수정 이유: 사이커가 적의 정신을 언급하는 부분 누락 복원

## 217. loc_psyker_female_a__heard_enemy_chaos_spawn_07

유형: 기존 수정

**현재 영문**

I hear a Fleshbag's tortured thoughts!

**기존 기본 번역**

살덩이의 생각이 들려!

**수정 기본 번역**

살덩이의 고통받는 생각이 들려!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 218. loc_psyker_female_a__lore_daemons_three_b_01

유형: 기존 수정

**현재 영문**

Careful, Sibling, we're around small and insignificant minds now. They might think you're ripe for possession.

**기존 기본 번역**

조심해라, 형제여. 작고 하잘 것 없는 마음들이 일어나고 있다. 너는 소유하기에 버겁다고 생각하겠지.

**수정 기본 번역**

조심해라, 형제여. 지금 주위에는 작고 하찮은 정신들뿐이다. 저들은 네가 빙의당하기 딱 좋다고 생각할지도 몰라.

수정 이유: possession을 소유로 옮긴 오류와 발화 주체 수정

## 219. loc_psyker_female_a__lore_hadron_three_a_03

유형: 기존 수정

**현재 영문**

The Tech-Priest orders her thoughts with painful precision.

**기존 기본 번역**

테크프리스트는 그녀의 생각을 고통스러울 정도로 정확하게 명령한다.

**수정 기본 번역**

테크프리스트는 지독할 만큼 정밀하게 생각을 정리하지.

수정 이유: orders her thoughts를 명령으로 옮긴 오류 수정

## 220. loc_psyker_female_a__lore_the_emperor_one_c_02

유형: 기존 수정

**현재 영문**

We're to believe only the Senatorum Imperialis know his inscrutable will. How convenient.

**기존 기본 번역**

우리는 세나토룸 임페리알리스만이 그의 불가해한 유언을 알고 있다고 믿어. 얼마나 편리한지.

**수정 기본 번역**

세나토룸 임페리알리스만이 그분의 불가해한 뜻을 안다고 믿으라는 거지. 참 편리하군.

수정 이유: will을 유언으로 옮긴 오류 수정

## 221. loc_psyker_female_a__lore_the_warp_one_b_02

유형: 기존 수정

**현재 영문**

Be thankful you only have to fear the Warp between missions. For me, the terrors of the Warp are the mission.

**기존 기본 번역**

임무 수행 중 워프만 두려워할 수 있다는 사실에 감사해. 나에겐 워프의 공포가 곧 임무니까.

**수정 기본 번역**

임무 사이에만 워프를 두려워하면 된다는 걸 감사히 여겨. 나에겐 워프의 공포 자체가 임무니까.

수정 이유: between missions를 임무 수행 중으로 옮긴 오류 수정

## 222. loc_psyker_female_a__mission_archives_start_banter_a_02

유형: 기존 수정

**현재 영문**

Oh, you are spoiling us. What a treat this mission has already become ...

**기존 기본 번역**

이러다 얘네들 버릇 나빠지겠어. 벌써 기가 막히게 좋은 임무인 것 같군...

**수정 기본 번역**

이렇게 호강시켜 줘도 되는 거야? 벌써부터 정말 멋진 임무가 됐는걸...

수정 이유: you are spoiling us의 주체와 대상 수정

## 223. loc_psyker_female_a__mission_cargo_end_event_conversation_three_a_01

유형: 기존 수정

**현재 영문**

Are you another indentured servant, Tech Priest, or a willing soldier?

**기존 기본 번역**

너도 망가진 종인가, 테크프리스트? 아니면 충실한 병사인가?

**수정 기본 번역**

너도 얽매여 일하는 종인가, 테크프리스트? 아니면 자원한 병사인가?

수정 이유: indentured와 willing의 대비 복원

## 224. loc_psyker_female_a__mission_propaganda_short_elevator_conversation_one_a_02

유형: 기존 수정

**현재 영문**

A psychic pathogen to go along with the physical? Interesting, but far-fetched.

**기존 기본 번역**

몸도 오염시키는 사이킥 병원체라고? 흥미롭지만, 이건 좀 너무하잖아.

**수정 기본 번역**

물리적 병원체에 사이킥 병원체까지 있다고? 흥미롭지만, 믿기 어려운걸.

수정 이유: 병원체의 병존과 신빙성을 묻는 뜻 복원

## 225. loc_psyker_female_a__mission_station_interrogation_bay_a_02

유형: 기존 수정

**현재 영문**

I find these catechizer posts fascinating. A place where monsters seek monsters, with the innocent caught between.

**기존 기본 번역**

심문은 참 매혹적이야. 괴물이 괴물을 찾는 와중에 수많은 무고한 사람들이 희생되지.

**수정 기본 번역**

이 심문소들은 참 매혹적이야. 괴물이 괴물을 찾는 와중에 무고한 사람들이 끼어드는 곳이지.

수정 이유: catechizer posts가 장소임을 반영

## 226. loc_psyker_female_a__mission_station_mid_event_conversation_two_a_02

유형: 기존 수정

**현재 영문**

Tell me again why we had to grub around in this vile place?

**기존 기본 번역**

왜 우리가 이 끔직한 데를 돌아다녀야 하냐고?

**수정 기본 번역**

왜 우리가 이 끔찍한 데를 돌아다녀야 하냐고?

수정 이유: 맞춤법 수정

## 227. loc_psyker_female_a__mission_strain_atmosphere_shield_01

유형: 기존 수정

**현재 영문**

When that atmospheric shield falls the wind will cut us to pieces ...

**기존 기본 번역**

저 대기 보호막이 무너져서 바람에 흩날리기 시작하면...

**수정 기본 번역**

저 대기 보호막이 무너지면 바람이 우릴 갈기갈기 찢어 놓을 거야...

수정 이유: 보호막 붕괴 시 위험의 대상과 결과 복원

## 228. loc_psyker_female_a__mission_strain_atmosphere_shield_02

유형: 기존 수정

**현재 영문**

Atmospheric shield? Once, perhaps. It's more like a net these days.

**기존 기본 번역**

대기 보호막? 예전에 한 번 봤지. 그때는 그물 같은 모양이었는데.

**수정 기본 번역**

대기 보호막? 한때는 그랬겠지. 지금은 그물에 더 가깝군.

수정 이유: 과거와 현재의 상태를 뒤바꾼 오류 수정

## 229. loc_psyker_female_a__seen_enemy_bulwark_04

유형: 기존 수정

**현재 영문**

Bulwark! Flank it!

**기존 기본 번역**

불워크다! 포위하자!

**수정 기본 번역**

불워크다! 측면을 노려!

수정 이유: 측면 공격 지시를 포위로 옮긴 오류 수정; 영문과 기존 두 모드 번역이 완전히 같은 반복 문구에도 적용

## 230. loc_psyker_female_b__critical_health_09

유형: 기존 수정

**현재 영문**

I need medicae!

**기존 기본 번역**

메디케이가 필요하다!

**수정 기본 번역**

메디카에가 필요하다!

수정 이유: 같은 치료 장치의 명칭 통일

## 231. loc_psyker_female_b__critical_health_10

유형: 기존 수정

**현재 영문**

I think I need medicae…

**기존 기본 번역**

메디케이가 필요한 것 같아...

**수정 기본 번역**

메디카에가 필요한 것 같아...

수정 이유: 같은 치료 장치의 명칭 통일

## 232. loc_psyker_female_b__lore_space_marines_one_b_01

유형: 기존 수정

**현재 영문**

Yes, Beloved, they're talking about the Adeptus Astartes. No, no... the good ones.

**기존 기본 번역**

맞아, 내 사랑, 그들은 아뎁투스 아스타르테스에 대해 이야기하고 있어. 아니, 아니.. 좋은 이야기야.

**수정 기본 번역**

맞아, 내 사랑, 그들은 아뎁투스 아스타르테스에 대해 이야기하고 있어. 아니, 아니... 착한 쪽 말이야.

수정 이유: good ones의 지시 대상을 이야기에서 아스타르테스로 수정

## 233. loc_psyker_female_b__lore_the_emperor_four_c_02

유형: 기존 수정

**현재 영문**

Yes, Beloved, I would very much like to visit you at the Golden Throne.

**기존 기본 번역**

그래, 내 사랑, 황금 옥좌에 당신이 있다면 정말 만나러 갔을 거야.

**수정 기본 번역**

그래, 내 사랑, 황금 옥좌에 있는 당신을 꼭 만나러 가고 싶어.

수정 이유: 방문 희망을 가정 및 과거 시제로 바꾼 오류 수정

## 234. loc_psyker_female_b__lore_the_emperor_three_a_02

유형: 기존 수정

**현재 영문**

Sometimes I share My Beloved's dream... of sacrifices, given unwillingly to the Golden Throne...

**기존 기본 번역**

나는 가끔 내 사랑의 꿈을 공유해... 희생에 대한 꿈, 원치 않는 황금 옥좌의 꿈...

**수정 기본 번역**

나는 가끔 내 사랑의 꿈을 공유해... 황금 옥좌에 강제로 바쳐지는 이들의 꿈을...

수정 이유: 희생이 강요된다는 의미 복원

## 235. loc_psyker_female_b__mission_cooling_production_line_02

유형: 기존 수정

**현재 영문**

My Beloved says that the original Leman Russ drank too much. That feels unkind.

**기존 기본 번역**

내 사랑이 말하길 리만 러스 전차가 술을 너무 많이 마셨다는데. 그래서 상태가 좋지 않대.

**수정 기본 번역**

내 사랑이 그러는데, 원래의 리만 러스는 술을 너무 많이 마셨대. 좀 짓궂은 말인걸.

수정 이유: 전차의 이름이 된 인물을 전차로 혼동한 오류와 평가 문장 수정

## 236. loc_psyker_female_b__mission_deception_01

유형: 기존 수정

**현재 영문**

I don't like cogitators. All that clicking and whirring. They're plotting against us, you know.

**기존 기본 번역**

나는 말장난하는 것을 좋아하지 않아. 딸깍하고 윙윙거리는 소리. 우릴 해치려는 음모를 꾸미고 있어.

**수정 기본 번역**

난 코지테이터가 싫어. 온통 딸깍거리고 윙윙대지. 우릴 해치려는 음모를 꾸미고 있다고.

수정 이유: cogitators를 말장난으로 옮긴 오류 수정

## 237. loc_psyker_female_b__mission_enforcer_end_event_conversation_one_a_02

유형: 기존 수정

**현재 영문**

Echoes upon echoes, and the enforcers the faintest of all.

**기존 기본 번역**

울리는 메아리 속에 인포서의 소리는 들리지 않는군.

**수정 기본 번역**

메아리 위로 메아리가 겹쳐지고, 인포서의 흔적은 그중에서도 가장 희미하군.

수정 이유: 희미하게 남은 흔적을 전혀 없는 것으로 옮긴 오류 수정

## 238. loc_psyker_female_c__ability_protectorate_start_05

유형: 기존 수정

**현재 영문**

Aegis conjured.

**기존 기본 번역**

이지스 요술이다.

**수정 기본 번역**

이지스를 구현했다.

수정 이유: 실드 생성 대사를 요술이라고 옮긴 오류 수정

## 239. loc_psyker_female_c__ability_protectorate_stop_06

유형: 기존 수정

**현재 영문**

Shield's going ...

**기존 기본 번역**

실드가 계속...

**수정 기본 번역**

실드가... 무너진다...

수정 이유: 실드 소멸 경고 누락 복원

## 240. loc_psyker_female_c__ability_venting_05

유형: 기존 수정

**현재 영문**

No hope ... no safety ... only [Pained Grunt]

**기존 기본 번역**

희망이 없고... 안전하지도 않아... 그래도... [고통스러운 신음]

**수정 기본 번역**

희망도... 안전도 없어... 오직... [고통스러운 신음]

수정 이유: only를 그래도로 옮긴 오류 수정

## 241. loc_psyker_female_c__critical_health_08

유형: 기존 수정

**현재 영문**

Requesting medicae!

**기존 기본 번역**

메디케이를 요청한다!

**수정 기본 번역**

메디카에를 요청한다!

수정 이유: 같은 치료 장치의 명칭 통일

## 242. loc_psyker_female_c__critical_health_10

유형: 기존 수정

**현재 영문**

Where is the medicae?

**기존 기본 번역**

메디케이는 어디 있나?

**수정 기본 번역**

메디카에는 어디 있나?

수정 이유: 같은 치료 장치의 명칭 통일

## 243. loc_psyker_female_c__mission_strain_mid_event_conversation_one_c_02

유형: 기존 수정

**현재 영문**

Ah. What a day. What a day.

**기존 기본 번역**

저게 유일한 악마인가? 완전히 퇴치된 건가?

**수정 기본 번역**

아. 참 기막힌 하루군. 기막힌 하루야.

수정 이유: 현재 ID의 영문과 전혀 다른 자막 수정

## 244. loc_psyker_female_c__seen_enemy_shocktrooper_05

유형: 기존 수정

**현재 영문**

We've a Shotgun!

**기존 기본 번역**

우리에게 샷건이 보여.

**수정 기본 번역**

샷거너다!

수정 이유: 적 발견 대사의 어색한 직역 수정

## 245. loc_psyker_male_a__enemy_kill_berserker_08

유형: 기존 수정

**현재 영문**

Rager's dead. I prefer his mind that way.

**기존 기본 번역**

레이저가 죽었어. 훨씬 낫네.

**수정 기본 번역**

레이저가 죽었어. 저놈 머릿속은 저 상태가 더 마음에 드는군.

수정 이유: 사이커가 적의 정신을 언급하는 부분 누락 복원; 영문과 기존 두 모드 번역이 완전히 같은 반복 문구에도 적용

## 246. loc_psyker_male_a__heard_enemy_chaos_spawn_01

유형: 기존 수정

**현재 영문**

Rotbag!

**기존 기본 번역**

살덩이다!

**수정 기본 번역**

부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 247. loc_psyker_male_a__heard_enemy_chaos_spawn_02

유형: 기존 수정

**현재 영문**

It's a Rotbag!

**기존 기본 번역**

살덩이다!

**수정 기본 번역**

부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 248. loc_psyker_male_a__heard_enemy_chaos_spawn_04

유형: 기존 수정

**현재 영문**

Rotbag… I think!

**기존 기본 번역**

살덩이인 것 같아!

**수정 기본 번역**

부패덩어리인 것 같아!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 249. loc_psyker_male_a__heard_enemy_chaos_spawn_07

유형: 기존 수정

**현재 영문**

I hear a Rotbag's tortured thoughts!

**기존 기본 번역**

살덩이의 생각이 들려!

**수정 기본 번역**

부패덩어리의 고통받는 생각이 들려!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 250. loc_psyker_male_a__heard_enemy_chaos_spawn_08

유형: 기존 수정

**현재 영문**

Rotbag! I feel its thoughts!

**기존 기본 번역**

살덩이! 생각이 느껴져!

**수정 기본 번역**

부패덩어리! 생각이 느껴져!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 251. loc_psyker_male_a__heard_enemy_chaos_spawn_09

유형: 기존 수정

**현재 영문**

A Rotbag! Coming closer!

**기존 기본 번역**

살덩이! 가까이 오고 있어!

**수정 기본 번역**

부패덩어리! 가까이 오고 있어!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 252. loc_psyker_male_a__heard_enemy_chaos_spawn_10

유형: 기존 수정

**현재 영문**

Rotbag… Its torment is deafening!

**기존 기본 번역**

살덩이... 귀가 먹을 듯한 고통의 소리야.

**수정 기본 번역**

부패덩어리... 귀가 먹을 듯한 고통의 소리야.

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 253. loc_psyker_male_a__lore_daemons_three_b_01

유형: 기존 수정

**현재 영문**

Careful, Sibling, we're around small and insignificant minds now. They might think you're ripe for possession.

**기존 기본 번역**

조심해라, 형제여. 작고 하잘 것 없는 마음들이 일어나고 있다. 너는 소유하기에 버겁다고 생각하겠지.

**수정 기본 번역**

조심해라, 형제여. 지금 주위에는 작고 하찮은 정신들뿐이다. 저들은 네가 빙의당하기 딱 좋다고 생각할지도 몰라.

수정 이유: possession을 소유로 옮긴 오류와 발화 주체 수정

## 254. loc_psyker_male_a__lore_hadron_three_a_03

유형: 기존 수정

**현재 영문**

The Tech-Priest orders her thoughts with painful precision.

**기존 기본 번역**

테크프리스트는 그녀의 생각을 고통스러울 정도로 정확하게 명령한다.

**수정 기본 번역**

테크프리스트는 지독할 만큼 정밀하게 생각을 정리하지.

수정 이유: orders her thoughts를 명령으로 옮긴 오류 수정

## 255. loc_psyker_male_a__lore_the_emperor_one_c_02

유형: 기존 수정

**현재 영문**

We're to believe only the Senatorum Imperialis know his inscrutable will. How convenient.

**기존 기본 번역**

우리는 세나토룸 임페리알리스만이 그의 불가해한 유언을 알고 있다고 믿어. 얼마나 편리한지.

**수정 기본 번역**

세나토룸 임페리알리스만이 그분의 불가해한 뜻을 안다고 믿으라는 거지. 참 편리하군.

수정 이유: will을 유언으로 옮긴 오류 수정

## 256. loc_psyker_male_a__lore_the_warp_one_b_02

유형: 기존 수정

**현재 영문**

Be thankful you only have to fear the Warp between missions. For me, the terrors of the Warp are the mission.

**기존 기본 번역**

임무 수행 중 워프만 두려워할 수 있다는 사실에 감사해. 나에겐 워프의 공포가 곧 임무니까.

**수정 기본 번역**

임무 사이에만 워프를 두려워하면 된다는 걸 감사히 여겨. 나에겐 워프의 공포 자체가 임무니까.

수정 이유: between missions를 임무 수행 중으로 옮긴 오류 수정

## 257. loc_psyker_male_a__mission_archives_start_banter_a_02

유형: 기존 수정

**현재 영문**

Oh, you are spoiling us. What a treat this mission has already become ...

**기존 기본 번역**

이러다 얘네들 버릇 나빠지겠어. 벌써 기가 막히게 좋은 임무인 것 같군...

**수정 기본 번역**

이렇게 호강시켜 줘도 되는 거야? 벌써부터 정말 멋진 임무가 됐는걸...

수정 이유: you are spoiling us의 주체와 대상 수정

## 258. loc_psyker_male_a__mission_cargo_end_event_conversation_three_a_01

유형: 기존 수정

**현재 영문**

Are you another indentured servant, Tech Priest, or a willing soldier?

**기존 기본 번역**

너도 망가진 종인가, 테크프리스트? 아니면 충실한 병사인가?

**수정 기본 번역**

너도 얽매여 일하는 종인가, 테크프리스트? 아니면 자원한 병사인가?

수정 이유: indentured와 willing의 대비 복원

## 259. loc_psyker_male_a__mission_propaganda_short_elevator_conversation_one_a_02

유형: 기존 수정

**현재 영문**

A psychic pathogen to go along with the physical? Interesting, but far-fetched.

**기존 기본 번역**

몸도 오염시키는 사이킥 병원체라고? 흥미롭지만, 이건 좀 너무하잖아.

**수정 기본 번역**

물리적 병원체에 사이킥 병원체까지 있다고? 흥미롭지만, 믿기 어려운걸.

수정 이유: 병원체의 병존과 신빙성을 묻는 뜻 복원

## 260. loc_psyker_male_a__mission_station_interrogation_bay_a_02

유형: 기존 수정

**현재 영문**

I find these catechizer posts fascinating. A place where monsters seek monsters, with the innocent caught between.

**기존 기본 번역**

심문은 참 매혹적이야. 괴물이 괴물을 찾는 와중에 수많은 무고한 사람들이 희생되지.

**수정 기본 번역**

이 심문소들은 참 매혹적이야. 괴물이 괴물을 찾는 와중에 무고한 사람들이 끼어드는 곳이지.

수정 이유: catechizer posts가 장소임을 반영

## 261. loc_psyker_male_a__mission_station_mid_event_conversation_two_a_02

유형: 기존 수정

**현재 영문**

Tell me again why we had to grub around in this vile place?

**기존 기본 번역**

왜 우리가 이 끔직한 데를 돌아다녀야 하냐고?

**수정 기본 번역**

왜 우리가 이 끔찍한 데를 돌아다녀야 하냐고?

수정 이유: 맞춤법 수정

## 262. loc_psyker_male_a__mission_strain_atmosphere_shield_01

유형: 기존 수정

**현재 영문**

When that atmospheric shield falls the wind will cut us to pieces ...

**기존 기본 번역**

저 대기 보호막이 무너져서 바람에 흩날리기 시작하면...

**수정 기본 번역**

저 대기 보호막이 무너지면 바람이 우릴 갈기갈기 찢어 놓을 거야...

수정 이유: 보호막 붕괴 시 위험의 대상과 결과 복원

## 263. loc_psyker_male_a__mission_strain_atmosphere_shield_02

유형: 기존 수정

**현재 영문**

Atmospheric shield? Once, perhaps. It's more like a net these days.

**기존 기본 번역**

대기 보호막? 예전에 한 번 봤지. 그때는 그물 같은 모양이었는데.

**수정 기본 번역**

대기 보호막? 한때는 그랬겠지. 지금은 그물에 더 가깝군.

수정 이유: 과거와 현재의 상태를 뒤바꾼 오류 수정

## 264. loc_psyker_male_a__player_tip_armor_hit_generic_06

유형: 기존 수정

**현재 영문**

Yes, hit the armour. That will work.

**기존 기본 번역**

그래, 방어구에 쏴. 총알이 잘 박히냐?

**수정 기본 번역**

그래, 방어구를 때려. 참 잘하는 짓이다.

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 265. loc_psyker_male_a__player_tip_armor_hit_generic_07

유형: 기존 수정

**현재 영문**

Of course! Waste effort on armour…

**기존 기본 번역**

그럼 그럼! 방어구에 탄약 낭비하고 있네...

**수정 기본 번역**

그럼 그럼! 방어구에 대고 열심히 헛수고하고 있네…

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 266. loc_psyker_male_a__seen_enemy_bulwark_04

유형: 기존 수정

**현재 영문**

Bulwark! Flank it!

**기존 기본 번역**

불워크다! 포위하자!

**수정 기본 번역**

불워크다! 측면을 노려!

수정 이유: 측면 공격 지시를 포위로 옮긴 오류 수정

## 267. loc_psyker_male_a__seen_enemy_grenadier_10

유형: 기존 수정

**현재 영문**

Bomber! Big gun, tiny mind!

**기존 기본 번역**

보머다!

**수정 기본 번역**

보머다! 총은 크고 머릿속은 텅 비었군!

수정 이유: 생략된 후반 대사 복원

## 268. loc_psyker_male_b__critical_health_09

유형: 기존 수정

**현재 영문**

I need medicae!

**기존 기본 번역**

메디케이가 필요하다!

**수정 기본 번역**

메디카에가 필요하다!

수정 이유: 같은 치료 장치의 명칭 통일

## 269. loc_psyker_male_b__critical_health_10

유형: 기존 수정

**현재 영문**

I think I need medicae…

**기존 기본 번역**

메디케이가 필요한 것 같아...

**수정 기본 번역**

메디카에가 필요한 것 같아...

수정 이유: 같은 치료 장치의 명칭 통일

## 270. loc_psyker_male_b__heard_enemy_chaos_spawn_01

유형: 기존 수정

**현재 영문**

Rotbag!

**기존 기본 번역**

살덩이다!

**수정 기본 번역**

부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 271. loc_psyker_male_b__heard_enemy_chaos_spawn_02

유형: 기존 수정

**현재 영문**

It's a Rotbag!

**기존 기본 번역**

살덩이다!

**수정 기본 번역**

부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 272. loc_psyker_male_b__heard_enemy_chaos_spawn_03

유형: 기존 수정

**현재 영문**

Look out! Rotbag!

**기존 기본 번역**

조심해! 살덩이다!

**수정 기본 번역**

조심해! 부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 273. loc_psyker_male_b__heard_enemy_chaos_spawn_04

유형: 기존 수정

**현재 영문**

Oh no. Rotbag.

**기존 기본 번역**

이런, 살덩이야!

**수정 기본 번역**

이런, 부패덩어리야!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 274. loc_psyker_male_b__heard_enemy_chaos_spawn_05

유형: 기존 수정

**현재 영문**

Rotbag!

**기존 기본 번역**

쟤도 봤을 거야.

**수정 기본 번역**

부패덩어리다!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 275. loc_psyker_male_b__heard_enemy_chaos_spawn_07

유형: 기존 수정

**현재 영문**

I hear a Rotbag!

**기존 기본 번역**

살덩이 소리가 들려!

**수정 기본 번역**

부패덩어리 소리가 들려!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 276. loc_psyker_male_b__lore_space_marines_one_b_01

유형: 기존 수정

**현재 영문**

Yes, Beloved, they're talking about the Adeptus Astartes. No, no... the good ones.

**기존 기본 번역**

맞아, 내 사랑, 그들은 아뎁투스 아스타르테스에 대해 이야기하고 있어. 아니, 아니.. 좋은 이야기야.

**수정 기본 번역**

맞아, 내 사랑, 그들은 아뎁투스 아스타르테스에 대해 이야기하고 있어. 아니, 아니... 착한 쪽 말이야.

수정 이유: good ones의 지시 대상을 이야기에서 아스타르테스로 수정

## 277. loc_psyker_male_b__lore_the_emperor_four_c_02

유형: 기존 수정

**현재 영문**

Yes, Beloved, I would very much like to visit you at the Golden Throne.

**기존 기본 번역**

그래, 내 사랑, 황금 옥좌에 당신이 있다면 정말 만나러 갔을 거야.

**수정 기본 번역**

그래, 내 사랑, 황금 옥좌에 있는 당신을 꼭 만나러 가고 싶어.

수정 이유: 방문 희망을 가정 및 과거 시제로 바꾼 오류 수정

## 278. loc_psyker_male_b__lore_the_emperor_three_a_02

유형: 기존 수정

**현재 영문**

Sometimes I share My Beloved's dream... of sacrifices, given unwillingly to the Golden Throne...

**기존 기본 번역**

나는 가끔 내 사랑의 꿈을 공유해... 희생에 대한 꿈, 원치 않는 황금 옥좌의 꿈...

**수정 기본 번역**

나는 가끔 내 사랑의 꿈을 공유해... 황금 옥좌에 강제로 바쳐지는 이들의 꿈을...

수정 이유: 희생이 강요된다는 의미 복원

## 279. loc_psyker_male_b__mission_cooling_production_line_02

유형: 기존 수정

**현재 영문**

My Beloved says that the original Leman Russ drank too much. That feels unkind.

**기존 기본 번역**

내 사랑이 말하길 리만 러스 전차가 술을 너무 많이 마셨다는데. 그래서 상태가 좋지 않대.

**수정 기본 번역**

내 사랑이 그러는데, 원래의 리만 러스는 술을 너무 많이 마셨대. 좀 짓궂은 말인걸.

수정 이유: 전차의 이름이 된 인물을 전차로 혼동한 오류와 평가 문장 수정

## 280. loc_psyker_male_b__mission_deception_01

유형: 기존 수정

**현재 영문**

I don't like cogitators. All that clicking and whirring. They're plotting against us, you know.

**기존 기본 번역**

나는 말장난하는 것을 좋아하지 않아. 딸깍하고 윙윙거리는 소리. 우릴 해치려는 음모를 꾸미고 있어.

**수정 기본 번역**

난 코지테이터가 싫어. 온통 딸깍거리고 윙윙대지. 우릴 해치려는 음모를 꾸미고 있다고.

수정 이유: cogitators를 말장난으로 옮긴 오류 수정

## 281. loc_psyker_male_b__mission_enforcer_end_event_conversation_one_a_02

유형: 기존 수정

**현재 영문**

Echoes upon echoes, and the enforcers the faintest of all.

**기존 기본 번역**

울리는 메아리 속에 인포서의 소리는 들리지 않는군.

**수정 기본 번역**

메아리 위로 메아리가 겹쳐지고, 인포서의 흔적은 그중에서도 가장 희미하군.

수정 이유: 희미하게 남은 흔적을 전혀 없는 것으로 옮긴 오류 수정

## 282. loc_psyker_male_c__ability_protectorate_start_05

유형: 기존 수정

**현재 영문**

Aegis conjured.

**기존 기본 번역**

이지스 요술이다.

**수정 기본 번역**

이지스를 구현했다.

수정 이유: 실드 생성 대사를 요술이라고 옮긴 오류 수정

## 283. loc_psyker_male_c__ability_protectorate_stop_06

유형: 기존 수정

**현재 영문**

Shield's going ...

**기존 기본 번역**

실드가 계속...

**수정 기본 번역**

실드가... 무너진다...

수정 이유: 실드 소멸 경고 누락 복원

## 284. loc_psyker_male_c__ability_venting_05

유형: 기존 수정

**현재 영문**

No hope ... no safety ... only [Pained Grunt]

**기존 기본 번역**

희망이 없고... 안전하지도 않아... 그래도... [고통스러운 신음]

**수정 기본 번역**

희망도... 안전도 없어... 오직... [고통스러운 신음]

수정 이유: only를 그래도로 옮긴 오류 수정

## 285. loc_psyker_male_c__critical_health_08

유형: 기존 수정

**현재 영문**

Requesting medicae!

**기존 기본 번역**

메디케이를 요청한다!

**수정 기본 번역**

메디카에를 요청한다!

수정 이유: 같은 치료 장치의 명칭 통일

## 286. loc_psyker_male_c__critical_health_10

유형: 기존 수정

**현재 영문**

Where is the medicae?

**기존 기본 번역**

메디케이는 어디 있나?

**수정 기본 번역**

메디카에는 어디 있나?

수정 이유: 같은 치료 장치의 명칭 통일

## 287. loc_psyker_male_c__mission_strain_mid_event_conversation_one_c_02

유형: 기존 수정

**현재 영문**

Ah. What a day. What a day.

**기존 기본 번역**

저게 유일한 악마인가? 완전히 퇴치된 건가?

**수정 기본 번역**

아. 참 기막힌 하루군. 기막힌 하루야.

수정 이유: 현재 ID의 영문과 전혀 다른 자막 수정

## 288. loc_psyker_male_c__seen_enemy_shocktrooper_05

유형: 기존 수정

**현재 영문**

We've a Shotgun!

**기존 기본 번역**

우리에게 샷건이 보여.

**수정 기본 번역**

샷거너다!

수정 이유: 적 발견 대사의 어색한 직역 수정

## 289. loc_purser_a__hub_idle_2nd_phase_conversation_fifteen_b_01

유형: 기존 수정

**현재 영문**

Sorry my darling, no can do. They're all on high priority, need-to-know assignments.

**기존 기본 번역**

미안하지만 자기, 안 돼. 모두 우선순위가 높고, 꼭 해결해야 하는 임무들이라서.

**수정 기본 번역**

미안하지만 자기, 안 돼. 다들 우선순위가 높고 정보가 제한된 임무 중이야.

수정 이유: need-to-know를 필요성으로 옮긴 오류 수정

## 290. loc_purser_a__hub_idle_2nd_phase_conversation_fourteen_b_01

유형: 기존 수정

**현재 영문**

Think nothing of it. Happy to help ... as long as the aquilas keep flowing.

**기존 기본 번역**

아무 생각하지 마. 도와줄 수 있어서 기뻐. 아퀼라가 계속 흐르기만 한다면.

**수정 기본 번역**

신경 쓰지 마. 도와줄 수 있어 기쁘니까… 아퀼라만 계속 들어온다면 말이지.

수정 이유: Think nothing of it 관용구 수정

## 291. loc_purser_a__hub_idle_2nd_phase_conversation_twentytwo_a_01

유형: 기존 수정

**현재 영문**

Zola? I've had some special issue gear come in. Though I'd give you first refusal.

**기존 기본 번역**

졸라? 나는 특별 문제 장비를 들여왔는데. 우선 구입권을 줄게.

**수정 기본 번역**

졸라? 나는 특별 지급 장비를 들여왔는데. 우선 구입권을 줄게.

수정 이유: special issue를 문제로 옮긴 오류 수정

## 292. loc_purser_a__hub_idle_2nd_phase_conversation_two_b_01

유형: 기존 수정

**현재 영문**

I'll be there, little man ... In my own good time.

**기존 기본 번역**

갈게, 꼬마야... 좋은 시간 보내고 있었는데.

**수정 기본 번역**

갈게, 꼬마야... 내가 내킬 때 말이야.

수정 이유: in my own good time 관용 표현 수정

## 293. loc_sergeant_a__cmd_load_coolant_03

유형: 기존 수정

**현재 영문**

Won't do any good in your sweaty meathooks! Get it in place!

**기존 기본 번역**

땀에 쩔어있는 네 손모가지는 아무런 도움이 안돼! 제자리에 갖다 넣어!

**수정 기본 번역**

땀범벅인 네 손에 들고 있어 봐야 소용없어! 제자리에 갖다 넣어!

수정 이유: 들고만 있는 물체가 쓸모없다는 뜻 복원

## 294. loc_sergeant_a__hammersmith_hub_announcement_09_a_01

유형: 추가 ID 덮어쓰기

**현재 영문**

Sir? You wanted to look over the plans for Slab Zone 79?

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

심문관님? 슬랩 구역 79의 계획을 검토하시겠다고 하셨습니까?

수정 이유: 09_a 모로우와 09_b 라닉의 대화 쌍을 대조한 추가 대사 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 295. loc_sergeant_a__hub_idle_2nd_phase_conversation_one_a_01

유형: 기존 수정

**현재 영문**

Commodore, do you mind not fleecing my no-hopers? It's bad for morale.

**기존 기본 번역**

준장, 희망없는 자들을 빼돌리지 말아주겠나? 사기에 좋지 않아.

**수정 기본 번역**

준장, 내 희망 없는 녀석들한테 바가지 좀 그만 씌워주겠나? 사기에 좋지 않다고.

수정 이유: fleecing을 사람 빼돌리기로 옮긴 오류 수정

## 296. loc_sergeant_a__hub_idle_2nd_phase_conversation_thirtyfour_a_01

유형: 기존 수정

**현재 영문**

Tech-priest, can't you do something about this vox? I can barely make anything out.

**기존 기본 번역**

테크프리스트, 이 복스를 어떻게 좀 해주지 않겠나? 거의 아무것도 할 수가 없어.

**수정 기본 번역**

테크프리스트, 이 복스 좀 어떻게 해줄 수 없나? 거의 알아들을 수가 없어.

수정 이유: make out의 청취 의미 복원

## 297. loc_sergeant_a__hub_idle_2nd_phase_conversation_thirtyseven_b_01

유형: 기존 수정

**현재 영문**

Can't say I'm surprised, but don't ask doesn't get.

**기존 기본 번역**

놀랐다고 말할 수는 없지만, 묻지 마.

**수정 기본 번역**

놀랍진 않군. 그래도 물어보지 않으면 얻는 것도 없지.

수정 이유: don't ask doesn't get의 뜻 복원

## 298. loc_sergeant_a__info_mission_cooling_demolish_01

유형: 기존 수정

**현재 영문**

Right, you'll have to blast your way in. Set a demo pack and get clear!

**기존 기본 번역**

좋아, 이제 폭파시켜서 들어가야 해. 철거용 폭탄을 설치하고 터뜨려!

**수정 기본 번역**

좋아, 폭파해서 들어가야겠군. 철거용 폭탄을 설치하고 물러서!

수정 이유: get clear의 안전거리 확보 지시 복원

## 299. loc_sergeant_a__level_hab_block_roof_03

유형: 기존 수정

**현재 영문**

The side of the hab blocks few get to see, eh?

**기존 기본 번역**

거주 구역의 측면은 거의 보이지 않지?

**수정 기본 번역**

거주 구역의 이런 모습은 좀처럼 보기 힘들지, 안 그래?

수정 이유: few get to see의 대상이 장소 측면이 아니라 드문 모습임을 반영

## 300. loc_sergeant_a__mission_archives_deep_archives_b_02

유형: 기존 수정

**현재 영문**

You finally reached the Deep Archives did you? About time.

**기존 기본 번역**

마침내 딥 아카이브에 도착했군. 시간도 딱 맞췄다.

**수정 기본 번역**

드디어 딥 아카이브에 도착했나? 진작 그랬어야지.

수정 이유: About time을 제시간 도착이라는 칭찬으로 옮긴 오류 수정

## 301. loc_sergeant_a__mission_cartel_elevator_access_03

유형: 기존 수정

**현재 영문**

About time! But I've reconstructed the cypher-ident. Crypt-key updated - head to the elevator.

**기존 기본 번역**

시간 다 됐다! 하지만 내가 암호 인식기를 재구성해냈지. 암호키 업데이트됨 - 엘리베이터로 향해라.

**수정 기본 번역**

이제야 됐군! 암호 인식기를 재구성했다. 암호키 업데이트 완료. 엘리베이터로 가라.

수정 이유: About time을 시간 만료로 옮긴 오류 수정

## 302. loc_sergeant_a__mission_cartel_keep_moving_02

유형: 기존 수정

**현재 영문**

You're making good time. Just a little further until you're past the shanty town.

**기존 기본 번역**

좋은 시간 보내고 있군. 판자촌을 지날 때까지 조금만 더 가면 돼.

**수정 기본 번역**

제법 빠르게 가고 있군. 조금만 더 가면 판자촌을 벗어난다.

수정 이유: making good time을 즐거운 시간으로 옮긴 오류 수정

## 303. loc_sergeant_a__mission_cartel_pillar_01

유형: 기존 수정

**현재 영문**

These stairways were built for maintenance. As you can see, they've been pressed to other things.

**기존 기본 번역**

이 계단은 유지보수를 위해 만들어졌지. 보다시피, 다른 것에 밀려 있었어.

**수정 기본 번역**

이 계단은 정비용으로 만들어졌지. 보다시피 지금은 다른 용도로 쓰이고 있지만.

수정 이유: pressed to other things를 우선순위에서 밀림으로 옮긴 오류 수정

## 304. loc_sergeant_a__mission_cartel_pillar_03

유형: 기존 수정

**현재 영문**

Got to admire the ingenuity of folk who'll make a home anywhere. Rather them than me.

**기존 기본 번역**

어디든 가정을 꾸릴 수 있는 사람들의 독창성에 감탄하게 되는군. 오히려 나보다 저들이 더 나은 거 같아.

**수정 기본 번역**

어디든 집으로 만드는 저 독창성은 인정해야겠군. 그래도 내가 저렇게 살고 싶진 않아.

수정 이유: Rather them than me를 상대 능력에 대한 칭찬으로 옮긴 오류 수정

## 305. loc_sergeant_a__mission_cartel_upload_01

유형: 기존 수정

**현재 영문**

Right! Now punch that bad intel into the heart of the cogitator array.

**기존 기본 번역**

좋아! 이제 겁쟁이들의 코지테이터 배열에 허위 정보를 심어주라고.

**수정 기본 번역**

좋아! 이제 코지테이터 배열의 핵심부에 허위 정보를 집어넣어!

수정 이유: heart of를 오역해 추가된 겁쟁이 표현 제거

## 306. loc_sergeant_a__mission_complex_brief_b_04

유형: 기존 수정

**현재 영문**

There's a comms-plex dish on Tertium that should do the job. Don't ask why the Mourningstar can't. You're not cleared.

**기존 기본 번역**

테르티움에는 이 일에 적합한 통신 시설 안테나가 있어. 모어닝스타에서는 왜 못하는지 물어보지 마. 아직 너희 혐의는 유효하니까.

**수정 기본 번역**

테르티움에 이 일을 해낼 통신 시설 안테나가 있다. 모어닝스타에서 왜 못 하는지는 묻지 마. 너희에게는 그 정보를 알 권한이 없다.

수정 이유: 정보 접근 허가를 범죄 혐의 해소로 옮긴 오류 수정

## 307. loc_sergeant_a__mission_complex_brief_c_04

유형: 기존 수정

**현재 영문**

You'll be heading into Archivum Sycorax in Throneside. Intel says their dish is still functional, and it has the oomph we need.

**기존 기본 번역**

너희는 스론사이드에 있는 아르키붐 시코락스로 보내질 거야. 정보원 말로는 안테나가 아직 쓸 만 하고, 우리에게 꼭 필요한 매력이 있다더군.

**수정 기본 번역**

스론사이드의 아르키붐 시코락스로 갈 거다. 정보에 따르면 그곳 안테나는 아직 작동하고, 우리에게 필요한 출력도 갖추고 있어.

수정 이유: oomph를 매력으로 옮긴 오류 수정

## 308. loc_sergeant_a__mission_complex_transmitter_03

유형: 기존 수정

**현재 영문**

Transmission can't begin until you get that dish aligned. Break out the data-interrogators!

**기존 기본 번역**

안테나를 연동시키기 전까진 전송을 시작할 수 없어! 데이터 탐색 장치로 시작해!

**수정 기본 번역**

안테나 방향을 맞춰야 전송을 시작할 수 있어! 데이터 탐색 장치를 꺼내!

수정 이유: 안테나 정렬을 기기 연동으로 옮긴 오류 수정

## 309. loc_sergeant_a__mission_cooling_briefing_three_02

유형: 기존 수정

**현재 영문**

Cryonic rods can flush the system. You'll find some in the control room. They're strictly for emergencies, but I reckon this qualifies, don't you?

**기존 기본 번역**

냉각봉으로 시스템을 가동할 수 있어. 제어실로 가면 좀 있을 거다. 비상용이지만, 지금은 비상 사태니까. 그렇지?

**수정 기본 번역**

냉각봉으로 시스템을 세척할 수 있어. 제어실로 가면 좀 있을 거다. 비상용이지만, 지금은 비상 사태니까. 그렇지?

수정 이유: flush의 기술적 의미 반영

## 310. loc_sergeant_a__mission_cooling_first_objective_01

유형: 기존 수정

**현재 영문**

You need to get your backsides over to the control chamber and grab those cryonic rods.

**기존 기본 번역**

제어실 뒤로 가서 냉각봉을 찾아야 해.

**수정 기본 번역**

어서 제어실로 가서 냉각봉을 챙겨.

수정 이유: get your backsides over를 제어실 뒤로 이동하는 것으로 옮긴 오류 수정

## 311. loc_sergeant_a__mission_forge_briefing_c_03

유형: 기존 수정

**현재 영문**

We badly need HL-17-36's Leman Russ battle tanks on the front lines, so take no chances.

**기존 기본 번역**

최전선에는 HL-17-36의 리만 러스 전차가 절실히 필요하니까, 이 기회를 놓치지 마라.

**수정 기본 번역**

최전선에는 HL-17-36의 리만 러스 전차가 절실하니, 위험을 감수하지 마라.

수정 이유: take no chances를 기회를 놓치지 말라는 뜻으로 옮긴 오류 수정

## 312. loc_sergeant_a__mission_forge_briefing_c_04

유형: 기존 수정

**현재 영문**

We can't have too many Leman Russ battle tanks, so get HL-17-36 back in working order, ASAP.

**기존 기본 번역**

리만 러스 전차가 너무 많아지면 안 된다. 최대한 빨리 HL-17-36을 다시 가동시키도록.

**수정 기본 번역**

리만 러스 전차는 많을수록 좋지. 그러니 최대한 빨리 HL-17-36을 다시 가동시켜라.

수정 이유: can't have too many를 과잉 금지라는 반대 의미로 옮긴 오류 수정

## 313. loc_sergeant_a__mission_raid_den_hurry_a_03

유형: 기존 수정

**현재 영문**

Sorry about the pace, sir. They're really milking this mission.

**기존 기본 번역**

진행 속도에 대해선 죄송합니다, 심문관님. 녀석들은 이 임무를 정말 열심히 하고 있습니다.

**수정 기본 번역**

진행이 늦어 죄송합니다, 심문관님. 녀석들이 이번 임무를 아주 질질 끌고 있군요.

수정 이유: milking을 노력에 대한 칭찬으로 옮긴 오류 수정

## 314. loc_sergeant_a__mission_raid_production_habs_hurry_02_b_01

유형: 기존 수정

**현재 영문**

Don't needle the strike team, sir. You'll make me redundant.

**기존 기본 번역**

스트라이크 팀을 너무 야단치지 마십시오. 제가 야단칠 참이었습니다.

**수정 기본 번역**

스트라이크 팀을 너무 들볶지 마십시오, 심문관님. 제 일자리가 없어지겠습니다.

수정 이유: make redundant의 농담 의미 복원

## 315. loc_sergeant_a__mission_rise_banter_three_a_04

유형: 기존 수정

**현재 영문**

Get your idle feet moving! The Emperor's watching you, and so am I! Between you and me, I'm the one you want to worry about.

**기존 기본 번역**

어서 움직여! 황제 폐하께서 너희를 지켜보신다. 나도 지켜보고 있고! 우리끼리 하는 얘긴데, 사실 너희가 걱정해야 할 건 내가 아니라고.

**수정 기본 번역**

어서 움직여! 황제 폐하께서 보고 계신다. 나도 보고 있고! 우리끼리 하는 말인데, 너희가 걱정해야 할 쪽은 나야.

수정 이유: 위협의 대상을 반대로 옮긴 오류 수정

## 316. loc_sergeant_a__mission_station_start_banter_b_02

유형: 기존 수정

**현재 영문**

This sector's in the balance. All we can do is hold ground. At least for now.

**기존 기본 번역**

이 구역은 어느 정도 균형이 잡힌 상태야. 일단은 위치 사수만 하면 되니까.

**수정 기본 번역**

이 구역의 운명은 아직 불확실해. 적어도 지금은 위치를 사수하는 수밖에 없어.

수정 이유: in the balance를 안정된 균형 상태로 옮긴 오류 수정

## 317. loc_sergeant_a__mission_station_tanks_04

유형: 기존 수정

**현재 영문**

What a Leman Russ Demolisher lacks in range, it makes up for in firepower. It's a beauty, and no mistake.

**기존 기본 번역**

리만 러스 데몰리셔는 사거리는 짧지만, 화력이 강하다. 절대 실수하지 않는 아름다운 녀석이지.

**수정 기본 번역**

리만 러스 데몰리셔는 짧은 사거리를 화력으로 보완하지. 두말할 나위 없이 멋진 녀석이야.

수정 이유: and no mistake를 장비의 무오류 성능으로 옮긴 오류 수정

## 318. loc_sergeant_b__mission_armoury_low_profile_a_04

유형: 기존 수정

**현재 영문**

I wish you lot'd make less noise. Serves me right for not leaving this to an Auric strike team.

**기존 기본 번역**

너희들이 좀 덜 시끄러웠으면 한다. 금빛 스트라이크 팀에게 이 일을 맡기지 않은 게 잘한 일인 것 같군.

**수정 기본 번역**

너희 좀 조용히 다니면 안 되나. 금빛 스트라이크 팀에 맡기지 않은 내 탓이지.

수정 이유: Serves me right 후회를 정반대 평가로 옮긴 오류 수정

## 319. loc_sergeant_b__mission_armoury_rooftops_a_02

유형: 기존 수정

**현재 영문**

Let's do this quiet - or as quiet as you lot can manage. No need to wake the district. Hadron's managed to breach the vox array, so maybe we--

**기존 기본 번역**

조용히 처리하자고. 너희가 할 수 있는 수준에서 최대한 조용하게. 온 동네를 깨울 필요 없잖아. 하드론이 복스 배열 해킹 툴을 만들었으니, 어쩌면 우리...

**수정 기본 번역**

조용히 처리하자고. 너희가 할 수 있는 만큼만이라도. 온 구역을 깨울 필요는 없지. 하드론이 복스 배열에 침투했으니, 어쩌면 우리가--

수정 이유: 이미 완료한 침투를 해킹 도구 제작으로 옮긴 오류 수정

## 320. loc_sergeant_b__mission_habs_redux_poison_complete_a_01

유형: 기존 수정

**현재 영문**

Revolting. Probably won't put it out of commission for long, but it'll buy us time. Get out before you're overrun!

**기존 기본 번역**

역겹군. 아마 금방 사라지겠지만, 그래도 충분한 시간은 벌어줄 거야. 밀려들어오기 전에 어서 나가!

**수정 기본 번역**

역겹군. 오래 무력화하지는 못하겠지만, 그래도 시간을 벌어줄 거야. 적에게 압도당하기 전에 나와!

수정 이유: 무력화 효과의 지속시간 의미를 명확히 함

## 321. loc_sergeant_b__mission_station_tanks_a_01

유형: 기존 수정

**현재 영문**

Having some vox trouble here. Bear with me.

**기존 기본 번역**

맙소사, 제발 복스 좀 고치라고. 이게 그렇게 힘든가?

**수정 기본 번역**

복스에 문제가 좀 있군. 잠시 기다려 줘.

수정 이유: 현재 원문과 다른 대사 수정

## 322. loc_setting_keybinding_press_new_button

유형: 기존 수정

**현재 영문**

Press the new button for this action or {#color(226,199,126)}{cancel_input:%s}{#reset()} to cancel.

**기존 기본 번역**

이 행동을 수행하려면 새 버튼을 누르거나 또는 {cancel_input:%s}로 취소하세요.

**수정 기본 번역**

이 행동에 지정할 새 버튼을 누르세요. 취소하려면 {#color(226,199,126)}{cancel_input:%s}{#reset()}를 누르세요.

수정 이유: 키 지정 안내를 행동 실행 안내로 옮긴 오류 수정

## 323. loc_shipmistress_a__shipmistress_hub_announcement_a_17_b_01

유형: 기존 수정

**현재 영문**

Additional blast-wadding is required in Section Grax 15/v. Please report suitable candidates to Voidmaster Rex.

**기존 기본 번역**

그랙스 15/v 구역에 추가 폭발 충전재가 필요하다. 자원자는 보이드마스터 렉스에게 보고하도록.

**수정 기본 번역**

그랙스 15/v 구역에 추가 폭발 완충재가 필요하다. 적합한 후보가 있으면 보이드마스터 렉스에게 보고하도록.

수정 이유: 원문에 없는 자원자 한정을 제거하고 인간을 완충재에 빗댄 위협 보존

## 324. loc_shipmistress_a__shipmistress_hub_announcement_a_29_a_01

유형: 기존 수정

**현재 영문**

Lady Alice... I have matters requiring your attention. Assuming you've had your fill of slumming it down there?

**기존 기본 번역**

앨리스... 당신이 좀 봐줘야 할 일이 있어. 밑에서 다른 녀석 고문하는 일이 끝났다면 말이지.

**수정 기본 번역**

앨리스... 당신이 봐줘야 할 일이 있어. 그 아래서 하층민 흉내 내는 건 충분히 즐겼다면 말이야.

수정 이유: slumming it을 고문으로 옮긴 오류 수정

## 325. loc_shipmistress_a__shipmistress_hub_announcement_a_57_a_01

유형: 기존 수정

**현재 영문**

To all interlopers: If you tire of my hospitality, I will be happy to ... send you away.

**기존 기본 번역**

모든 불청객들은 들어라. 내 인내심을 바닥나게 한다면... 나도 기꺼이 너희를 보내 버릴 거다.

**수정 기본 번역**

모든 불청객들은 들어라. 내 환대가 지겨워진다면... 기꺼이 너희를 보내주지.

수정 이유: 환대에 싫증 내는 주체가 바뀐 오류 수정

## 326. loc_shipmistress_a__shipmistress_hub_announcement_a_64_a_01

유형: 기존 수정

**현재 영문**

Rejects? You can rely on nothing save death, so give it your all.

**기존 기본 번역**

거부자들? 너희들을 구할 건 죽음밖에 없으니, 최선을 다하도록.

**수정 기본 번역**

거부자들? 죽음 말고는 확실한 게 없으니, 최선을 다하도록.

수정 이유: save를 제외가 아닌 구원으로 옮긴 오류 수정

## 327. loc_shipmistress_a__world_intro_04

유형: 기존 수정

**현재 영문**

Every human soul, from the most high-born lord to the most basic servitor, is dedicated to the service of the God-Emperor of Mankind.

**기존 기본 번역**

모든 인간들... 가장 고귀한 왕족부터 가장 근간인 서비터까지, 인류의 신-황제 폐하를 향한 봉사에 헌신하고 있다.

**수정 기본 번역**

가장 고귀한 귀족부터 가장 낮은 서비터까지, 모든 인간의 영혼은 인류의 신-황제 폐하를 섬기는 데 헌신한다.

수정 이유: lord를 왕족으로 한정한 표현과 어색한 최하위 표현 수정

## 328. loc_social_menu_confirmation_popup_confirm_button

유형: 추가 ID 덮어쓰기

**현재 영문**

Yes

**기존 기본 번역**

수락

**수정 기본 번역**

예

수정 이유: Yes/No 선택지를 긍정·부정 응답으로 통일

## 329. loc_social_menu_confirmation_popup_decline_button

유형: 추가 ID 덮어쓰기

**현재 영문**

No

**기존 기본 번역**

반대

**수정 기본 번역**

아니요

수정 이유: Yes/No 선택지를 긍정·부정 응답으로 통일

## 330. loc_social_menu_confirmation_popup_initiate_kick_vote_header

유형: 기존 수정

**현재 영문**

Kick {#color(239,193,82)}{player_name}{#reset()} from Strike Team

**기존 기본 번역**

스트라이크 팀에서 {player_name} 요원을 추방하시겠습니까? 예를 선택하면 모든 다른 멤버가 {player_name} 요원을 스트라이크 팀에서 추방할지 여부를 결정하는 투표에 참여합니다.

**수정 기본 번역**

{#color(239,193,82)}{player_name}{#reset()} 요원을 스트라이크 팀에서 추방

수정 이유: 제목용 문자열에 들어간 중복 설명 제거 및 이름 변수 중복 제거

## 331. loc_social_menu_party_header

유형: 기존 수정

**현재 영문**

 Strike Team {num_party_members:%d}/{max_num_party_members:%d}

**기존 기본 번역**

스트라이크 팀

**수정 기본 번역**

 스트라이크 팀 {num_party_members:%d}/{max_num_party_members:%d}

수정 이유: 팀 인원수와 최대 인원수 변수 복원

## 332. loc_social_party_join_rejection_reason_party_full

유형: 기존 수정

**현재 영문**

Strike Team is full

**기존 기본 번역**

스트라이커 팀이 꽉 찼습니다

**수정 기본 번역**

스트라이크 팀이 꽉 찼습니다

수정 이유: 팀 명칭 오타 수정

## 333. loc_stats_fire_mode_ads_desc

유형: 기존 수정

**현재 영문**

Aim Down Sights for better targeting.

**기존 기본 번역**

견착해서 무기의 정확성과 안정성을 높일 수 있습니다.

**수정 기본 번역**

목표물을 더 정확히 겨냥하기 위해 조준 사격을 합니다.

수정 이유: 현재 ID의 원문은 견착이 아니라 Aim Down Sights임

## 334. loc_stats_special_action_special_attack_combataxe_p1m1_desc

유형: 기존 수정

**현재 영문**

Sweeping uppercut that ignores Stagger reduction and inflicts higher Impact & Damage vs armoured enemies.

**기존 기본 번역**

휩쓰는 어퍼컷으로 비틀거림을 무시하는 공격을 합니다. 아머가 있는 적에 대한 충격 및 대미지가 더 증가합니다.

**수정 기본 번역**

휩쓰는 어퍼컷으로 비틀거림 감소 효과를 무시하는 공격을 합니다. 아머가 있는 적에 대한 충격 및 대미지가 더 증가합니다.

수정 이유: 비틀거림 감소 무시와 비틀거림 면역 구분

## 335. loc_stats_special_action_special_attack_combataxe_p3m1_desc

유형: 기존 수정

**현재 영문**

Quick poke attack that ignores Stagger reduction. Increased Impact & Damage vs armoured enemies.

**기존 기본 번역**

빠르게 찔러 비틀거림을 무시하는 공격을 합니다. 아머가 있는 적에 대한 충격 및 대미지가 더 증가합니다.

**수정 기본 번역**

빠르게 찔러 비틀거림 감소 효과를 무시하는 공격을 합니다. 아머가 있는 적에 대한 충격 및 대미지가 더 증가합니다.

수정 이유: 비틀거림 감소 무시와 비틀거림 면역 구분

## 336. loc_stats_special_action_special_bullet_shotgun_p1m2_desc

유형: 기존 수정

**현재 영문**

Loads the weapon with one Solid Slug Shell that has high Accuracy, Stagger and Damage.

**기존 기본 번역**

무기에 솔리드 슬러그탄 1발을 장전하여 적에게 명중률과 비틀거림, 높은 대미지를 줍니다.

**수정 기본 번역**

명중률과 비틀거림, 대미지가 높은 솔리드 슬러그탄 한 발을 장전합니다.

수정 이유: 명중률을 적에게 주는 효과로 읽히는 문장 수정

## 337. loc_steelhead_b__hub_map_table_conversation_12_c_01

유형: 기존 수정

**현재 영문**

Not like me, then. Charmed life. The Emperor loves me.

**기존 기본 번역**

그럼 나랑은 다르네. 매력적인 삶이지. 난 황제 폐하의 사랑을 받는 몸이니까.

**수정 기본 번역**

그럼 나랑은 다르네. 난 운 좋은 삶을 살거든. 황제 폐하의 사랑을 받는 몸이니까.

수정 이유: charmed life를 매력적인 삶으로 옮긴 오류 수정

## 338. loc_store_view_display_name

유형: 추가 ID 덮어쓰기

**현재 영문**

The Commodore's Vestures

**기존 기본 번역**

준장의 수확물

**수정 기본 번역**

준장의 의복

수정 이유: Vestures를 수확물로 옮긴 오류 수정

## 339. loc_system_leave_penalty_description

유형: 기존 수정

**현재 영문**

Leaving a Havoc Assignment before finishing the mission will prevent you and anyone in your Strike Team from starting another Havoc Assignment until the current one ends.

**기존 기본 번역**

하복 임무를 완료하기 전에 떠날 경우, 자신과 스트라이크 팀에 있는 사람들 모두 현재 임무가 끝내기 전에는 다른 하복 임무를 시작할 수 없습니다.

**수정 기본 번역**

하복 임무를 완료하기 전에 떠날 경우, 자신과 스트라이크 팀에 있는 사람들 모두 현재 임무가 끝나기 전에는 다른 하복 임무를 시작할 수 없습니다.

수정 이유: 문법 오류 수정

## 340. loc_tactical_overlay_crafting_mat_notification

유형: 기존 수정

**현재 영문**

{player_name:%s} found {amount:%s}

**기존 기본 번역**

{player_name:%s} 요원이 {amount:%s}발견

**수정 기본 번역**

{player_name:%s} 요원이 {amount:%s} 발견

수정 이유: 띄어쓰기 수정

## 341. loc_talent_ability_area_buff_drone_improved_description

유형: 기존 수정

**현재 영문**

Deploy a Nuncio-Aquila in the target direction.

Allies within {range:%s}m Replenish {toughness:%s} Toughness per second, gain {suppression:%s} Suppression Dealt, {impact:%s} Impact, {recoil:%s} Recoil as well as are Immune to Stun, Slowdown, and Suppression.

Enemies within {range:%s}m have {damage_taken:%s} Damage Taken.

Lasts {duration:%s}s. {cooldown:%s}s Cooldown.

This is an augmented version of {nuncio_name:%s}.

**기존 기본 번역**

목표한 방향으로 눈시오 아퀼라를 배치합니다.

{range:%s}미터 내의 아군의 강인함을 매초마다 {toughness:%s} 회복하고, 가하는 제압이 {suppression:%s}, 충격이 {impact:%s} 증가하며, 반동이 {recoil:%s} 감소합니다. 둔화, 제압 면역 상태가 되며, 보조 사격 중 방해 면역 상태가 됩니다.

{range:%s}미터 내의 적이 받는 대미지가 {damage_taken:%s} 증가합니다.

{duration:%s}초 동안 지속되며, 쿨다운 시간은 {cooldown:%s}초입니다.

{nuncio_name:%s}의 증강된 버전입니다.

**수정 기본 번역**

목표한 방향으로 눈시오 아퀼라를 배치합니다.

{range:%s}미터 내의 아군의 강인함을 매초마다 {toughness:%s} 회복하고, 가하는 제압이 {suppression:%s}, 충격이 {impact:%s} 증가하며, 반동이 {recoil:%s} 감소합니다. 기절, 둔화, 제압에 면역이 됩니다.

{range:%s}미터 내의 적이 받는 대미지가 {damage_taken:%s} 증가합니다.

{duration:%s}초 동안 지속되며, 쿨다운 시간은 {cooldown:%s}초입니다.

{nuncio_name:%s}의 증강된 버전입니다.

수정 이유: 현재 원문의 기절 면역과 적용 범위 반영

## 342. loc_talent_adamant_ability_nuncio_base_desc

유형: 기존 수정

**현재 영문**

Deploy a Nuncio-Aquila in the target direction.

Allies within {range:%s}m Replenish {toughness:%s} Toughness per second and Enemies within {range:%s}m have {damage_taken:%s} Damage Taken.

Lasts {duration:%s}s. {cooldown:%s}s Cooldown.

**기존 기본 번역**

목표한 방향으로 눈시오 아퀼라를 배치합니다.

{range:%s}미터 내의 아군은 강인함을 매 초마다 {toughness:%s} 회복합니다. 또한 {range:%s} 미터 내의 적은 {damage_taken:%s}의 대미지를 추가로 받습니다.

{duration:%s}초 동안 지속됩니다.

**수정 기본 번역**

목표한 방향으로 눈시오 아퀼라를 배치합니다.

{range:%s}미터 내의 아군은 매초 강인함을 {toughness:%s} 회복하고, {range:%s}미터 내의 적은 받는 대미지가 {damage_taken:%s} 증가합니다.

지속시간: {duration:%s}초
쿨다운: {cooldown:%s}초

수정 이유: 기본 전투 능력의 쿨다운 누락 복원

## 343. loc_talent_adamant_charge_cooldown_alt_description

유형: 기존 수정

**현재 영문**

Restore {cooldown:%s}s Ability Cooldown for each hit, increased to {cooldown_elite:%s} on Elite, Specialist, or Monstrosity. {max_cooldown:%s} Max Cooldown restored.

**기존 기본 번역**

전투 능력으로 적을 맞힐 때마다 전투 능력의 쿨다운이 {cooldown:%s}초씩 감소합니다. 엘리트, 스페셜리스트, 흉물을 맞히면 {cooldown_elite:%s}초 추가로 감소합니다. 쿨다운은 최대 {max_cooldown:%s}초까지 감소합니다.

**수정 기본 번역**

적 하나를 맞힐 때마다 전투 능력의 쿨다운을 {cooldown:%s}초 회복합니다. 엘리트, 스페셜리스트 또는 흉물을 맞히면 대신 {cooldown_elite:%s}초 회복합니다. 최대 {max_cooldown:%s}초까지 회복할 수 있습니다.

수정 이유: increased to를 추가 감소량이 아닌 대체 회복량으로 수정

## 344. loc_talent_adamant_clip_size_alt_desc

유형: 기존 수정

**현재 영문**

{clip_size:%s} Clip Size, rounded up.

**기존 기본 번역**

탄창 용량이 {clip_size:%s} 증가합니다. (반올림 처리)

**수정 기본 번역**

탄창 용량이 {clip_size:%s} 증가합니다. 소수점 이하는 올림합니다.

수정 이유: rounded up 오역 수정

## 345. loc_talent_adamant_dodge_improvement_desc

유형: 기존 수정

**현재 영문**

Increase Effective Dodges by {dodge:%s} and time considered Dodging by {dodge_duration:%s}.

**기존 기본 번역**

효과적인 회피 횟수가 {dodge:%s}, 회피 지속 시간이 {dodge_duration:%s} 증가합니다.

**수정 기본 번역**

유효 회피 횟수가 {dodge:%s} 증가하고, 회피 중으로 판정되는 시간이 {dodge_duration:%s} 늘어납니다.

수정 이유: 회피 판정 시간 명시

## 346. loc_talent_adamant_dog_pounces_bleed_nearby_desc

유형: 기존 수정

**현재 영문**

Enemies knocked away by your Cyber Mastiff's Pounce have {stacks:%s} Stack(s) of Bleed applied to them.

**기존 기본 번역**

사이버 마스티프가 덮쳐서 쓰러뜨린 적에게 출혈 {stacks:%s} 중첩을 부여합니다.

**수정 기본 번역**

사이버 마스티프의 덮치기에 밀려난 적에게 출혈을 {stacks:%s}회 중첩시킵니다.

수정 이유: 덮치기로 제압한 대상과 주위로 밀려난 적을 구분

## 347. loc_talent_adamant_elite_special_kills_offensive_boost_alt_desc

유형: 기존 수정

**현재 영문**

{damage:%s} Damage and {movement_speed:%s} Movement Speed on Elite or Specialist Kill. Lasts {duration:%s}s.

**기존 기본 번역**

엘리트 또는 스페셜리스트 처치 시 적에게 주는 대미지가 {damage:%s}, 이동 속도가 {movement_speed:%s} 증가합니다. {duration:%s}초 동안 치속됩니다.

**수정 기본 번역**

엘리트 또는 스페셜리스트 처치 시 적에게 주는 대미지가 {damage:%s}, 이동 속도가 {movement_speed:%s} 증가합니다. {duration:%s}초 동안 지속됩니다.

수정 이유: 오타 수정

## 348. loc_talent_adamant_forceful_ability_damage

유형: 기존 수정

**현재 영문**

On Combat Ability, Gain {strength:%s} Strength for each stack. Lasts {duration:%s}s. Removes all Stacks.

**기존 기본 번역**

중첩 당, 전투 능력의 위력이 {strength:%s} 증가합니다. {duration:%s}초 동안 지속됩니다.

모든 중첩이 제거됩니다.

**수정 기본 번역**

전투 능력을 사용하면 모든 중첩을 소모하고, 소모한 중첩 하나당 파워가 {strength:%s} 증가합니다. {duration:%s}초 동안 지속됩니다.

수정 이유: 전투 능력 자체만 강화하는 효과로 옮긴 오류 수정

## 349. loc_talent_adamant_forceful_base_alt_desc

유형: 기존 수정

**현재 영문**

Staggering Hits and Blocked Attacks grant Stacks of {forceful_name:%s}. Lasting {duration:%s}s and stacking {stacks:%s} times. Each stack gives {impact:%s} Impact and {dr:%s} Damage Resistance. Remove stack on damage taken.

**기존 기본 번역**

적을 비틀거리게 하는 공격을 맞히거나 공격을 막아내면 {forceful_name:%s} 중첩을 획득합니다. 최대 {stacks:%s}회 중첩되며, {duration:%s}초 동안 지속됩니다. 각 중첩마다 충격이 {impact:%s}, 대미지 저항력이 {dr:%s} 씩 증가합니다. 대미지를 받으면 중첩이 사라집니다.

**수정 기본 번역**

적을 비틀거리게 하는 공격을 맞히거나 공격을 막아내면 {forceful_name:%s} 중첩을 획득합니다. 최대 {stacks:%s}회 중첩되며, {duration:%s}초 동안 지속됩니다. 각 중첩마다 충격이 {impact:%s}, 대미지 저항력이 {dr:%s} 씩 증가합니다. 대미지를 받으면 중첩 하나를 잃습니다.

수정 이유: 중첩 제거 수 명시

## 350. loc_talent_adamant_forceful_melee_alt_desc

유형: 기존 수정

**현재 영문**

While at Max Stacks, and for {duration:%s}s afterwards, Gain {attack_speed:%s} Attack Speed and {cleave:%s} Cleave.

**기존 기본 번역**

중첩이 최대치일 때 {duration:%s}초 뒤에 공격 속도가 {attack_speed:%s}, 쪼개기가 {cleave:%s} 증가합니다.

**수정 기본 번역**

중첩이 최대치인 동안과 그 상태가 끝난 뒤 {duration:%s}초 동안 공격 속도가 {attack_speed:%s}, 쪼개기가 {cleave:%s} 증가합니다.

수정 이유: 잔여 효과 지속시간을 발동 지연으로 옮긴 오류 수정

## 351. loc_talent_adamant_forceful_stun_immune_and_block_all_linger_desc

유형: 기존 수정

**현재 영문**

While at Max Stacks, and for {duration:%s}s afterwards, Gain Stun Immunity, additionally, your perfect blocks can block all attacks.

**기존 기본 번역**

중첩이 최대치일 때 {duration:%s}초 뒤에 기절 면역을 얻으며, 완벽한 방어로 모든 공격을 막아낼 수 있습니다.

**수정 기본 번역**

중첩이 최대치인 동안과 그 상태가 끝난 뒤 {duration:%s}초 동안 기절에 면역이 됩니다. 또한 완벽한 막기로 모든 공격을 막을 수 있습니다.

수정 이유: 최대 중첩 이후 잔여 시간을 발동 지연으로 옮긴 오류 수정

## 352. loc_talent_adamant_increased_damage_to_high_health_desc

유형: 기존 수정

**현재 영문**

{damage:%s} Damage to Enemies above {health:%s} Health.

**기존 기본 번역**

체력이 {health:%s} 이상인 적에게 주는 대미지가 {damage:%s} 증가합니다.

**수정 기본 번역**

체력이 {health:%s} 초과인 적에게 주는 대미지가 {damage:%s} 증가합니다.

수정 이유: above 경계 조건 반영

## 353. loc_talent_adamant_melee_weakspot_hits_count_as_stagger_desc

유형: 기존 수정

**현재 영문**

Melee Weakspot hits make the enemy count as Staggered for {duration:%s}s.

**기존 기본 번역**

근접 공격으로 적의 약점을 맞히면 {duration:%s}초 동안 비틀거립니다.

**수정 기본 번역**

근접 약점 공격에 맞은 적은 {duration:%s}초 동안 비틀거리는 상태로 판정됩니다.

수정 이유: 실제 비틀거림 동작을 강제하는 효과가 아닌 판정 효과임을 명시

## 354. loc_talent_adamant_staggers_reduce_damage_taken_alt_desc

유형: 기존 수정

**현재 영문**

Staggering an Enemy grants {normal_stacks:%s} stack(s) of {damage_taken_multiplier:%s} Damage Resistance, on the next Melee hit taken. Stacking {max_stacks:%s} times and lasting {duration:%s}s. Staggering Non-Human Sized Enemies grants {ogryn_stacks:%s} stack(s).

**기존 기본 번역**

적을 비틀거리게 하면 다음 근접 공격을 받을 때 {damage_taken_multiplier:%s} 대미지 저항력 {normal_stacks:%s} 중첩을 획득합니다. 인간 크기가 아닌 적들을 비틀거리게 하면 {ogryn_stacks:%s} 중첩을 획득합니다.

**수정 기본 번역**

적을 비틀거리게 하면 다음에 받는 근접 공격에 적용되는 {damage_taken_multiplier:%s} 대미지 저항력을 {normal_stacks:%s}중첩 획득합니다. 최대 {max_stacks:%s}회 중첩되며 {duration:%s}초 동안 지속됩니다. 인간 크기가 아닌 적을 비틀거리게 하면 {ogryn_stacks:%s}중첩 획득합니다.

수정 이유: 중첩 획득 시점, 상한, 지속시간 복원

## 355. loc_talent_adamant_stance_ranged_kills_transfer_ammo_no_cd_desc

유형: 기존 수정

**현재 영문**

During {stance_name:%s}, ranged kills replenish up to {ammo:%s} of the total Ammo in your Clip from your Reserve, rounded up. Can occur once per Attack.

**기존 기본 번역**

{stance_name:%s}가 지속되는 동안, 원거리 공격으로 적을 처치하면 탄창에 장전되는 총 탄약의 {ammo:%s}만큼을 갖고 있는 탄약에서 보충합니다. (반올림 처리). 매 공격마다 한 번만 발동됩니다.

**수정 기본 번역**

{stance_name:%s}가 지속되는 동안 원거리 처치 시, 탄창 총용량의 최대 {ammo:%s}만큼을 예비 탄약에서 탄창으로 보충합니다. 소수점 이하는 올림합니다. 공격 한 번당 한 번만 발동합니다.

수정 이유: up to 및 rounded up 반영

## 356. loc_talent_broker_ability_focus_desc

유형: 기존 수정

**현재 영문**

Swaps to and reloads your Ranged Weapon, entering {talent_name:%s} for {duration:%s}s. For the duration, you count as Dodging against Ranged Attacks, Sprinting costs no Stamina, and you gain {sprint_movement_speed:%s} Sprint Speed.

While the ability is active, reloading your weapon does not reduce your Ammo Reserve.

Base Cooldown: {cooldown:%s}s.

**기존 기본 번역**

원거리 무기로 즉시 전환 및 재장전하고, {duration:%s}초 동안 {talent_name:%s} 상태에 진입합니다. 지속 시간 동안 원거리 공격에 절대로 맞지 않으며, 질주할 때 스태미나를 소모하지 않고, 질주 속도가 {sprint_movement_speed:%s} 증가합니다.

능력이 발동된 동안에는 재장전 시 보유한 탄약을 소비하지 않습니다.

기본 쿨다운: {cooldown:%s}

**수정 기본 번역**

원거리 무기로 전환하고 재장전한 뒤, {duration:%s}초 동안 {talent_name:%s} 상태에 진입합니다. 지속 시간 동안 원거리 공격에 대해 회피 중인 것으로 판정되며, 질주 시 스태미나를 소모하지 않고 질주 속도가 {sprint_movement_speed:%s} 증가합니다.

능력이 활성화된 동안에는 재장전해도 예비 탄약이 줄어들지 않습니다.

기본 쿨다운: {cooldown:%s}초

수정 이유: 현재 영문은 impossible to hit가 아니라 count as Dodging against Ranged Attacks입니다. 절대 피격되지 않는다는 기존 설명을 회피 판정으로 수정하고 쿨다운 초 단위도 보완합니다.

## 357. loc_talent_broker_ability_focus_improved_desc

유형: 기존 수정

**현재 영문**

Swaps to and reloads your Ranged Weapon, entering {talent_name:%s} for {duration:%s}s. For the duration, you count as Dodging against Ranged Attacks, Sprinting costs no Stamina, and you gain {sprint_movement_speed:%s} Sprint Speed.

While the ability is active, reloading your weapon does not reduce your Ammo Reserve.

Additionally, Enemies within Close Range become highlighted. Killing highlighted enemies with your Ranged Weapon extends the duration by {duration_extend:%s}s. After {duration_max:%s}s, the extending becomes diminished.

Base Cooldown: {cooldown:%s}s.

This is an augmented version of {default_talent:%s}.

**기존 기본 번역**

원거리 무기로 즉시 전환 및 재장전하고, {duration:%s}초 동안 {talent_name:%s} 상태에 진입합니다. 지속 시간 동안 원거리 공격에 절대로 맞지 않으며, 질주할 때 스태미나를 소모하지 않고, 질주 속도가 {sprint_movement_speed:%s} 증가합니다.

능력이 발동된 동안에는 재장전 시 보유한 탄약을 소비하지 않습니다.

추가로 근거리에 있는 적이 강조 표시됩니다.

강조 표시 된 적을 원거리 무기로 처치하면 지속시간이 {duration_extend:%s}초 증가합니다. {duration_max:%s}초 이후부터는 연장 효과가 감소합니다.

기본 쿨다운: {cooldown:%s}초

이것은 {default_talent:%s}의 증강된 버전입니다.

**수정 기본 번역**

원거리 무기로 즉시 전환 및 재장전하고, {duration:%s}초 동안 {talent_name:%s} 상태에 진입합니다. 지속 시간 동안 원거리 공격에 대해 회피 중인 것으로 판정되며, 질주할 때 스태미나를 소모하지 않고, 질주 속도가 {sprint_movement_speed:%s} 증가합니다.

능력이 발동된 동안에는 재장전 시 보유한 탄약을 소비하지 않습니다.

추가로 근거리에 있는 적이 강조 표시됩니다.

강조 표시 된 적을 원거리 무기로 처치하면 지속시간이 {duration_extend:%s}초 증가합니다. {duration_max:%s}초 이후부터는 연장 효과가 감소합니다.

기본 쿨다운: {cooldown:%s}초

이것은 {default_talent:%s}의 증강된 버전입니다.

수정 이유: 현재 원문의 회피 판정 반영

## 358. loc_talent_broker_ability_punk_rage_desc_3

유형: 기존 수정

**현재 영문**

Replenish all Toughness and enter {talent_name:%s} for {duration:%s}s. For the duration, gain {power:%s} Melee Power, {attack_speed:%s} Melee Attack Speed and {damage_taken:%s} Damage Reduction, as well as becoming Stun and Suppression immune.

Melee Strikes extend the duration by {rage_duration_extend:%s}s. After {rage_duration_max:%s}s, the duration extension granted by each hit is reduced.

Base Cooldown: {cooldown:%s}s.

**기존 기본 번역**

강인함을 모두 회복하고 {duration:%s}초 동안 {talent_name:%s} 상태가 됩니다. 지속시간 동안 근접 무기 파워가 {power:%s}, 근접 공격 속도가 {attack_speed:%s} 증가하고, 받는 대미지 감소율이 {damage_taken:%s}만큼 증가합니다.또한 기절과 제압에 면역 상태가 됩니다.

근접 공격을 맞히면 지속시간이 {rage_duration_extend:%s}초 연장됩니다. {rage_duration_max:%s}초 이후부터는 각 공격으로 받는 연장 효과가 감소합니다.

기본 쿨다운: {cooldown:%s}초

**수정 기본 번역**

강인함을 모두 회복하고 {duration:%s}초 동안 {talent_name:%s} 상태에 진입합니다. 지속 시간 동안 근접 무기 파워가 {power:%s}, 근접 공격 속도가 {attack_speed:%s}, 받는 대미지 감소율이 {damage_taken:%s} 증가하며, 기절과 제압에 면역이 됩니다.

근접 공격을 맞히면 지속 시간이 {rage_duration_extend:%s}초 늘어납니다. {rage_duration_max:%s}초가 지나면 공격을 맞힐 때마다 늘어나는 시간이 감소합니다.

기본 쿨다운: {cooldown:%s}초

수정 이유: 문장 경계와 띄어쓰기를 정리하고 지속 시간 연장 효과가 감소한다는 의미를 명확히 합니다.

## 359. loc_talent_broker_ability_punk_rage_sub_1_desc_02

유형: 기존 수정

**현재 영문**

Heavy Attacks while {punk_rage:%s} is active have {rending:%s} Rending.

**기존 기본 번역**

{punk_rage:%s}가 발동된 상태일 때 강공격의 찢기가 {rending:%s} 증가합니다.

**수정 기본 번역**

{punk_rage:%s} 활성화 중에는 강공격의 찢기가 {rending:%s} 증가합니다.

수정 이유: 기존 용어를 유지하면서 발동 조건을 간결하게 정리합니다.

## 360. loc_talent_broker_ability_punk_rage_sub_3_desc_02

유형: 기존 수정

**현재 영문**

When {punk_rage%s} is activated, unleash a powerful Shout that staggers Enemies and increases the time between their attacks by {attack_speed_reduction:%s} for {duration:%s}s.

When {punk_rage:%s} runs out, shout again.

**기존 기본 번역**

{punk_rage%s}가 발동된 상태일 때, 강력한 함성을 질러 적들을 비틀거리게 하고, {duration:%s}초 동안 적들의 공격 간격이 {attack_speed_reduction:%s} 증가합니다.

{punk_rage:%s}가 종료되면 다시 한 번 함성을 지릅니다.

**수정 기본 번역**

{punk_rage%s}를 활성화하면 강력한 함성을 질러 적들을 비틀거리게 하고, {duration:%s}초 동안 적들의 공격 간격을 {attack_speed_reduction:%s} 늘립니다.

{punk_rage:%s}가 종료되면 다시 한 번 함성을 지릅니다.

수정 이유: 현재 영문의 When activated에 따라 활성화 순간의 효과로 표현합니다. 변수 표기는 현재 영문 원문과 동일하게 보존합니다. 원문도 콜론 없는 첫 표기를 사용하므로 별도 변수 오류로 단정하지 않습니다.

## 361. loc_talent_broker_ability_stimm_field_desc_3

유형: 기존 수정

**현재 영문**

Deploy a refitted Medi-Pack on the ground, bolstering you and your allies for {duration:%s}s. Operatives breathing the Pack’s gas heal up to {total_corruption_heal:%s} Corruption over time and become immune to it.

Additionally, if you have a Stimm equipped, {stimm_field:%s} will copy its contents and disperse them into the air, granting its effects to any nearby allies.

Base Cooldown: {cooldown:%s}s.

**기존 기본 번역**

개량된 의료 상자를 설치하여 {duration:%s}초 동안 자신과 동료들을 강화합니다. 상자의 가스를 들이마신 요원들은 부패를 시간에 걸쳐 {total_corruption_heal:%s}까지 제거하며, 부패 면역 상태가 됩니다.

추가로 자극제를 장비 중일 경우, {stimm_field:%s}가 자극제의 내용물을 복제하여 공기 중에 살포하며, 주변의 아군에게 그 효과를 부여합니다.

기본 쿨다운: {cooldown:%s}초

**수정 기본 번역**

개량된 의료 상자를 설치하여 {duration:%s}초 동안 자신과 아군을 강화합니다. 상자의 가스를 들이마시는 요원은 부패가 점차 회복되어 총 {total_corruption_heal:%s}까지 제거되며, 부패에 면역이 됩니다.

자극제를 장비하고 있다면 {stimm_field:%s}가 그 내용물을 복제해 공기 중에 살포하여 주변 아군에게 해당 효과를 부여합니다.

기본 쿨다운: {cooldown:%s}초

수정 이유: 시간에 걸쳐라는 직역을 다듬고 부패 제거 총량과 자극제 효과 공유 조건을 구분합니다.

## 362. loc_talent_broker_ability_stimm_field_sub_1_desc

유형: 기존 수정

**현재 영문**

The duration of {stimm_field:%s} is shortened to {duration:%s}s, but its effects linger after leaving its area for {linger_duration:%s}s.

**기존 기본 번역**

{stimm_field:%s}의 지속 시간이 {duration:%s}초 감소하지만 효과 범위를 벗어난 뒤에도 {linger_duration:%s}초 동안 효과가 지속됩니다.

**수정 기본 번역**

{stimm_field:%s}의 지속 시간이 {duration:%s}초로 줄어들지만, 효과 범위를 벗어난 뒤에도 {linger_duration:%s}초 동안 효과가 지속됩니다.

수정 이유: shortened to는 해당 시간으로 줄어든다는 뜻이므로, 기존의 해당 시간만큼 감소한다는 번역을 수정합니다.

## 363. loc_talent_broker_blitz_flash_grenade_desc

유형: 기존 수정

**현재 영문**

Quick to use Grenade that staggers enemies.

Every {num_kills:%s} Kills at Close Range generate {num_charges:%s} Grenade(s).

{max_charges:%s} Max Grenades.

**기존 기본 번역**

적을 비틀거리게 하는 수류탄을 빠르게 던집니다.

근거리에 있는 적을 {num_kills:%s} 처치할 때마다 수류탄을 {num_charges:%s}개 보충합니다.

최대 {max_charges:%s}개의 수류탄을 소지할 수 있습니다.

**수정 기본 번역**

적을 비틀거리게 하는 수류탄을 빠르게 던집니다.

근거리에 있는 적을 {num_kills:%s}명 처치할 때마다 수류탄을 {num_charges:%s}개 보충합니다.

최대 {max_charges:%s}개의 수류탄을 소지할 수 있습니다.

수정 이유: 수량 단위 보완

## 364. loc_talent_broker_blitz_tox_grenade_desc_02

유형: 기존 수정

**현재 영문**

Thrown grenade containing {toxin:%s}. The canister breaks open when it explodes, spilling its contents out across an area for {duration:%s}s.

Enemies standing in the toxic matter receive up to {max_stacks:%s} stacks of {toxin:%s} over time and explode upon death.

{max_charges:%s} Max Grenades.

**기존 기본 번역**

{toxin:%s}가 담긴 수류탄을 투척합니다. 용기가 폭발하며 열릴 때, 내용물을 일정한 범위에 흩뿌리고, {duration:%s}초 동안 지속됩니다.

독성 물질 위에 서 있는 적들은 시간에 걸쳐 {toxin:%s}가 최대 {max_stacks:%s}회까지 중첩되며, 사망하면 폭발합니다.

최대 {max_charges:%s}개 충전됩니다.

**수정 기본 번역**

{toxin:%s}가 담긴 수류탄을 투척합니다. 용기가 폭발하면 내용물이 주변에 퍼져 {duration:%s}초 동안 남습니다.

독성 물질 안에 있는 적에게는 시간이 지남에 따라 {toxin:%s}가 최대 {max_stacks:%s}회 중첩되며, 해당 적은 사망 시 폭발합니다.

최대 수류탄 소지량: {max_charges:%s}개

수정 이유: 수류탄 내용물이 남는 시간과 중첩 대상을 명확히 하고, Max Grenades를 최대 소지량으로 표현합니다.

## 365. loc_talent_broker_keystone_chemical_dependency_desc

유형: 기존 수정

**현재 영문**

Using a Stimm grants you a stack of {dependency:%s} for {duration:%s}s.

For each stack, gain {cooldown_reduction:%s} Ability Cooldown Reduction.

Up to {max_stacks:%s} Max Stacks. Stacks decay one at a time.

**기존 기본 번역**

자극제를 사용하면 {duration:%s}초 동안 {dependency:%s}을 획득합니다.

각 중첩당, 능력 쿨다운 재생률이 {cooldown_reduction:%s} 증가합니다.

최대 {max_stacks:%s}개까지 중첩되며, 중첩은 한 번에 하나씩만 감소합니다.

**수정 기본 번역**

자극제를 사용하면 {duration:%s}초 동안 {dependency:%s}을 획득합니다.

각 중첩당, 전투 능력의 쿨다운 감소율이 {cooldown_reduction:%s} 증가합니다.

최대 {max_stacks:%s}개까지 중첩되며, 중첩은 한 번에 하나씩만 감소합니다.

수정 이유: 쿨다운 감소와 쿨다운 재생속도 구분

## 366. loc_talent_broker_keystone_vultures_mark_dodge_on_ranged_crit_desc

유형: 기존 수정

**현재 영문**

Ranged Critical Hits makes you count as Dodging against all Attacks for {duration:%s}s.

**기존 기본 번역**

원거리 치명타 공격을 맞히면 {duration:%s}초 동안 모든 공격에 대해 면역 상태가 됩니다.

**수정 기본 번역**

원거리 치명타 공격을 맞히면 {duration:%s}초 동안 모든 공격에 대해 회피 중인 것으로 판정됩니다.

수정 이유: 회피 판정을 모든 공격 면역으로 옮긴 오류 수정

## 367. loc_talent_broker_keystone_vultures_mark_on_kill_desc

유형: 기존 수정

**현재 영문**

Killing a Special or Elite enemy with a ranged weapon grants you a stack of Vulture's Mark for {duration:%s}s (Stacks {max_stacks:%s} times).

Each stack grants {ranged_damage:%s} Ranged Damage, {crit_chance:%s} Ranged Critical Strike Chance, and {movement_speed:%s} Movement Speed.

While at max stacks, Special and Elite Ranged Kills restore {toughness:%s} Toughness to you and Allies in Coherency.

**기존 기본 번역**

엘리트 또는 스페셜리스트를 원거리 무기로 처치하면 {duration:%s}초 동안 독수리의 표식을 획득합니다. 최대 {max_stacks:%s}회 중첩됩니다.

각 중첩당 원거리 공격 대미지가 {ranged_damage:%s} 증가하고, 원거리 공격 치명타 확률이 {crit_chance:%s} 증가하며, 이동 속도가 {movement_speed:%s} 증가합니다.

최대 중첩 상태일 때 엘리트 또는 스페셜리스트를 처치하면 본인과 단결 상태의 아군의 강인함을 {toughness:%s} 회복합니다.

**수정 기본 번역**

엘리트 또는 스페셜리스트를 원거리 무기로 처치하면 {duration:%s}초 동안 독수리의 표식을 획득합니다. 최대 {max_stacks:%s}회 중첩됩니다.

각 중첩당 원거리 공격 대미지가 {ranged_damage:%s} 증가하고, 원거리 공격 치명타 확률이 {crit_chance:%s} 증가하며, 이동 속도가 {movement_speed:%s} 증가합니다.

최대 중첩 상태일 때 엘리트 또는 스페셜리스트를 원거리 공격으로 처치하면 본인과 단결 상태의 아군의 강인함을 {toughness:%s} 회복합니다.

수정 이유: 최대 중첩 강인함 회복의 원거리 처치 조건 복원

## 368. loc_talent_broker_passive_blitz_inflicts_toxin_desc_02

유형: 기존 수정

**현재 영문**

Blitz explosions infect Enemies with stacks of {toxin:%s} differently, depending on your chosen Blitz.

{blinder:%s}: {blinder_stacks:%s} stacks.
{missile_launcher:%s}: {missile_launcher_stacks:%s} stacks.
{chem_grenade:%s}: {chem_grenade_stacks:%s} stacks.

**기존 기본 번역**

선택한 대공세에 따라 대공세 폭발로 적에게 부여하는 {toxin:%s}의 중첩 갯수가 변화합니다.

- {blinder:%s}: {blinder_stacks:%s}회
- {missile_launcher:%s}: {missile_launcher_stacks:%s}회
- {chem_grenade:%s}: {chem_grenade_stacks:%s}회

**수정 기본 번역**

대공세 폭발이 적에게 {toxin:%s} 중첩을 부여합니다. 부여하는 중첩 수는 선택한 대공세에 따라 달라집니다.

- {blinder:%s}: {blinder_stacks:%s}중첩
- {missile_launcher:%s}: {missile_launcher_stacks:%s}중첩
- {chem_grenade:%s}: {chem_grenade_stacks:%s}중첩

수정 이유: 기능을 먼저 설명하고 중첩 갯수의 맞춤법과 단위를 정리합니다.

## 369. loc_talent_broker_passive_close_range_damage_on_dodge_desc

유형: 기존 수정

**현재 영문**

{damage_near:%s} Close Range Damage for {duration:%s}s after a Successful Dodge.

**기존 기본 번역**

적의 공격을 성공적으로 회피하면 {duration:%s}초 동안 근거리에서 가하는 원거리 대미지가 {damage_near:%s} 증가합니다.

**수정 기본 번역**

적의 공격을 성공적으로 회피하면 {duration:%s}초 동안 근거리 대미지가 {damage_near:%s} 증가합니다.

수정 이유: 원문에 없는 원거리 공격 한정 표현 제거

## 370. loc_talent_broker_passive_close_ranged_damage_desc

유형: 기존 수정

**현재 영문**

{damage_near:%s} Ranged Damage against targets within {range_near:%s} meters, scaling down to a minimum of {damage_far:%s} at {range_far:%s} meters and beyond.

**기존 기본 번역**

{range_near:%s}미터 내에 있는 목표에게 주는 원거리 공격 대미지가 {damage_near:%s} 증가하며, {range_far:%s}미터 이상에서는 대미지가 {damage_far:%s}까지 점차 감소합니다.

**수정 기본 번역**

{range_near:%s}미터 이내의 적에게 주는 원거리 대미지가 {damage_near:%s} 증가합니다. 거리가 멀어질수록 보너스가 줄어들어, {range_far:%s}미터 이상에서는 최소 {damage_far:%s}가 됩니다.

수정 이유: 거리 비례 감소와 최소 보너스 도달 지점 명시

## 371. loc_talent_broker_passive_damage_vs_heavy_staggered_desc_02

유형: 기존 수정

**현재 영문**

{power_light:%s} Damage against Enemies that are Staggered. Medium and Heavy Staggered Enemies instead take {power_heavy:%s}.

**기존 기본 번역**

비틀거리는 적에게 주는 대미지가 {power_light:%s} 증가합니다. 중간 또는 강하게 비틀거리고 있을 경우 주는 대미지가 {power_heavy:%s} 증가합니다.

**수정 기본 번역**

비틀거리는 적에게 주는 대미지가 {power_light:%s} 증가합니다. 중간 또는 강한 비틀거림 상태의 적에게는 대신 {power_heavy:%s} 증가합니다.

수정 이유: instead를 반영하여 두 보너스가 함께 더해지는 것으로 읽히지 않도록 합니다.

## 372. loc_talent_broker_passive_dodge_melee_on_slide_desc

유형: 기존 수정

**현재 영문**

While sliding, you count as Dodging against Melee Attacks.

**기존 기본 번역**

슬라이딩 하는 동안 근접 공격에 대해 면역 상태가 됩니다.

**수정 기본 번역**

슬라이딩하는 동안 근접 공격에 대해 회피 중인 것으로 판정됩니다.

수정 이유: 회피 판정을 절대 면역으로 옮긴 오류 수정

## 373. loc_talent_broker_passive_extended_mag_desc

유형: 기존 수정

**현재 영문**

{clip_size:%s} Clip Size, rounded up.

**기존 기본 번역**

탄창 용량이 {clip_size:%s} 증가합니다. (반올림 처리)

**수정 기본 번역**

탄창 용량이 {clip_size:%s} 증가합니다. 소수점 이하는 올림합니다.

수정 이유: rounded up은 반올림이 아니라 올림이므로 수정합니다.

## 374. loc_talent_broker_passive_improved_dodges_at_full_stamina_desc

유형: 기존 수정

**현재 영문**

{dodge_cooldown_reset_modifier:%s} Dodge Recovery Speed while Stamina is above {stamina:%s}.

**기존 기본 번역**

스태미나가 {stamina:%s} 이상일 때 회피 횟수 회복 속도가 {dodge_cooldown_reset_modifier:%s} 증가합니다.

**수정 기본 번역**

스태미나가 {stamina:%s} 초과일 때 회피 횟수 회복 속도가 {dodge_cooldown_reset_modifier:%s} 증가합니다.

수정 이유: above 경계 조건 반영

## 375. loc_talent_broker_passive_improved_dodges_desc_02

유형: 기존 수정

**현재 영문**

Dodge Speed is increased by {dodge_distance_modifier:%s}, and time considered Dodging by {dodge_linger_time:%s}s.

**기존 기본 번역**

회피 속도가 {dodge_distance_modifier:%s} 증가하고, 회피로 간주되는 시간이 {dodge_linger_time:%s}초 증가합니다.

**수정 기본 번역**

회피 속도가 {dodge_distance_modifier:%s} 증가하고, 회피 판정이 유지되는 시간이 {dodge_linger_time:%s}초 늘어납니다.

수정 이유: time considered Dodging을 회피 판정 유지 시간으로 풀어 씁니다.

## 376. loc_talent_broker_passive_low_ammo_regen_desc_04

유형: 기존 수정

**현재 영문**

Killing an Elite or Specialist Enemy with a Melee Attack while Ammo Reserve is below {ammo_threshold:%s} will refill it to {ammo_threshold:%s}.

**기존 기본 번역**

보유 중인 탄약의 양이 {ammo_threshold:%s} 이하일 때, 엘리트 또는 스페셜리스트를 근접 공격으로 처치하면 탄약을 최대 {ammo_threshold:%s}까지 보충합니다.

**수정 기본 번역**

예비 탄약이 {ammo_threshold:%s} 미만일 때 엘리트 또는 스페셜리스트를 근접 공격으로 처치하면, 예비 탄약이 {ammo_threshold:%s}까지 보충됩니다.

수정 이유: Ammo Reserve를 예비 탄약으로, below를 미만으로 옮기고 refill to의 보충 목표를 명확히 합니다.

## 377. loc_talent_broker_passive_reduce_swap_time_desc

유형: 기존 수정

**현재 영문**

{wield_speed:%s} Weapon Swap Speed.
Additionally, gain {recoil:%s} Recoil and {spread:%s} Spread while firing from the hip or bracing.

**기존 기본 번역**

무기 교체 속도가 {wield_speed:%s} 증가합니다. 또한 지향사격 또는 조준사격을 하는 동안 반동이 {recoil:%s} 감소하며, 탄퍼짐이 {spread:%s} 감소합니다.

**수정 기본 번역**

무기 교체 속도가 {wield_speed:%s} 증가합니다. 또한 지향사격 또는 견착 사격을 하는 동안 반동이 {recoil:%s} 감소하며, 탄퍼짐이 {spread:%s} 감소합니다.

수정 이유: bracing을 견착으로 통일

## 378. loc_talent_broker_passive_replenish_toughness_while_toxined_enemies_in_proximity_desc

유형: 기존 수정

**현재 영문**

Replenish {toughness_amount:%s} Toughness every {interval:%s}s for each {toxin:%s} infected Enemy within {range:%s}m, up to a maximum of {max_enemies} Enemies.

**기존 기본 번역**

{range:%s}미터 안에 있는 {toxin:%s}에 의해 감염된 적 한 명 당 강인함을 매 {interval:%s}초마다 {toughness_amount:%s}씩 회복합니다. 감염된 적은 최대 {max_enemies}명까지만 계산합니다.

**수정 기본 번역**

{range:%s}미터 이내에서 {toxin:%s}에 감염된 적 한 명당, {interval:%s}초마다 강인함을 {toughness_amount:%s} 회복합니다. 최대 {max_enemies}명까지 계산합니다.

수정 이유: 회복 주기와 적 한 명당 회복량, 계산 상한을 구분합니다. 변수는 기존 번역 표기를 유지합니다.

## 379. loc_talent_broker_passive_restore_toughness_on_close_ranged_kill_desc

유형: 기존 수정

**현재 영문**

Replenish {toughness:%s} Toughness on Ranged Kill. Elites and Specials instead replenish {toughness_elites:%s} Toughness.

**기존 기본 번역**

원거리 공격으로 적을 처치하면 강인함을 {toughness:%s} 회복합니다. 엘리트 및 전문가 적을 처치하면 강인함을 {toughness_elites:%s} 회복합니다.

**수정 기본 번역**

원거리 공격으로 적을 처치하면 강인함을 {toughness:%s} 회복합니다. 엘리트 및 스페셜리스트 적을 처치하면 강인함을 {toughness_elites:%s} 회복합니다.

수정 이유: 기존 모드 용어 통일

## 380. loc_talent_broker_passive_stamina_grants_atk_speed_desc

유형: 기존 수정

**현재 영문**

{attack_speed_increase:%s} increased Melee Attack Speed for each current Stamina.

**기존 기본 번역**

현재 남아있는 스태미너당 근접 공격 속도가 {attack_speed_increase:%s} 증가합니다.

**수정 기본 번역**

현재 남아있는 스태미나당 근접 공격 속도가 {attack_speed_increase:%s} 증가합니다.

수정 이유: 용어 오타 수정

## 381. loc_talent_broker_passive_stimm_cd_on_kill_desc

유형: 기존 수정

**현재 영문**

Kills replenish {restore:%s} of your {stimm:%s} Cooldown. Killing {toxin:%s} infected Enemies instead replenishes {restore_toxined:%s}.

**기존 기본 번역**

적을 죽이면 자극제 쿨다운이 {restore:%s} 재생됩니다. {toxin:%s}에 감염된 적을 처치하면 {restore_toxined:%s} 재생됩니다.

**수정 기본 번역**

적을 처치하면 {stimm:%s}의 쿨다운을 {restore:%s} 회복합니다. {toxin:%s}에 감염된 적을 처치하면 대신 {restore_toxined:%s} 회복합니다.

수정 이유: 자극제 이름 변수 복원 및 대체 회복량 명시

## 382. loc_talent_broker_passive_stun_immunity_on_toughness_broken_desc

유형: 기존 수정

**현재 영문**

Gain Stun Immunity for {duration:%s}s and restore {toughness:%s} Toughness when Toughness is broken. {cooldown:%s}s Cooldown.

**기존 기본 번역**

강인함이 파괴되면 {duration:%s}초 동안 강인함을 {toughness:%s} 회복하며, 기절 면역 상태가 됩니다. {cooldown:%s}초마다 발동할 수 있습니다.

**수정 기본 번역**

강인함이 파괴되면 강인함을 {toughness:%s} 회복하고 {duration:%s}초 동안 기절에 면역이 됩니다. {cooldown:%s}초에 한 번만 발동합니다.

수정 이유: 즉시 강인함 회복과 면역 지속시간 분리

## 383. loc_talent_broker_passive_toxin_infected_enemies_take_increased_damage_desc

유형: 기존 수정

**현재 영문**

When infecting an Enemy with {toxin:%s}, increase their damage taken by {damage_taken:%s} from all sources for {duration:%s}s.

**기존 기본 번역**

적이 {toxin:%s}에 감염됐을 때, {duration:%s}초 동안 대상이 모든 종류의 공격으로부터 받는 대미지가 {damage_taken:%s} 증가합니다.

**수정 기본 번역**

적을 {toxin:%s}에 감염시키면, {duration:%s}초 동안 해당 적이 모든 피해원으로부터 받는 대미지가 {damage_taken:%s} 증가합니다.

수정 이유: 플레이어가 감염시키는 시점이라는 조건과 from all sources를 명시합니다.

## 384. loc_talent_broker_passive_toxin_spread_on_kills_desc_02

유형: 기존 수정

**현재 영문**

Killing an Elite Enemy with a Melee Attack infects up to {max_targets:%s} enemies within {radius:%s}m of the target with {toxin_stacks:%s} stacks of {toxin:%s}.

**기존 기본 번역**

근접 공격으로 엘리트를 처치하면 {radius:%s}미터 안에 있는 최대 {max_targets:%s}명의 적들에게 {toxin:%s} 중첩 {toxin_stacks:%s}개를 부여합니다.

**수정 기본 번역**

근접 공격으로 엘리트를 처치하면, 처치한 적을 중심으로 {radius:%s}미터 이내에 있는 최대 {max_targets:%s}명의 적에게 {toxin:%s}를 {toxin_stacks:%s}회 중첩시킵니다.

수정 이유: of the target을 반영해 효과 범위의 중심이 처치한 적이라는 점을 명시합니다.

## 385. loc_talent_buff_cooldown_on_melee_kills

유형: 기존 수정

**현재 영문**

While active, Melee Kills grant {cooldown:%s} Ability Cooldown Regeneration for {duration:%s}s.

**기존 기본 번역**

활성화 된 동안, 근접 무기로 적을 처치하면 {duration:%s}초 동안 능력 쿨다운이 {cooldown:%s} 재생됩니다.

**수정 기본 번역**

활성화 된 동안, 근접 무기로 적을 처치하면 {duration:%s}초 동안 능력 쿨다운 재생 속도가 {cooldown:%s} 증가합니다.

수정 이유: 즉시 쿨다운 회복과 재생속도 증가 구분

## 386. loc_talent_buff_cooldown_on_ranged_kills

유형: 기존 수정

**현재 영문**

While active, Ranged Kills grant {cooldown:%s} Ability Cooldown Regeneration for {duration:%s}s.

**기존 기본 번역**

활성화 된 동안, 원거리 무기로 적을 처치하면 {duration:%s}초 동안 능력 쿨다운이 {cooldown:%s} 재생됩니다.

**수정 기본 번역**

활성화 된 동안, 원거리 무기로 적을 처치하면 {duration:%s}초 동안 능력 쿨다운 재생 속도가 {cooldown:%s} 증가합니다.

수정 이유: 즉시 쿨다운 회복과 재생속도 증가 구분

## 387. loc_talent_execution_order_command_applies_brittleness_description

유형: 기존 수정

**현재 영문**

You gain {rending:%s} Rending for {time:%s}s after a Marked Kill.

**기존 기본 번역**

표식을 가진 적을 처치하면 찢기가 {rending:%s} 증가합니다.

**수정 기본 번역**

표식을 가진 적을 처치하면 {time:%s}초 동안 찢기가 {rending:%s} 증가합니다.

수정 이유: 지속시간 누락 복원

## 388. loc_talent_ogryn_carapace_armor_trigger_on_zero_stacks_new_desc

유형: 기존 수정

**현재 영문**

When {talent_name:%s} reaches {stacks:%s} stacks or below, you push back Enemies and Replenish {toughness_replenish:%s} Toughness.

This effect can occur once every {cooldown:%s}s.

**기존 기본 번역**

{talent_name:%s}이 {stacks:%s} 중첩 이하일 때, 적을 밀어내면 강인함을 {toughness_replenish:%s} 회복합니다.

{cooldown:%s}초마다 발동할 수 있습니다.

**수정 기본 번역**

{talent_name:%s}이 {stacks:%s}중첩 이하로 떨어지면 주변 적을 밀어내고 강인함을 {toughness_replenish:%s} 회복합니다.

{cooldown:%s}초에 한 번만 발동합니다.

수정 이유: 자동 발동 결과인 밀어내기를 발동 조건으로 옮긴 오류 수정

## 389. loc_talent_ogryn_combat_ability_special_ammo_replenish_desc

유형: 기존 수정

**현재 영문**

Swaps to and reloads your Ranged Weapon. You have {ranged_attack_speed:%s} Rate of Fire, {reload_speed:%s} Reload Speed, {reduced_move_penalty:%s} Reduced Braced Movement Speed penalties, and gain {damage:%s} Close Range Damage for the next {duration:%s}s. {ammo_return_percent:%s} of Ammo consumed while active is returned to your Reserve once finished.

Base Cooldown: {cooldown:%s}s

**기존 기본 번역**

원거리 무기로 교체하고 즉시 재장전합니다. {duration:%s}초 동안 발사 속도가 {ranged_attack_speed:%s}, 재장전 속도가 {reload_speed:%s}, 근거리에서 입히는 원거리 공격 대미지가 {damage:%s} 증가하며, 견착 시 이동 속도 패널티가 {reduced_move_penalty:%s} 감소합니다. 전투 능력이 활성화 상태일 때 소모한 탄약의 {ammon_return_percent:%s}가 전투 능력이 비활성화 되면 예비 탄약으로 반환됩니다.

기본 쿨다운: {cooldown:%s}초

**수정 기본 번역**

원거리 무기로 교체하고 즉시 재장전합니다. {duration:%s}초 동안 발사 속도가 {ranged_attack_speed:%s}, 재장전 속도가 {reload_speed:%s}, 근거리에서 입히는 원거리 공격 대미지가 {damage:%s} 증가하며, 견착 시 이동 속도 패널티가 {reduced_move_penalty:%s} 감소합니다. 전투 능력이 활성화 상태일 때 소모한 탄약의 {ammo_return_percent:%s}가 전투 능력이 비활성화 되면 예비 탄약으로 반환됩니다.

기본 쿨다운: {cooldown:%s}초

수정 이유: 탄약 반환량 변수 철자 오류 수정

## 390. loc_talent_ogryn_crit_chance_on_kill_desc

유형: 기존 수정

**현재 영문**

Killing an Enemy grants {crit_chance:%s} Critical Chance for {duration:%s}s. Stacks {max_stacks:%s} times.

**기존 기본 번역**

적을 처치하면 {duration:%s}초 동안 치명타 확률이 {crit_chance:%s} 증가합니다.

**수정 기본 번역**

적을 처치하면 {duration:%s}초 동안 치명타 확률이 {crit_chance:%s} 증가합니다. 최대 {max_stacks:%s}회 중첩됩니다.

수정 이유: 중첩 상한 누락 복원

## 391. loc_talent_ogryn_damage_reduction_after_elite_kill_desc

유형: 기존 수정

**현재 영문**

{damage_reduction:%s} Damage Resistance on Elite Kill or Specialist Kill. Lasts {duration:%s}s.

**기존 기본 번역**

엘리트 또는 스페셜리스트를 처치하면 대미지 저항력이 {damage_reduction:%s} 증가합니다.

**수정 기본 번역**

엘리트 또는 스페셜리스트를 처치하면 {duration:%s}초 동안 대미지 저항력이 {damage_reduction:%s} 증가합니다.

수정 이유: 지속시간 누락 복원

## 392. loc_talent_ogryn_damage_reduction_on_high_stamina_desc

유형: 기존 수정

**현재 영문**

{damage_taken:%s} Damage Resistance while above {stamina:%s} Stamina.

**기존 기본 번역**

스태미나가 {stamina:%s} 이상일 때 대미지 저항력이 {damage_taken:%s} 증가합니다.

**수정 기본 번역**

스태미나가 {stamina:%s} 초과일 때 대미지 저항력이 {damage_taken:%s} 증가합니다.

수정 이유: above 경계 조건 반영

## 393. loc_talent_ogryn_fully_charged_attacks_gain_damage_and_stagger

유형: 추가 ID 덮어쓰기

**현재 영문**

Crunch!

**기존 기본 번역**

부셔!

**수정 기본 번역**

부숴!

수정 이유: 부수다 활용형의 맞춤법 수정

## 394. loc_talent_ogryn_protect_allies_desc

유형: 기존 수정

**현재 영문**

On Ally getting Toughness Broken, gain  {power:%s} Strength, and {toughness_damage_reduction:%s} Toughness Damage Reduction for {duration:%s}s. {cooldown:%s}s Cooldown.

On Ally getting Knocked Down, gain Stun Immunity, and {revive_speed:%s} Revive Speed for {duration:%s}s.

**기존 기본 번역**

아군의 강인함이 파괴되면 {duration:%s}초 동안 파워가 {power:%s} 증가하고, 대미지 저항력이 {toughness_damage_reduction:%s} 증가합니다. {cooldown:%s}초마다 발동할 수 있습니다.

아군이 쓰러지면 {duration:%s}초 동안 기절 면역 상태가 되며 구조 속도가 {revive_speed:%s} 증가합니다.

**수정 기본 번역**

아군의 강인함이 파괴되면 {duration:%s}초 동안 파워가 {power:%s} 증가하고, 받는 강인함 대미지 감소율이 {toughness_damage_reduction:%s} 증가합니다. {cooldown:%s}초마다 발동할 수 있습니다.

아군이 쓰러지면 {duration:%s}초 동안 기절 면역 상태가 되며 구조 속도가 {revive_speed:%s} 증가합니다.

수정 이유: 강인함 피해 감소를 모든 피해 저항으로 옮긴 오류 수정

## 395. loc_talent_ogryn_taunt_restore_toughness_new_desc

유형: 기존 수정

**현재 영문**

{talent_name:%s} and its Repeats, Replenish {tougness:%s} Toughness and an additional {toughness_per_hit:%s} each 1s per enemy affected, up to {max:%s}, for {duration:%s}s. 

**기존 기본 번역**

{talent_name:%s}를 발동하고, 능력이 재발동될 때마다 강인함을 {tougness:%s} 회복하며 도발 당한 적 하나당 강인함을 {toughness_per_hit:%s}씩, 최대 {max:%s}를 추가로 회복합니다. {duration:%s}초 동안 지속됩니다.

**수정 기본 번역**

{talent_name:%s}를 발동하거나 효과가 반복될 때 강인함을 {tougness:%s} 회복합니다. 또한 영향을 받은 적 한 명당 매초 강인함을 {toughness_per_hit:%s}씩, 최대 {max:%s}까지 추가로 회복합니다. {duration:%s}초 동안 지속됩니다.

수정 이유: 추가 강인함 회복이 매초 발동함을 복원; 원문 변수의 철자 보존

## 396. loc_talent_ogryn_toughness_gain_increase_on_low_health_desc

유형: 기존 수정

**현재 영문**

{toughness_multiplier:%s} Toughness Replenishment while below {health:%s} Health. 

**기존 기본 번역**

체력이 {health:%s} 이하일 때 강인함 회복량이 {toughness_multiplier:%s} 증가합니다.

**수정 기본 번역**

체력이 {health:%s} 미만일 때 강인함 회복량이 {toughness_multiplier:%s} 증가합니다.

수정 이유: below 경계 조건 반영

## 397. loc_talent_psyker_ability_increase_brain_burst_speed_desc

유형: 기존 수정

**현재 영문**

Using your Combat Ability makes your {talent_name:%s} charge {smite_attack_speed:%s} faster and generate {warp_charge_cost:%s} less Peril for {duration:%s}s.

**기존 기본 번역**

전투 능력을 사용하면 {talent_name:%s}의 충전 속도가 {smite_attack_speed:%s} 빨라지고 {duration:%s}초 동안 위험을 {warp_charge_cost:%s} 적게 생성합니다.

**수정 기본 번역**

전투 능력을 사용하면 {duration:%s}초 동안 {talent_name:%s}의 충전 속도가 {smite_attack_speed:%s} 빨라지고 위험 생성량이 {warp_charge_cost:%s} 감소합니다.

수정 이유: 지속시간이 충전 속도와 위험 생성량 모두에 적용됨을 명시

## 398. loc_talent_psyker_brain_burst_improved_description

유형: 기존 수정

**현재 영문**

Charge up your Psychic Power and release it to deal immense Damage to a Single Enemy.

This is an augmented version of {talent_old:%s} dealing {damage:%s} Damage.

**기존 기본 번역**

사이킥 능력을 충전했다 해방하여 단일 대상에게 강력한 대미지를 입힙니다. 플랙 및 갑각 방어구를 입은 적에게 효과적입니다.

{talent_old:%s}의 증강된 버전으로 대미지가 {damage:%s} 증가합니다.

**수정 기본 번역**

사이킥 능력을 충전했다 해방하여 단일 대상에게 강력한 대미지를 입힙니다.

{talent_old:%s}의 증강된 버전으로 대미지가 {damage:%s} 증가합니다.

수정 이유: 현재 원문에 없는 방어구별 효율 설명 제거

## 399. loc_talent_psyker_chain_lightning_improved_target_buff_alt_description

유형: 기존 수정

**현재 영문**

Enemies Electrocuted by you take {damage:%s} increased Base Damage from all sources.

**기존 기본 번역**

{talent_name:%s}에 감전된 적들이 모든 종류의 공격으로부터 받는 기본 대미지가 {damage:%s} 증가합니다.

**수정 기본 번역**

자신이 감전시킨 적이 모든 피해원으로부터 받는 기본 대미지가 {damage:%s} 증가합니다.

수정 이유: 특정 대공세만이 아닌 자신의 모든 감전으로 확장된 원문 반영

## 400. loc_talent_psyker_combat_ability_shield_description

유형: 기존 수정

**현재 영문**

Spawns a psychic shield in front of you for {duration:%s}s. The shield blocks Enemy Ranged Attacks, while you and Allies can still shoot through.

Base Cooldown: {cooldown:%s}s.

**기존 기본 번역**

전방에 {duration:%s}초 동안 유지되는 사이킥 실드를 소환합니다. 실드는 적의 원거리를 차단하지만, 자신과 아군의 원거리 공격은 관통할 수 있습니다.

기본 쿨다운: {cooldown:%s}초

**수정 기본 번역**

전방에 {duration:%s}초 동안 유지되는 사이킥 실드를 소환합니다. 실드는 적의 원거리 공격을 차단하지만, 자신과 아군의 원거리 공격은 관통할 수 있습니다.

기본 쿨다운: {cooldown:%s}초

수정 이유: 누락된 명사 보완

## 401. loc_talent_psyker_damage_resistance_stun_immunity_desc

유형: 기존 수정

**현재 영문**

{dr:%s} Damage Resistance, in addition, while at Critical Peril, and for {duration:%s}s afterwards, you are Stun Immune.

**기존 기본 번역**

위험이 치명적인 수준일 때 대미지 저항력이 {dr:%s} 증가합니다. 또한 {duration:%s}초 후에 기절 면역 상태가 됩니다.

**수정 기본 번역**

대미지 저항력이 {dr:%s} 증가합니다. 또한 위험이 치명적인 수준인 동안과 그 상태가 끝난 뒤 {duration:%s}초 동안 기절에 면역이 됩니다.

수정 이유: 상시 저항력과 조건부 면역을 분리; 이후 지속시간을 발동 지연으로 옮긴 오류 수정

## 402. loc_talent_psyker_damage_to_peril_conversion_desc

유형: 기존 수정

**현재 영문**

While below Critical Peril, {percent:%s} of Damage Taken is converted into Peril.

**기존 기본 번역**

위험이 치명적인 수준 이하일 때, 받은 대미지의 {percent:%s}가 위험으로 변환됩니다.

**수정 기본 번역**

위험이 치명적인 수준 미만일 때, 받은 대미지의 {percent:%s}가 위험으로 변환됩니다.

수정 이유: below 경계 조건 반영

## 403. loc_talent_psyker_empowered_ability_description

유형: 기존 수정

**현재 영문**

Kills have a {chance:%s} chance to Empower your next Blitz.

Empowered {blitz_one:%s}:
{smite_cost:%s} Peril Cost Reduction
{smite_attack_speed:%s} Cast time Reduction
{smite_damage:%s} Damage

Empowered {blitz_two:%s}:
{chain_lightning_damage:%s} Damage
{chain_lightning_jump_time_multiplier:%s} faster spread between enemies

Empowered {blitz_three:%s}:
{throwing_knives_cost:%s} Peril Cost Reduction.
Base Damage increase from {throwing_knives_old_damage:%s} to {throwing_knives_new_damage:%s}.
Does not consume any charges.

**기존 기본 번역**

적 처치 시 {chance:%s} 확률로 대공세를 강화합니다.

강화된 {blitz_one:%s}:
- 위험 생성량 {smite_cost:%s} 감소
- 시전 시간 {smite_attack_speed:%s} 감소
- 대미지 {smite_damage:%s} 증가

강화된 {blitz_two:%s}:
- 대미지 {chain_lightning_damage:%s} 증가
- 적 사이에서 {chain_lightning_jump_time_multiplier:%s} 더 빠르게 확산

강화된 {blitz_three:%s}:
- 위험 생성량 {throwing_knives_cost:%s} 감소
- 기본 대미지가 {throwing_knives_old_damage:%s}에서 {throwing_knives_new_damage:%s}으로 증가합니다.
- 충전을 소진하지 않습니다.

**수정 기본 번역**

적 처치 시 {chance:%s} 확률로 다음 대공세를 강화합니다.

강화된 {blitz_one:%s}:
- 위험 생성량 {smite_cost:%s} 감소
- 시전 시간 {smite_attack_speed:%s} 감소
- 대미지 {smite_damage:%s} 증가

강화된 {blitz_two:%s}:
- 대미지 {chain_lightning_damage:%s} 증가
- 적 사이에서 {chain_lightning_jump_time_multiplier:%s} 더 빠르게 확산

강화된 {blitz_three:%s}:
- 위험 생성량 {throwing_knives_cost:%s} 감소
- 기본 대미지가 {throwing_knives_old_damage:%s}에서 {throwing_knives_new_damage:%s}으로 증가합니다.
- 충전을 소진하지 않습니다.

수정 이유: 다음 대공세에 한정되는 효과 명시

## 404. loc_talent_psyker_force_field_charges_description

유형: 기존 수정

**현재 영문**

{talent_name:%s} now holds up to {max_charges:%s} charges.

**기존 기본 번역**

{talent_name:%s}를 최대 {max_charges:%s}회까지 충전됩니다.

**수정 기본 번역**

{talent_name:%s}가 최대 {max_charges:%s}회까지 충전됩니다.

수정 이유: 조사 오류 수정

## 405. loc_talent_psyker_improved_dodge_description

유형: 기존 수정

**현재 영문**

Increase Effective Dodges by {extra_consecutive_dodges:%s} and time considered Dodging by {dodge_linger_time:%s}.

**기존 기본 번역**

회피 지속 시간이 {dodge_linger_time:%s} 증가합니다. 회피가 비효율적이게 되기까지 필요한 회피 횟수가 {extra_consecutive_dodges:%s} 증가합니다.

**수정 기본 번역**

유효 회피 횟수가 {extra_consecutive_dodges:%s} 증가하고, 회피 중으로 판정되는 시간이 {dodge_linger_time:%s} 늘어납니다.

수정 이유: 회피 동작 자체의 시간과 회피 판정 시간을 구분

## 406. loc_talent_psyker_overcharge_infinite_casting_desc

유형: 기존 수정

**현재 영문**

{talent_name:%s} now also prevents overloading from Perils of the Warp, during its lingering effect.

**기존 기본 번역**

{talent_name:%s}이 활성화 된 상태일 때 워프 위험 과부하를 방지합니다.

**수정 기본 번역**

{talent_name:%s}의 잔여 효과가 지속되는 동안에도 워프 위험 과부하를 방지합니다.

수정 이유: 활성 시간과 종료 후 잔여 효과 시간의 차이 반영

## 407. loc_talent_psyker_reload_speed_warp_desc

유형: 기존 수정

**현재 영문**

{reload_speed:%s} Reload Speed while below {threshold:%s} Peril. On Reload generate up to {warp_charge:%s} Peril based on the Percentage of the Clip Restored.

**기존 기본 번역**

위험이 {threshold:%s} 이하일 때 재장전 속도가 {reload_speed:%s} 증가합니다. 재장전 시 재장전 한 탄창의 비율에 따라 위험이 최대 {warp_charge:%s}까지 생성됩니다.

**수정 기본 번역**

위험이 {threshold:%s} 미만일 때 재장전 속도가 {reload_speed:%s} 증가합니다. 재장전 시 재장전 한 탄창의 비율에 따라 위험이 최대 {warp_charge:%s}까지 생성됩니다.

수정 이유: below 경계 조건 반영

## 408. loc_talent_psyker_stat_mix_desc

유형: 기존 수정

**현재 영문**

{peril_reduction:%s} Passive Quelling, {stamina:%s} Stamina, and {toughness_replenish:%s} Toughness Replenishment.

**기존 기본 번역**

지속 평정 효과가 {peril_reduction:%s} 감소하고, 스태미나가 {stamina:%s} 증가하며, 강인함을 {toughness_replenish:%s} 회복합니다.

**수정 기본 번역**

지속 평정 효과가 {peril_reduction:%s} 감소하고, 스태미나가 {stamina:%s}, 강인함 회복량이 {toughness_replenish:%s} 증가합니다.

수정 이유: 강인함 회복량 증가를 즉시 회복으로 옮긴 오류 수정

## 409. loc_talent_veteran_ally_kills_increase_damage_description

유형: 기존 수정

**현재 영문**

{proc_chance:%s} chance of {damage:%s} Base Damage, {melee_impact:%s} Melee Impact & {suppression:%s} Suppression for {duration:%s}s whenever an Ally kills an Enemy.

**기존 기본 번역**

아군이 적을 처치할 때마다 {proc_chance:%s} 확률로 기본 대미지가 {damage:%s}, 근접 무기의 충격이 {melee_impact:%s}, 제압이 {suppression:%s} 증가합니다.

**수정 기본 번역**

아군이 적을 처치할 때마다 {proc_chance:%s} 확률로 {duration:%s}초 동안 기본 대미지가 {damage:%s}, 근접 충격이 {melee_impact:%s}, 제압이 {suppression:%s} 증가합니다.

수정 이유: 지속시간 누락 복원

## 410. loc_talent_veteran_combat_ability_coherency_outlines_description

유형: 기존 수정

**현재 영문**

{talent_name:%s} now outlines Elite & Specialist Enemies for Allies in Coherency for {duration:%s}s.

**기존 기본 번역**

{talent_name:%s}로 강조 표시된 엘리트 및 스페셜리스트가 이제 {duration:%s}초 동안 아군에게도 보입니다.

**수정 기본 번역**

{talent_name:%s}로 강조 표시된 엘리트 및 스페셜리스트가 이제 {duration:%s}초 동안 단결 상태의 아군에게도 보입니다.

수정 이유: 단결 조건 누락 복원

## 411. loc_talent_veteran_combat_ability_extra_charge_description

유형: 기존 수정

**현재 영문**

Your Combat Ability gains {charges:%s} charge, but {ability_cooldown:%s} Cooldown.

**기존 기본 번역**

전투 능력이 {charges:%s}회까지 충전되지만, 쿨다운이 {ability_cooldown:%s} 증가합니다.

**수정 기본 번역**

전투 능력의 충전 횟수가 {charges:%s}회 추가되지만, 쿨다운이 {ability_cooldown:%s} 증가합니다.

수정 이유: 추가 충전 수를 총 충전 수로 옮긴 오류 수정

## 412. loc_talent_veteran_elite_kills_grant_ammo_coop_cd_desc

유형: 기존 수정

**현재 영문**

Replenish {ammo:%s} Ammo for you and Allies in Coherency whenever any of you Kill an Elite or Specialist Enemy. This can only occur once every {cooldown:%s}s.

**기존 기본 번역**

엘리트 또는 스페셜리스트를 처치할 때마다 자신과 단결 상태의 아군에게 탄약을 {ammo:%s} 보급합니다. {cooldown:%s}초에 한 번 씩만 발동할 수 있습니다.

**수정 기본 번역**

자신 또는 단결 상태의 아군이 엘리트나 스페셜리스트를 처치할 때마다, 자신과 단결 상태의 아군에게 탄약을 {ammo:%s} 보급합니다. {cooldown:%s}초에 한 번만 발동합니다.

수정 이유: 아군 처치로도 발동하는 조건 명시

## 413. loc_talent_veteran_elite_kills_grant_ammo_coop_improved_cd_desc

유형: 기존 수정

**현재 영문**

Replenish {ammo_2:%s} Ammo for you and Allies in Coherency whenever any of you Kill an Elite or Specialist Enemy. This can only occur once every {cooldown:%s}s.

This is an augmented version of {talent_name:%s}.

**기존 기본 번역**

엘리트 또는 스페셜리스트를 처치할 때마다 자신과 단결 상태의 아군에게 탄약을 {ammo_2:%s}씩 보급합니다.

{talent_name:%s}의 증강된 버전입니다.

**수정 기본 번역**

자신 또는 단결 상태의 아군이 엘리트나 스페셜리스트를 처치할 때마다, 자신과 단결 상태의 아군에게 탄약을 {ammo_2:%s} 보급합니다. {cooldown:%s}초에 한 번만 발동합니다.

{talent_name:%s}의 증강된 버전입니다.

수정 이유: 처치 주체와 재발동 대기시간 누락 복원

## 414. loc_talent_veteran_ranged_power_out_of_melee_new_desc

유형: 기존 수정

**현재 영문**

{ranged_damage:%s} Base Ranged Damage when you have avoided Melee Attacks for {cooldown:%s}s.

**기존 기본 번역**

근접 공격을 회피하면 {cooldown:%s}초 동안 기본 원거리 대미지가 {ranged_damage:%s} 증가합니다.

**수정 기본 번역**

{cooldown:%s}초 동안 근접 공격에 맞지 않으면 기본 원거리 대미지가 {ranged_damage:%s} 증가합니다.

수정 이유: 피격을 피해야 하는 시간을 회피 후 효과 지속시간으로 옮긴 오류 수정

## 415. loc_talent_veteran_ranged_stance_toughness_description

유형: 기존 수정

**현재 영문**

Enter Ranged Stance for {duration:%s}s. When in Ranged Stance you instantly equip your ranged weapon, deal {damage:%s} Ranged Damage, {weakspot_damage:%s} Ranged Weakspot Damage, replenish {toughness:%s} Toughness each second, and your Spread and Recoil are greatly reduced.

Human-sized Elite Enemies and Specialist Enemies are highlighted for {duration:%s}s.

Killing a highlighted Enemy refreshes the duration of its bonuses for {refresh_duration:%s}s.

Base Cooldown: {cooldown:%s}s.

This is an augmented version of {old_talent_name:%s}.

**기존 기본 번역**

{duration:%s}초 동안 사격 자세를 취합니다. 사격 자세를 취하면 원거리 무기를 즉시 장착하고, 원거리 무기의 대미지가 {damage:%s}, 약점 대미지가 {weakspot_damage:%s} 증가합니다. 또한 탄퍼짐과 반동도 크게 감소합니다.

{duration:%s}초 동안 인간 크기의 엘리트와 스페셜리스트가 강조 표시됩니다.

강조 표시된 적을 처치하면 지속 시간이 {duration:%s} 연장됩니다.

기본 쿨다운: {cooldown:%s}

{old_talent_name:%s}의 강화 버전입니다.

**수정 기본 번역**

{duration:%s}초 동안 사격 자세를 취합니다. 원거리 무기를 즉시 장착하고, 원거리 대미지가 {damage:%s}, 원거리 약점 대미지가 {weakspot_damage:%s} 증가하며, 매초 강인함을 {toughness:%s} 회복합니다. 탄퍼짐과 반동도 크게 감소합니다.

{duration:%s}초 동안 인간 크기의 엘리트와 스페셜리스트가 강조 표시됩니다.

강조 표시된 적을 처치하면 효과의 남은 지속시간이 {refresh_duration:%s}초로 갱신됩니다.

기본 쿨다운: {cooldown:%s}초

{old_talent_name:%s}의 증강된 버전입니다.

수정 이유: 강인함 회복 누락, 갱신 시간 변수 및 초 단위 수정

## 416. loc_talent_veteran_replenish_toughness_and_boost_allies_desc

유형: 기존 수정

**현재 영문**

When you kill an Enemy with a Ranged Attack, Allies within {radius:%s} metres of the target Replenish {toughness:%s} Toughness & receive {base_damage:%s} to all Base Damage  for {duration:%s}s.

**기존 기본 번역**

원거리 공격으로 적을 처치하면, 목표로부터 {radius:%s}미터 내에 있는 아군의 강인함을 {toughness:%s} 회복하고, {duration:%s}초 동안 모든 기본 대미지가 {base_damage:%s} 증가합니다.

**수정 기본 번역**

원거리 공격으로 적을 처치하면, 목표로부터 {radius:%s}미터 내의 아군이 강인함을 {toughness:%s} 회복하고 {duration:%s}초 동안 모든 기본 대미지가 {base_damage:%s} 증가합니다.

수정 이유: 공격력 증가도 범위 내 아군이 받는 효과임을 명확히 함

## 417. loc_talent_veteran_snipers_focus_duration_desc

유형: 기존 수정

**현재 영문**

Ranged Weakspot kills grant {stacks:%s} stack(s) of Focus. Up to {max_stacks:%s} Max Stacks. Lasts {duration:%s}s. Stacks are refreshed on Weakspot Hit and decay one at a time.

Each stack of Focus grants {power:%s} Ranged Finesse Strength, and {reload_speed:%s} Reload Speed.

**기존 기본 번역**

원거리 공격으로 약점 처치 시 {stacks:%s}개의 집중을 획득합니다. 최대 {max_stacks:%s}개까지 중첩되며, {duration:%s}초 동안 지속됩니다. 약점 명중 시 중첩 갯수가 갱신되며, 한 번에 하나씩 줄어듭니다.

집중 중첩 하나당 원거리 무기의 기교 파워가 {power:%s}씩, 재장전 속도가 {reload_speed:%s}씩 증가합니다.

원거리 무기로 약점을 맞히면 {grace_time_hit:%s}초 동안 중첩을 잃지 않고 움직일 수 있으며, 원거리 무기로 약점 처치를 하면 {grace_time:%s}초 동안 집중 중첩을 잃지 않고 이동할 수 있습니다.

**수정 기본 번역**

원거리 약점 처치 시 집중을 {stacks:%s}중첩 획득합니다. 최대 {max_stacks:%s}회 중첩되며 {duration:%s}초 동안 지속됩니다. 약점 명중 시 지속시간이 갱신되고, 중첩은 한 번에 하나씩 줄어듭니다.

집중 중첩 하나당 원거리 기교 파워가 {power:%s}, 재장전 속도가 {reload_speed:%s} 증가합니다.

수정 이유: 현재 원문에서 사라진 이동 유예시간 설명 및 변수를 제거하고 갱신 대상 수정

## 418. loc_talent_veteran_tdr_on_high_toughness_desc

유형: 기존 수정

**현재 영문**

{toughness_damage_reduction:%s} Reduced Toughness Damage if above {toughness_percent:%s} Toughness.

**기존 기본 번역**

현재 보유 중인 강인함이 {toughness_percent:%s} 이상일 때, 받는 강인함 대미지 감소율이 {toughness_damage_reduction:%s} 증가합니다.

**수정 기본 번역**

현재 보유 중인 강인함이 {toughness_percent:%s} 초과일 때, 받는 강인함 대미지 감소율이 {toughness_damage_reduction:%s} 증가합니다.

수정 이유: above 경계 조건 반영

## 419. loc_talent_veteran_toughness_bonus_leaving_invisibility_desc

유형: 기존 수정

**현재 영문**

{talent_name:%s} provides {tdr%s} Toughness Damage Reduction for {duration%s}s on leaving Stealth.

**기존 기본 번역**

은신이 해제되면 {duration%s}초 동안 받는 강인함 대미지 감소율이 {tdr%s} 증가합니다.

**수정 기본 번역**

{talent_name:%s}의 은신이 해제되면 {duration%s}초 동안 받는 강인함 대미지 감소율이 {tdr%s} 증가합니다.

수정 이유: 전투 능력 이름 변수 복원

## 420. loc_talent_veteran_toughness_on_weakspot_kill_alt_desc

유형: 기존 수정

**현재 영문**

Replenish {toughness:%s} Toughness and gain {toughness_damage_reduction:%s} Toughness Damage Reduction for {duration:%s}s on Ranged Weakspot Kill. Stacks {stacks:%s} times. Stacks Decay one at a time.

**기존 기본 번역**

원거리 무기로 적의 약점을 맞혀 처치하면 {duration:%s}초 동안 강인함을 {toughness:%s} 회복하고 받는 강인함 대미지 감소율이 {toughness_damage_reduction:%s} 증가합니다. 최대 {stacks:%s}회 중첩됩니다. 한 번에 하나씩 줄어듭니다.

**수정 기본 번역**

원거리 약점 처치 시 강인함을 {toughness:%s} 회복하고, {duration:%s}초 동안 받는 강인함 대미지 감소율이 {toughness_damage_reduction:%s} 증가합니다. 최대 {stacks:%s}회 중첩되며, 중첩은 한 번에 하나씩 줄어듭니다.

수정 이유: 강인함 회복과 지속되는 피해 감소 효과 분리

## 421. loc_talent_veteran_weapon_switch_new_description

유형: 기존 수정

**현재 영문**

Gain Ranged Specialist on Melee Kills (Stacks {ranged_stacks:%s} times). Gain Melee Specialist on Ranged Kill (Stacks {melee_stacks:%s} times.)

When you wield your Ranged Weapon, you activate your Ranged Specialist effect to gain {ranged_attack_speed:%s} Ranged Attack Speed, {reload_speed:%s} Reload Speed, as well as {ranged_crit_chance:%s} Ranged Critical Hit Chance on your next shot, per stack. Lasts {ranged_duration:%s}s.

When you wield your Melee Weapon, you activate your Melee Specialist effect, to gain {melee_attack_speed:%s} Melee Attack Speed, and {dodge_modifier:%s} Dodge Speed and Dodge Distance. Lasts {melee_duration:%s}s.

**기존 기본 번역**

근접 공격으로 적을 처치하면 최대 {ranged_stacks:%s}회 중첩되는 원거리전 전문가를 획득합니다. 원거리 공격으로 적을 처치하면 최대 {melee_stacks:%s}회 중첩되는 근접전 전문가를 획득합니다.

원거리 무기를 장착하면 원거리전 전문가 효과가 발동되며, 중첩당 원거리 공격 속도가 {ranged_attack_speed:%s}, 재장전 속도가 {reload_speed:%s} 증가하고, 다음 공격의 원거리 치명타 공격 확률이 {ranged_crit_chance:%s} 증가합니다. {ranged_duration:%s}초 동안 지속됩니다.

근접 무기를 장착하면 근접전 전문가 효과가 발동되며, 중첩당 근접 공격 속도가 {melee_attack_speed:%s}, 회피 속도와 회피 거리가 {dodge_modifier:%s} 증가합니다. {melee_duration:%s}초 동안 지속됩니다.

**수정 기본 번역**

근접 공격으로 적을 처치하면 최대 {ranged_stacks:%s}회 중첩되는 원거리전 전문가를 획득합니다. 원거리 공격으로 적을 처치하면 최대 {melee_stacks:%s}회 중첩되는 근접전 전문가를 획득합니다.

원거리 무기를 장착하면 원거리전 전문가 효과가 발동되며, 중첩당 원거리 공격 속도가 {ranged_attack_speed:%s}, 재장전 속도가 {reload_speed:%s} 증가하고, 다음 공격의 원거리 치명타 공격 확률이 {ranged_crit_chance:%s} 증가합니다. {ranged_duration:%s}초 동안 지속됩니다.

근접 무기를 장착하면 근접전 전문가 효과가 발동되며, 근접 공격 속도가 {melee_attack_speed:%s}, 회피 속도와 회피 거리가 {dodge_modifier:%s} 증가합니다. {melee_duration:%s}초 동안 지속됩니다.

수정 이유: 원문에서 근접 효과에 명시되지 않은 중첩당 배율 제거

## 422. loc_talent_veteran_weapon_switch_replenish_ammo_description

유형: 기존 수정

**현재 영문**

Activating Ranged Specialist replenishes up to {ammo:%s} of your missing ammo in your Clip from your Reserve, rounded up, for each stack.

**기존 기본 번역**

원거리전 전문가가 활성화 되면 중첩당 탄창에서 소모한 탄약의 최대 {ammo:%s}까지 예비 탄약으로 탄창에 보충합니다.

**수정 기본 번역**

원거리전 전문가가 활성화 되면 중첩당 탄창에서 소모한 탄약의 최대 {ammo:%s}까지 예비 탄약으로 탄창에 보충합니다. 소수점 이하는 올림합니다.

수정 이유: rounded up 누락 복원

## 423. loc_talent_veteran_weapon_switch_replenish_stamina_new_description

유형: 기존 수정

**현재 영문**

Activating Melee Specialist restores {stamina:%s} Stamina and grants {stamina_reduction:%s} Stamina Cost Reduction for {duration:%s}s.

**기존 기본 번역**

근접전 전문가가 활성화 되면 {duration:%s}초 동안 스태미나를 {stamina:%s} 회복하고, 스태미나 비용 감소율이 {stamina_reduction:%s} 증가합니다.

**수정 기본 번역**

근접전 전문가가 활성화되면 스태미나를 {stamina:%s} 회복하고, {duration:%s}초 동안 스태미나 비용 감소율이 {stamina_reduction:%s} 증가합니다.

수정 이유: 즉시 스태미나 회복과 일정 시간 비용 감소 효과 분리

## 424. loc_talent_zealot_3_passive_2_description

유형: 기존 수정

**현재 영문**

{damage:%s} Increased Damage against Infested & Unyielding Enemies.

**기존 기본 번역**

감염된 적과 및 불굴의 적에게 입히는 대미지가 {damage:%s} 증가합니다.

**수정 기본 번역**

감염된 적 및 불굴의 적에게 입히는 대미지가 {damage:%s} 증가합니다.

수정 이유: 중복 조사 수정

## 425. loc_talent_zealot_3_tier_2_ability_1_description

유형: 기존 수정

**현재 영문**

{damage:%s} Damage on your next Melee Attack for each Enemy Hit. Stacks {max_stacks:%s} times.

**기존 기본 번역**

다음 근접 공격으로 맞힌 적의 수에 따라 대미지가 {damage:%s} 증가합니다. 최대 {max_stacks:%s}회 중첩됩니다.

**수정 기본 번역**

적 한 명을 맞힐 때마다 다음 근접 공격의 대미지가 {damage:%s} 증가합니다. 최대 {max_stacks:%s}회 중첩됩니다.

수정 이유: 이번 공격의 명중 수가 다음 근접 공격에 적용됨을 명확히 함

## 426. loc_talent_zealot_3_tier_4_ability_3_description

유형: 기존 수정

**현재 영문**

When you or an Ally in Coherency takes damage, they gain {damage_reduction:%s} Damage Reduction for {duration:%s}s. Triggers every {cooldown:%s}s.

**기존 기본 번역**

자신 또는 단결 상태의 아군이 대미지를 받으면, {duration:%s}초 동안 받는 대미지 감소율이 {damage_reduction:%s} 증가합니다. {cooldown:%s}초마다 발동합니다.

**수정 기본 번역**

자신 또는 단결 상태의 아군이 대미지를 받으면, 대미지를 받은 대상이 {duration:%s}초 동안 {damage_reduction:%s}의 대미지 감소 효과를 얻습니다. {cooldown:%s}초마다 발동합니다.

수정 이유: 효과를 받는 대상이 피해를 받은 요원임을 명시

## 427. loc_talent_zealot_bolstering_prayer_variant_two_description

유형: 기존 수정

**현재 영문**

Wield a holy relic that releases pulses of energy every {interval:%s}s. While channeling, Allies in Coherency have Stun Immunity and Invulnerability.

Each pulse Replenishes {toughness:%s} Toughness to Allies in Coherency. If the Ally is at full Toughness they instead gain {flat_toughness:%s} Max Toughness up to a total of {max_toughness}.

{cooldown:%s}s Base Cooldown.

**기존 기본 번역**

{interval:%s}초마다 에너지 파동을 방출하는 성스러운 유물을 휘두릅니다. 파동을 방출하는 동안 단결 상태의 아군은 기절 면역과 불사 효과를 받습니다.

각 파동은 단결 상태의 아군의 강인함을 {toughness:%s} 회복합니다. 만약 아군의 강인함이 최대치일 경우, 강인함을 {flat_toughness:%s} 추가로 받으며, 최대 {max_toughness:%s}까지 증가합니다.

기본 쿨다운: {cooldown:%s}초

**수정 기본 번역**

{interval:%s}초마다 에너지 파동을 방출하는 성스러운 유물을 휘두릅니다. 파동을 방출하는 동안 단결 상태의 아군은 기절 면역과 무적 효과를 받습니다.

각 파동은 단결 상태의 아군의 강인함을 {toughness:%s} 회복합니다. 아군의 강인함이 최대치라면 대신 최대 강인함이 {flat_toughness:%s} 증가하며, 총 {max_toughness}까지 증가합니다.

기본 쿨다운: {cooldown:%s}초

수정 이유: 최대 강인함 증가와 무적 효과를 명확히 하고 현재 원문 변수 보존

## 428. loc_talent_zealot_damage_taken_restores_cd_new_description

유형: 기존 수정

**현재 영문**

Up to {cooldown_regen:%s} Ability Cooldown Regeneration based on Missing Health. Max reached at {current_health:%s} Current Health.

**기존 기본 번역**

잃어버린 체력이 비례해 전투 능력 쿨다운 재생 속도가 최대 {cooldown_regen:%s}까지 증가합니다. 최대 체력의 {current_health:%s}일 때 최대치가 됩니다.

**수정 기본 번역**

잃은 체력에 비례해 전투 능력 쿨다운 재생 속도가 최대 {cooldown_regen:%s}까지 증가합니다. 최대 체력의 {current_health:%s}일 때 최대치가 됩니다.

수정 이유: 잘못된 조사 수정

## 429. loc_talent_zealot_fanatic_rage_toughness_replenish_desc

유형: 기존 수정

**현재 영문**

Triggering Fury Replenishes {toughness:%s} Toughness. In addition, while Fury is Active, you have {toughness_damage_reduction:%s} Toughness Damage Reduction and replenish {toughness_small:%s} Toughness each second.

**기존 기본 번역**

분노가 발동되면 강인함을 {toughness:%s} 회복합니다. 분노가 활성화 상태일 때 받는 강인함 대미지 감소율이 {toughness:%s} 증가하고, 매초마다 강인함을 {toughness_small:%s}씩 회복합니다.

**수정 기본 번역**

분노가 발동되면 강인함을 {toughness:%s} 회복합니다. 분노가 활성화된 동안에는 받는 강인함 대미지 감소율이 {toughness_damage_reduction:%s} 증가하고, 매초 강인함을 {toughness_small:%s} 회복합니다.

수정 이유: 피해 감소 자리에 잘못 사용한 회복량 변수 수정

## 430. loc_talent_zealot_momentum_toughness_replenish_desc

유형: 기존 수정

**현재 영문**

Replenish {toughness:%s} Toughness per second per spent Stack of Momentum during its Duration.

**기존 기본 번역**

지속 시간 동안 가속 중첩당 매초마다 강인함을 {toughness:%s}씩 회복합니다.

**수정 기본 번역**

지속 시간 동안 소모한 가속 중첩당 매초마다 강인함을 {toughness:%s}씩 회복합니다.

수정 이유: 보유 중첩이 아니라 소모한 중첩 기준임을 명확히 함

## 431. loc_talent_zealot_push_attacks_attack_speed_desc

유형: 기존 수정

**현재 영문**

Push followup attacks grant {attack_speed:%s} Melee Attack Speed for {duration:%s}s.

**기존 기본 번역**

밀기 후속 공격을 맞히면 {duration:%s}초 동안 근접 공격 속도가 {attack_speed:%s} 증가합니다.

**수정 기본 번역**

밀기 후속 공격을 사용하면 {duration:%s}초 동안 근접 공격 속도가 {attack_speed:%s} 증가합니다.

수정 이유: 원문에 없는 명중 조건 제거

## 432. loc_talent_zealot_resist_death_desc

유형: 기존 수정

**현재 영문**

Fatal Damage instead grants you Invulnerability for {active_duration:%s}s. Occurs every {cooldown_duration:%s}s.

**기존 기본 번역**

죽음에 이르게 하는 대미지를 받으면 {active_duration:%s}초 동안 불사 상태가 됩니다. {cooldown_duration:%s}초마다 발동할 수 있습니다.

**수정 기본 번역**

죽음에 이르게 하는 대미지를 받으면 {active_duration:%s}초 동안 무적 상태가 됩니다. {cooldown_duration:%s}초마다 발동할 수 있습니다.

수정 이유: Invulnerability를 피해를 받지 않는 무적 효과로 표현

## 433. loc_talent_zealot_sprint_improvements_alt_desc

유형: 기존 수정

**현재 영문**

{sprint_speed:%s} Sprint Speed and {sprint_cost:%s} Sprint Cost. Sprinting for {duration:%s}s grants Slowdown Immunity.

**기존 기본 번역**

질주 속도가 {sprint_speed:%s} 증가하며, 질주 비용이 {sprint_cost:%s} 감소합니다. 질주 시 {duration:%s}초 동안 둔화 면역 상태가 됩니다.

**수정 기본 번역**

질주 속도가 {sprint_speed:%s} 증가하며, 질주 비용이 {sprint_cost:%s} 감소합니다. {duration:%s}초 동안 질주하면 둔화 면역 상태가 됩니다.

수정 이유: 질주 요구 시간을 면역 지속시간으로 옮긴 오류 수정

## 434. loc_tech_priest_a__cmd_wandering_skull_04

유형: 기존 수정

**현재 영문**

If you lose the servo-skull I shall look to you for a replacement.

**기존 기본 번역**

서보 스컬을 잃어버린다면, 너희를 대체할 녀석을 찾아보겠다.

**수정 기본 번역**

서보 스컬을 잃어버리면 너희에게서 대체품을 구하겠다.

수정 이유: 대체 대상이 서보 스컬이라는 위협의 뜻 복원

## 435. loc_tech_priest_a__hub_idle_2nd_phase_conversation_thirtyone_b_01

유형: 기존 수정

**현재 영문**

I am not cheerless. Your mind simply cannot comprehend my sublime humour.

**기존 기본 번역**

기운이 없다. 그대의 마음은 내 숭고한 유머 감각을 그냥 받아들이질 못하는군.

**수정 기본 번역**

내가 재미없는 게 아니다. 그대의 정신이 내 숭고한 유머를 이해하지 못할 뿐이지.

수정 이유: 부정어 누락으로 반대가 된 의미 수정

## 436. loc_tech_priest_a__hub_idle_2nd_phase_conversation_thirtyseven_a_01

유형: 기존 수정

**현재 영문**

I have petitioned the Forges of Mars for additional materiel, Sergeant Major. The response was not ... encouraging.

**기존 기본 번역**

화성의 요새에 추가 자료를 요청했다, 원사. 반응은... 좋지 못하군.

**수정 기본 번역**

화성의 제조 시설에 추가 군수품을 요청했다, 원사. 답변은... 희망적이지 않군.

수정 이유: Forges와 materiel을 요새 및 자료로 옮긴 오류 수정

## 437. loc_tech_priest_a__hub_idle_2nd_phase_conversation_thirtysix_a_01

유형: 기존 수정

**현재 영문**

Sergeant Major! I really must insist your charges take better care of their weapons!

**기존 기본 번역**

원사! 녀석들의 무기를 더 잘 관리해야 하는 건 그대의 책임이야!

**수정 기본 번역**

원사! 그대의 부하들에게 무기 관리를 더 철저히 하라고 일러두도록!

수정 이유: charges가 원사의 부하를 가리키는 뜻 복원

## 438. loc_tech_priest_a__hub_idle_2nd_phase_conversation_twentynine_b_01

유형: 기존 수정

**현재 영문**

I am always in acceptable humour.

**기존 기본 번역**

난 항상 유머를 받아들일 준비가 되어 있다.

**수정 기본 번역**

나는 항상 기분이 괜찮은 상태다.

수정 이유: humour가 기분을 가리키는 표현 수정

## 439. loc_tech_priest_a__hub_idle_crafting_06

유형: 기존 수정

**현재 영문**

Many heroes have borne your arms before you. Others will do so after your passing.

**기존 기본 번역**

이전에도 많은 영웅들이 팔을 걷어붙이고 뛰어들었지. 네가 목숨을 잃으면 다른 사람들이 그 길을 계속 이어갈 테고.

**수정 기본 번역**

너희가 쓰는 무기는 이전에도 많은 영웅들이 들었던 것이다. 너희가 죽은 뒤에도 다른 이들이 이어서 들겠지.

수정 이유: borne your arms를 팔 걷어붙이기로 옮긴 오류 수정

## 440. loc_tech_priest_a__hub_idle_crafting_08

유형: 기존 수정

**현재 영문**

The tools of war are the tools by which the Omnissiah will reshape the galaxy.

**기존 기본 번역**

전쟁이란 옴니시아께서 은하를 재편성하기 위한 도구지.

**수정 기본 번역**

전쟁의 도구야말로 옴니시아께서 은하를 재편하실 도구다.

수정 이유: 주어인 무기 및 전쟁 도구를 전쟁 자체로 옮긴 오류 수정

## 441. loc_tech_priest_a__info_extraction_01

유형: 기존 수정

**현재 영문**

The probability of escape is almost in your favour.

**기존 기본 번역**

탈출 확률로는 너희가 우세한 편이다.

**수정 기본 번역**

탈출 확률은 거의 너희에게 유리하다고 할 만한 수준이다.

수정 이유: almost 한정 의미 복원

## 442. loc_tech_priest_a__info_extraction_02

유형: 기존 수정

**현재 영문**

Extraction window closing.

**기존 기본 번역**

탈출할 시간이 다가왔군.

**수정 기본 번역**

탈출할 기회가 닫히고 있다.

수정 이유: 탈출 가능 시간 종료를 시작으로 옮긴 오류 수정

## 443. loc_tech_priest_a__info_extraction_03

유형: 기존 수정

**현재 영문**

Extraction prognosis approaching terminal.

**기존 기본 번역**

탈출 예상 시간이 임박했다.

**수정 기본 번역**

탈출 전망이 치명적인 수준으로 악화되고 있다.

수정 이유: 부정적인 예후를 탈출 예정 시각으로 옮긴 오류 수정

## 444. loc_tech_priest_a__mission_armoury_side_streets_01_c_02

유형: 기존 수정

**현재 영문**

I have almost total confidence that the mission will not be a disaster. I even expect one of the strike team to survive.

**기존 기본 번역**

이 임무가 재앙이 되지 않을 것 같다는 믿음이 아주 약간 드는군. 스트라이크 팀 중 누군가 살아남을 줄은 몰랐다.

**수정 기본 번역**

이 임무가 재앙으로 끝나지 않으리라 거의 전적으로 확신한다. 스트라이크 팀에서 한 명쯤은 살아남으리라고도 예상하지.

수정 이유: 확신의 크기와 생존 예측 시제 오류 수정

## 445. loc_tech_priest_a__mission_cargo_end_event_conversation_one_b_02

유형: 기존 수정

**현재 영문**

Trains are not shell-proof. There are many traitor outposts between here and loyalist territory.

**기존 기본 번역**

기차는 방탄이 아니다. 이곳과 황실의 영토 사이에는 수많은 배신자들의 초소가 있다.

**수정 기본 번역**

기차는 방탄이 아니다. 이곳과 충성파의 영토 사이에는 수많은 배신자들의 초소가 있다.

수정 이유: loyalist territory의 진영 의미 수정

## 446. loc_tech_priest_a__mission_cartel_brief_one_01

유형: 기존 수정

**현재 영문**

War zone analysis supports the implementation of bad data in the Torrent's cogitator array.

**기존 기본 번역**

토렌트의 코지테이터 배열에서 전쟁 지역 분석 기능은 잘못된 정보의 구현을 지원하고 있다.

**수정 기본 번역**

전장 분석 결과, 토렌트의 코지테이터 배열에 허위 데이터를 주입하는 것이 타당하다.

수정 이유: 작전 타당성 분석을 배열 내부 기능으로 옮긴 오류 수정

## 447. loc_tech_priest_a__mission_cartel_brief_three_03

유형: 기존 수정

**현재 영문**

Reach the array. Upload my exquisite data forgery. Extract. It is well within your capabilites.

**기존 기본 번역**

배열에 도달한다. 네 정교한 데이터 위조를 업로드한다. 탈출한다. 너희는 할 수 있다.

**수정 기본 번역**

배열에 도달한다. 내 정교한 데이터 위조를 업로드한다. 탈출한다. 너희는 할 수 있다.

수정 이유: 소유 주체 my 수정

## 448. loc_tech_priest_a__mission_cartel_pillar_04

유형: 기존 수정

**현재 영문**

Hmmm. Clearly the pillars' pest-control measures are ineffective against indigents.

**기존 기본 번역**

흐음. 기둥들의 해충 방제 조치는 확실히 소작인들에게는 효과가 없다.

**수정 기본 번역**

흐음. 기둥의 해충 방제 조치는 빈민들에게는 확실히 효과가 없군.

수정 이유: indigents를 소작인으로 옮긴 오류 수정

## 449. loc_tech_priest_a__mission_cartel_upload_03

유형: 기존 수정

**현재 영문**

Security stacks disabled. Begin disruptive delivery.

**기존 기본 번역**

보안 스택이 해제되었다. 중단 없이 전송을 시작하겠다.

**수정 기본 번역**

보안 스택 해제 완료. 교란 데이터 전송을 시작해라.

수정 이유: disruptive delivery를 중단 없는 전송으로 옮긴 오류 수정

## 450. loc_tech_priest_a__mission_cooling_briefing_three_04

유형: 기존 수정

**현재 영문**

Once cryonic rods are deployed - correctly, mark you, varlets - the system will stabilise, and you will have proven somewhat useful.

**기존 기본 번역**

냉각봉을 정확히 설치하면, 시스템이 안정화되고 어느 정도 유용할 것으로 입증되었다.

**수정 기본 번역**

냉각봉을 설치하면, 정확히 설치하라는 말이다, 종자들, 시스템이 안정화될 것이다. 너희도 조금은 쓸모 있다는 걸 증명하겠지.

수정 이유: 유용성을 입증하는 주체가 요원이라는 뜻 복원

## 451. loc_tech_priest_a__mission_core_briefing_c_03

유형: 기존 수정

**현재 영문**

Initiate contact with our informant, follow his instructions and wake the foundryplex. Understood?

**기존 기본 번역**

그 비밀을 함께 찾아보도록 하지. 그리고 방심하지 마라. 이 정보 제공자의 의도는... 아직 불분명하다.

**수정 기본 번역**

정보 제공자와 접촉해서 지시를 따르고 파운드리플렉스를 깨워라. 알아들었나?

수정 이유: 현재 원문과 다른 대사 수정

## 452. loc_tech_priest_a__mission_forge_elevator_conversation_three_b_01

유형: 기존 수정

**현재 영문**

[Sigh] Very well. I am fluent in all one hundred and one core binharic cants of the eighty-ninth discipline.

**기존 기본 번역**

알겠다. 나는 여든 아홉 번째 분야의 핵심 이진법 문장을 모두 유창하게 구사할 수 있다.

**수정 기본 번역**

[한숨] 알겠다. 나는 제89분야의 핵심 바이너릭 방언 101개를 모두 유창하게 구사한다.

수정 이유: 101개 수량 누락과 binharic cants 의미 복원

## 453. loc_tech_priest_a__mission_raid_production_lab_destroy_mid_b_03

유형: 기존 수정

**현재 영문**

Not all that is lost can be saved, enginseer. Stillness is preferable to subversion.

**기존 기본 번역**

잃어버린 모든 것을 구할 수는 없다, 엔진시어. 전복되어 있는 거보단 정적이 낫다.

**수정 기본 번역**

잃어버린 모든 것을 구할 수는 없다, 엔진시어. 적에게 넘어가는 것보다는 멈추는 편이 낫다.

수정 이유: subversion의 적에 의한 변질 및 전용 의미 복원

## 454. loc_tech_priest_a__mission_rails_briefing_a_04

유형: 기존 수정

**현재 영문**

Peculation and mismanagement have reduced our special issue ammunition stores to critical level.

**기존 기본 번역**

잘못된 계산과 관리로 인해 특수 탄종 저장고가 심각한 수준으로 감소했다.

**수정 기본 번역**

횡령과 부실한 관리로 특수 탄종 비축량이 위험한 수준까지 줄었다.

수정 이유: peculation을 계산 착오로 옮긴 오류 수정

## 455. loc_tech_priest_a__mission_rails_briefing_b_04

유형: 기존 수정

**현재 영문**

You - yes you - need to find some more at Logistratum (Chasm Station). Can you handle that?

**기존 기본 번역**

로지스트라툼에서 더 많은 정보를 찾을 수 있다. 해낼 수 있겠나?

**수정 기본 번역**

너희, 그래 너희 말이다. 로지스트라툼(캐즘 스테이션)에서 좀 더 찾아와야 한다. 해낼 수 있겠나?

수정 이유: 목적어를 임의로 정보라고 특정한 부분 수정

## 456. loc_tech_priest_a__mission_rails_event_grab_supplies_01

유형: 기존 수정

**현재 영문**

Correct crates designated. Proceed with retrieval.

**기존 기본 번역**

올바른 보관함을 찾아라. 회수를 진행하도록.

**수정 기본 번역**

회수할 보관함을 지정했다. 회수를 진행하도록.

수정 이유: 목표 지정 완료를 탐색 지시로 옮긴 오류 수정

## 457. loc_tech_priest_a__mission_rails_logistratum_01

유형: 기존 수정

**현재 영문**

Logistratum access: Achieved. And with something approaching efficiency.

**기존 기본 번역**

로지스트라툼 접근: 도착 완료. 그리고 효율성에 근접한 무언가가 있어.

**수정 기본 번역**

로지스트라툼 접근: 성공. 거의 효율적이라고 할 만한 방식으로 해냈군.

수정 이유: efficiency에 근접한 수행이라는 평가 복원

## 458. loc_tech_priest_a__mission_rails_maintenance_bay_02

유형: 기존 수정

**현재 영문**

Make note: Repair Bay Chiron-13-Kappa in lamentable condition. Reprimands to be issued.

**기존 기본 번역**

기록. 정비 구역 케이론-13-카파의 상태가 좋지 않음. 수리가 필요함.

**수정 기본 번역**

기록: 정비 구역 케이론-13-카파의 상태가 참담함. 문책 조치 필요.

수정 이유: reprimands를 수리로 옮긴 오류 수정

## 459. loc_tech_priest_a__mission_scavenge_briefing_two_02

유형: 기존 수정

**현재 영문**

Vault access is limited. You will have to interrogate a servitor colony. Try not to inflict damage. It is the only one of its kind left on Atoma.

**기존 기본 번역**

볼트 접근은 제한되어 있다. 서비터 콜로니를 심문해야 할 거다. 피해는 주지 말도록. 아토마에 유일하게 남은 서비터다.

**수정 기본 번역**

보관고 접근은 제한되어 있다. 서비터 콜로니를 조사해야 할 거다. 손상시키지 마라. 아토마에 남은 유일한 동종 콜로니다.

수정 이유: only one of its kind를 모든 서비터의 유일한 생존 개체로 옮긴 오류 수정

## 460. loc_tech_priest_a__mission_strain_start_banter_b_02

유형: 기존 수정

**현재 영문**

Freight Port HL-32-2 was struck from maintenance schedules some 521.4 cycles ago.

**기존 기본 번역**

화물 항구 HL-32-2는 약 521.4 사이클 전에 점검 일정에서 충돌했다.

**수정 기본 번역**

화물 항구 HL-32-2는 약 521.4사이클 전에 정비 일정에서 제외되었다.

수정 이유: struck from을 충돌로 옮긴 오류 수정

## 461. loc_tech_priest_b__mission_forge_briefing_c_01

유형: 기존 수정

**현재 영문**

I trust you will undertake this mission with your customary disregard for operational parameters?

**기존 기본 번역**

이 작업 방해 요소를 제거하기 위한 임무를 진행할 수 있겠나?

**수정 기본 번역**

이번에도 평소처럼 작전 지침을 무시하며 임무를 수행하겠지?

수정 이유: customary disregard for operational parameters의 빈정거림 복원

## 462. loc_tertium_noble_b__mission_habs_redux_escape_conversation_c_03

유형: 기존 수정

**현재 영문**

This is no time for misguided sentiment, novitiate.

**기존 기본 번역**

그런 길 잃은 감상을 풀 때가 아니다, 노비시에이트.

**수정 기본 번역**

엉뚱한 감상에 젖을 때가 아니다, 노비시에이트.

수정 이유: misguided sentiment의 뜻 복원

## 463. loc_tertium_noble_b__mission_habs_redux_start_zone_c_02

유형: 기존 수정

**현재 영문**

Your opinion was not courted, novitiate. Nor your presence wanted.

**기존 기본 번역**

네 의견은 묻지 않았다, 노비시에이트. 네가 여기 왜 있는지도 모르겠군.

**수정 기본 번역**

네 의견은 묻지 않았다, 노비시에이트. 네가 여기 오길 바란 적도 없고.

수정 이유: 원치 않는 참석이라는 의미 복원

## 464. loc_title_achievement_004_female

유형: 추가 ID 덮어쓰기

**현재 영문**

Cyber-Falcon

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

사이버 팔콘

수정 이유: 원문이 확보된 칭호 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 465. loc_title_achievement_115_desc

유형: 기존 수정

**현재 영문**

Title for completing a Havoc Order rank of 35 without anyone getting downed.

**기존 기본 번역**

아무도 쓰러지지 않은 상태로 하복 임무 랭크 35에 도달하면 받는 칭호입니다.

**수정 기본 번역**

아무도 쓰러지지 않은 상태로 랭크 35 하복 임무를 완료하면 받는 칭호입니다.

수정 이유: 해금 조건은 랭크 도달이 아니라 임무 완료

## 466. loc_title_penance_track_001_male

유형: 추가 ID 덮어쓰기

**현재 영문**

Ministorum Lackey

**기존 기본 번역**

(한국어 원문 덤프에 없음)

**수정 기본 번역**

미니스토룸 하수인

수정 이유: 원문이 확보된 칭호 번역

확인 메모: 영문 원문은 확보됨. 같은 ID의 한국어 원문은 이번 덤프에 없어 기존 게임 한국어와의 비교는 미확인.

## 467. loc_training_ground_psyker_a__hub_rumour_politics_01_a_09

유형: 기존 수정

**현재 영문**

Lord Margrave should watch his back ... The king's throne is always tempting, even in the face of oblivion.

**기존 기본 번역**

마그레이브 경은 조심하는 게 좋을 거야... 보이드라 해도, 옥좌는 항상 매혹적인 법이니까.

**수정 기본 번역**

마그레이브 경은 등 뒤를 조심해야겠어... 멸망을 앞두고도 왕좌는 매력적인 법이니까.

수정 이유: oblivion을 보이드라는 장소로 옮긴 오류 수정

## 468. loc_training_ground_psyker_a__hub_rumour_wanderers_01_a_03

유형: 기존 수정

**현재 영문**

Bounty hunters are looking for work in the hive. It's definitely a buyer's market.

**기존 기본 번역**

현상금 사냥꾼들이 하이브에서 일거리를 찾고 있어. 확실히 수요가 있는 시장이지.

**수정 기본 번역**

현상금 사냥꾼들이 하이브에서 일거리를 찾고 있어. 확실히 고용하는 쪽이 유리한 시장이지.

수정 이유: buyer's market의 거래상 우위 의미를 풀어 씀

## 469. loc_training_ground_psyker_a__player_first_intro_cinematic_a_01

유형: 기존 수정

**현재 영문**

Welcome to the Meatgrinder. Everything here may feel real, but don't worry ... you won't get hurt, not unless you anger poor Sefoni.

**기존 기본 번역**

미트 그라인더에 온 걸 환영한다. 걱정 마. 아무리 진짜 같아도 실제로 다치지는 않을 거야. 이 가없은 세포니를 화나게 하지 않는다면 말이지.

**수정 기본 번역**

미트 그라인더에 온 걸 환영한다. 걱정 마. 아무리 진짜 같아도 실제로 다치지는 않을 거야. 이 가엾은 세포니를 화나게 하지 않는다면 말이지.

수정 이유: 맞춤법 오류 수정

## 470. loc_trait_bespoke_armor_rending_from_dot_burning_desc

유형: 기존 수정

**현재 영문**

Direct hits apply {num_stacks:%s} Stacks of {rending_percentage:%s} Brittleness for {duration:%s}s. Stacks {max_stacks:%s} times

**기존 기본 번역**

직격타가 {duration:%s}초 동안 지속되는 {rending_percentage:%s}%의 불안정 중첩을 {num_stacks:%s}개 부여합니다. 최대 {max_stacks:%s}개 중첩됩니다.

**수정 기본 번역**

직격타가 {duration:%s}초 동안 지속되는 {rending_percentage:%s}의 불안정 중첩을 {num_stacks:%s}개 부여합니다. 최대 {max_stacks:%s}개 중첩됩니다.

수정 이유: 영문에 없는 백분율 기호 제거; 원문의 서식화된 변수 보존

## 471. loc_trait_bespoke_chained_hits_increases_power_desc

유형: 기존 수정

**현재 영문**

Continuously chaining more than 2 attacks gives {power_level:%s} Power. Stacks {stacks:%s} times.

**기존 기본 번역**

적에게 공격을 2회 이상 연속으로 맞히면 파워가 {power_level:%s} 증가합니다. 최대 {stacks:%s}회 중첩됩니다.

**수정 기본 번역**

공격을 두 번 넘게 연속으로 이어 가면 파워가 {power_level:%s} 증가합니다. 최대 {stacks:%s}회 중첩됩니다.

수정 이유: more than 2를 2회 이상으로 옮긴 오류와 원문에 없는 명중 조건 수정

## 472. loc_trait_bespoke_double_shot_on_primary_crit_and_crit_chance_desc

유형: 기존 수정

**현재 영문**

{value:%s} Shots on Primary Critical Hit. {crit_chance:%s} Ranged Crit Chance.

**기존 기본 번역**

적에게 치명타 공격을 맞히면 {value:%s}개의 투사체를 발사합니다. 원거리 공격의 치명타 확률이 {crit_chance:%s} 증가합니다.

**수정 기본 번역**

주 공격이 치명타일 때 투사체를 {value:%s}개 발사합니다. 원거리 공격의 치명타 확률이 {crit_chance:%s} 증가합니다.

수정 이유: Primary 조건 누락 복원

## 473. loc_trait_bespoke_elite_kills_grants_stackable_power_desc

유형: 기존 수정

**현재 영문**

{power_level:%s} Strength for {time:%s} s on Elite and Specialist Kill. Stacks {stacks:%s} times, deteriorating one at a time.

**기존 기본 번역**

엘리트 적 처치 시 {time:%s}초 동안 파워가 {power_level:%s} 증가합니다. 최대 {stacks:%s}회 중첩되며, 한 번에 하나씩 줄어듭니다.

**수정 기본 번역**

엘리트 또는 스페셜리스트 처치 시 {time:%s}초 동안 파워가 {power_level:%s} 증가합니다. 최대 {stacks:%s}회 중첩되며, 한 번에 하나씩 줄어듭니다.

수정 이유: 스페셜리스트 처치 조건 누락 보완

## 474. loc_trait_bespoke_followup_shots_ranged_weakspot_damage_desc

유형: 기존 수정

**현재 영문**

{damage:%s} Weakspot Damage on Second, Third and Fourth shots in a Salvo.

**기존 기본 번역**

연속으로 사격할 때, 두 번째, 세 번째와 네 번째 탄환의 약점 대미지가 {damage:%s} 증가합니다

**수정 기본 번역**

연속으로 사격할 때, 두 번째, 세 번째와 네 번째 탄환의 약점 대미지가 {damage:%s} 증가합니다.

수정 이유: 문장 끝 마침표 보완

## 475. loc_trait_bespoke_guaranteed_melee_crit_on_activated_kill_desc

유형: 기존 수정

**현재 영문**

{crit_chance:%s} Critical Chance on your next Melee Attack after Special Attack Kill.

**기존 기본 번역**

특수 공격으로 적을 죽이면 치명타 확률이 {crit_chance:%s} 증가합니다.

**수정 기본 번역**

특수 공격으로 적을 처치하면 다음 근접 공격의 치명타 확률이 {crit_chance:%s} 증가합니다.

수정 이유: 다음 근접 공격으로 한정되는 조건 복원

## 476. loc_trait_bespoke_increase_stagger_per_hit_in_sweep_desc

유형: 기존 수정

**현재 영문**

{impact:%s} Impact to Target for each Enemy already Hit by the same Attack

**기존 기본 번역**

이미 같은 공격에 맞은 적에게 {impact:%s}의 충격을 추가로 가합니다.

**수정 기본 번역**

같은 공격으로 이미 맞힌 적 한 명당, 다음에 맞는 대상에게 가하는 충격이 {impact:%s} 증가합니다.

수정 이유: 동일 대상을 재타격하는 효과로 읽히던 번역 수정

## 477. loc_trait_bespoke_increased_sprint_speed_desc

유형: 기존 수정

**현재 영문**

Gain Ranged Attack Immunity while sprinting with over {stamina:%s} Stamina.

**기존 기본 번역**

스태미나가 {stamina:%s} 이상일 때 질주하면, 질주하는 동안 원거리 공격에 대해 면역 상태가 됩니다.

**수정 기본 번역**

스태미나가 {stamina:%s} 초과일 때 질주하면, 질주하는 동안 원거리 공격에 대해 면역 상태가 됩니다.

수정 이유: over의 경계 조건 반영

## 478. loc_trait_bespoke_infinite_armor_cleave_on_activated_attacks_and_heavy_damage_desc

유형: 기존 수정

**현재 영문**

Increased Cleave and {heavy_damage:%s} Heavy Melee Attack Damage on Energised Attacks.

**기존 기본 번역**

쪼개기가 증가하며, 에너지 강공격의 피해량이 {heavy_damage:%s} 증가합니다.

**수정 기본 번역**

에너지 공격의 쪼개기가 증가하며, 에너지 강공격의 대미지가 {heavy_damage:%s} 증가합니다.

수정 이유: 에너지 공격 조건의 적용 범위를 명확히 함

## 479. loc_trait_bespoke_infinite_cleave_on_weakspot_kill_desc

유형: 기존 수정

**현재 영문**

{weakspot_damage:%s} Weak Spot Damage. Weakspot Kills also ignore Enemy Hit Mass.

**기존 기본 번역**

약점 대미지가 {weakspot_damage:%s} 증가합니다. 약점을 맞혀 적을 죽이면 다음 적의 히트 매스를 무시합니다.

**수정 기본 번역**

약점 대미지가 {weakspot_damage:%s} 증가합니다. 약점 처치 시 처치한 적의 히트 매스를 무시합니다.

수정 이유: 원문에 없는 다음 적의 히트 매스 무시라는 의미 수정

## 480. loc_trait_bespoke_power_bonus_on_same_enemy_attacks_desc

유형: 기존 수정

**현재 영문**

{power_level:%s} Strength for {time:%s}s on Hit (Same Enemy). Stacks {stacks:%s} times.

**기존 기본 번역**

같은 적을 맞힐 때마다 파워가 {power_level:%s} 증가합니다. 최대 {stacks:%s}회 중첩됩니다.

**수정 기본 번역**

같은 적을 맞히면 {time:%s}초 동안 파워가 {power_level:%s} 증가합니다. 최대 {stacks:%s}회 중첩됩니다.

수정 이유: 효과 지속시간 누락 복원

## 481. loc_trait_bespoke_power_bonus_scaled_on_heat_desc

유형: 기존 수정

**현재 영문**

Up to {damage:%s} Strength scaling with Heat Level.

**기존 기본 번역**

과열 수준에 따라 피해량이 최대 {damage:%s} 증가합니다.

**수정 기본 번역**

과열 수준에 따라 파워가 최대 {damage:%s}까지 증가합니다.

수정 이유: Strength를 피해량으로 옮긴 오류 수정

## 482. loc_trait_bespoke_power_bonus_scaled_on_stamina_desc

유형: 기존 수정

**현재 영문**

Up to {power_level:%s} Strength, as Stamina depletes.

**기존 기본 번역**

스태미나를 소진하면 파워가 {power_level:%s} 증가합니다.

**수정 기본 번역**

스태미나가 줄어들수록 파워가 최대 {power_level:%s}까지 증가합니다.

수정 이유: 소진 시 발동이 아니라 남은 스태미나에 따른 증가

## 483. loc_trait_bespoke_reduced_overheat_on_crits_desc

유형: 기존 수정

**현재 영문**

{heat_percentage:%s} Heat generation on Critical Hit.

**기존 기본 번역**

치명타 공격을 맞히면 열 재생률이 {heat_percentage:%s} 감소합니다.

**수정 기본 번역**

치명타 공격 시 과열 생성량이 {heat_percentage:%s} 감소합니다.

수정 이유: 과열 생성량을 재생률로 옮긴 오류 수정

## 484. loc_trait_bespoke_rend_armor_on_aoe_charge_desc

유형: 기존 수정

**현재 영문**

Target receives up to {stacks:%s} Stacks of {rending:%s} Brittleness, scaling with charge time of Secondary Attack. Debuff lasts for {time:%s} seconds and can have a maximum of {max_stacks:%s} stacks.

**기존 기본 번역**

보조 공격 충전 시간에 따라 대상에게 {rending:%s}의 불안정을 {stacks:%s}개 부여합니다. 효과는 {time:%s}초 동안 지속되며, 최대 {max_stacks:%s}회 중첩됩니다.

**수정 기본 번역**

보조 공격 충전 시간에 따라 대상에게 {rending:%s}의 불안정을 최대 {stacks:%s}개 부여합니다. 효과는 {time:%s}초 동안 지속되며, 최대 {max_stacks:%s}회 중첩됩니다.

수정 이유: 충전 시간에 비례하는 최대 부여량 명시

## 485. loc_trait_damage_bonus_on_block_desc

유형: 기존 수정

**현재 영문**

Gain a stack for each stamina spent blocking. Your next melee attack gains {power:%s} strength per stack and consumes one stack. Last {duration:%s}s. Stacks {stacks:%s} times.

**기존 기본 번역**

방어로 소모한 스태미나마다 중첩을 획득합니다. 중첩 1개당 다음 근접 공격의 파워가 {power:%s} 증가합니다. {duration:%s}초 동안 지속되며 최대 {stacks:%s}회 중첩됩니다.

**수정 기본 번역**

막기로 소모한 스태미나마다 중첩을 획득합니다. 다음 근접 공격은 중첩 하나당 파워가 {power:%s} 증가하고 중첩 하나를 소모합니다. {duration:%s}초 동안 지속되며 최대 {stacks:%s}회 중첩됩니다.

수정 이유: 공격할 때 중첩 하나를 소모한다는 설명 복원

## 486. loc_trait_gadget_dr_vs_flamer_desc

유형: 기존 수정

**현재 영문**

{damage_reduction:%s} Damage Resistance (Flamers)

**기존 기본 번역**

대미지 저항 +{damage_reduction:%s}(톡스 플레이머)

**수정 기본 번역**

대미지 저항 {damage_reduction:%s}(플레이머)

수정 이유: 원문의 범위를 톡스 플레이머 한 종류로 제한하지 않도록 수정

## 487. loc_trait_ranged_common_wield_increase_stamina_desc

유형: 기존 수정

**현재 영문**

{stamina:%s} Stamina (Weapon is Active)

**기존 기본 번역**

스태미나 {stamina:%s}(무기가 활성화된 경우)

**수정 기본 번역**

스태미나 {stamina:%s}(이 무기를 들고 있을 때)

수정 이유: Weapon is Active를 특수기 활성화로 오해하지 않도록 수정

## 488. loc_travelling_salesman_a__mission_core_cinematic_c_01

유형: 기존 수정

**현재 영문**

I know of a facility hidden in one of Tertium's inter-zone voids. It holds the lost secrets of forging True Moebian Steel.

**기존 기본 번역**

이걸 어떻게 알아냈냐고요? 원래 신사는 자랑을 하지 않는 법이죠. 어쨌든 서두르세요. 우리의 용맹한 뫼비안 6연대가 점점 다가오는 게 느껴지니까.

**수정 기본 번역**

테르티움 구역 간 보이드 지대 중 하나에 숨겨져 있는 시설에 대해 알고 있습니다. 진짜 뫼비안 강철 제련과 관련해 사라진 비밀이 숨겨져 있는 곳이죠.

수정 이유: 해당 ID의 현재 영어·한국어 원문 모두 앞 문구와 동일함; 다른 대사를 덮어쓴 오류 수정

## 489. loc_travelling_salesman_a__mission_core_elevator_conversation_02_c_01

유형: 기존 수정

**현재 영문**

Which places you in abundant, if not necessarily discerning company. I shall endeavour to soldier on.

**기존 기본 번역**

꼭 안목 있는 분들이 아니더라도, 풍요로운 동행이 될 수 있게 노력해보도록 하죠.

**수정 기본 번역**

그렇게 생각하는 분이 많기는 하죠. 꼭 안목 있는 분들이라는 건 아니지만요. 그래도 저는 꿋꿋이 계속하겠습니다.

수정 이유: in abundant company의 뜻과 soldier on 관용 표현 수정

## 490. loc_travelling_salesman_a__mission_core_elevator_conversation_03_b_01

유형: 기존 수정

**현재 영문**

How splendid, though I confess I hoped for a more fungible expression of thanks.

**기존 기본 번역**

훌륭하네요. 정중한 감사의 말이었다면 더 좋았을 텐데 말이죠.

**수정 기본 번역**

멋지군요. 다만 좀 더 돈이 되는 형태의 감사를 기대하긴 했습니다.

수정 이유: fungible 보상을 정중한 말로 옮긴 오류 수정

## 491. loc_travelling_salesman_a__mission_core_event_03_start_c_03

유형: 기존 수정

**현재 영문**

If the team will indulge me in getting things moving, I shall repair to the control oubliette post haste.

**기존 기본 번역**

팀원분들이 제가 일을 진행하게 도와주신다면, 서둘러 비밀 지하 제어실을 수리하겠습니다.

**수정 기본 번역**

팀원분들이 작동을 시작해주시면, 저는 서둘러 제어실로 가겠습니다.

수정 이유: repair to를 이동이 아닌 수리로 옮긴 오류 수정

## 492. loc_travelling_salesman_a__mission_core_objective_01_a_03

유형: 기존 수정

**현재 영문**

It's no small thing to cross the inner void. For that, we will need to rouse a lateral shuttle to life with a hearty infusion of the Motive Force.

**기존 기본 번역**

내부의 보이드를 건너는 건 사소한 일이 아니에요. 측면 셔틀을 되살려야 모티브 포스의 중심부로 갈 수 있습니다.

**수정 기본 번역**

내부의 보이드를 건너는 건 쉬운 일이 아니에요. 모티브 포스를 충분히 공급해서 측면 셔틀을 되살려야 합니다.

수정 이유: hearty infusion을 목적지의 중심부로 옮긴 오류 수정

## 493. loc_tutorial_prologue_sprint_desc

유형: 기존 수정

**현재 영문**

Hold {#color(216,237,190)}$INGAME_INPUT:sprint${#reset()} while moving to Sprint.

**기존 기본 번역**

이동 중 $INGAME_INPUT:sprint$를 눌러 질주하세요.

**수정 기본 번역**

이동 중 {#color(216,237,190)}$INGAME_INPUT:sprint${#reset()}를 길게 눌러 질주하세요.

수정 이유: Hold 입력 방식 및 현재 원문의 키 표시 색상 태그 복원

## 494. loc_veteran_female_a__ability_ranger_10

유형: 기존 수정

**현재 영문**

Engaging critical target.

**기존 기본 번역**

중요 목표물을 제거하겠다.

**수정 기본 번역**

중요 목표물과 교전한다.

수정 이유: Engaging을 처치 완료로 오해하지 않도록 수정

## 495. loc_veteran_female_a__event_survive_keep_coming_a_02

유형: 기존 수정

**현재 영문**

Give me some fragging fire discipline!

**기존 기본 번역**

빌어먹을 사격 훈련 좀 시켜달라고!

**수정 기본 번역**

빌어먹을, 사격 규율 좀 지켜!

수정 이유: 사격 규율 지시를 훈련 요청으로 옮긴 오류 수정

## 496. loc_veteran_female_a__heard_enemy_chaos_spawn_02

유형: 기존 수정

**현재 영문**

Rotbag, coming in!

**기존 기본 번역**

부패덩어리다, 응답하라!

**수정 기본 번역**

부패덩어리가 다가온다!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 497. loc_veteran_female_a__lore_the_warp_four_b_01

유형: 기존 수정

**현재 영문**

Well, it sort of folds into the Immaterium and... um... Does anyone else wanna take this?

**기존 기본 번역**

이렇게 접어서 이마테리움을 만들고... 그... 음... 이어서 설명해줄 사람?

**수정 기본 번역**

그게, 이마테리움 안으로 접혀 들어가서... 음... 누가 대신 설명 좀 해줄래?

수정 이유: 이마테리움으로 진입하는 것을 생성으로 옮긴 오류 수정

## 498. loc_veteran_female_a__mission_complex_start_banter_a_01

유형: 기존 수정

**현재 영문**

Another mission with spotty intel. Just my fragging luck.

**기존 기본 번역**

짜증나는 정보원과 또 임무를 하라니. 빌어먹을 운이로군.

**수정 기본 번역**

부실한 정보로 또 임무를 하라니. 빌어먹을 내 팔자야.

수정 이유: spotty intel을 짜증나는 정보원으로 옮긴 오류 수정

## 499. loc_veteran_female_a__mission_cooling_elevator_conversation_three_line_one_01

유형: 기존 수정

**현재 영문**

Even if we can save the manufactorum, I reckon the workers have had it.

**기존 기본 번역**

우리가 이 매뉴팩토룸을 구한다 해도, 노동자들은 이미 알게 되었을 텐데.

**수정 기본 번역**

매뉴팩토룸을 구해도, 노동자들은 이미 끝장났을 것 같은데.

수정 이유: have had it을 알게 됨으로 옮긴 오류 수정

## 500. loc_veteran_female_a__mission_cooling_long_way_down_01

유형: 기존 수정

**현재 영문**

Now that? … That's a long way down.

**기존 기본 번역**

이제 와서? ...너무 늦었잖아.

**수정 기본 번역**

저기? ...까마득하게 깊군.

수정 이유: long way down을 시간 지연으로 옮긴 오류 수정

## 501. loc_veteran_female_a__mission_forge_elevator_conversation_one_c_02

유형: 기존 수정

**현재 영문**

So Atoman tanks are tougher than most? Can I have one? Might be handy.

**기존 기본 번역**

아토마 전차가 우리보다 강하다고? 나도 하나 가질 수 있어? 유용할 텐데.

**수정 기본 번역**

아토마 전차가 다른 전차보다 튼튼하다고? 나도 하나 가질 수 있어? 유용할 텐데.

수정 이유: 전차끼리의 비교를 전차와 사람의 비교로 옮긴 오류 수정

## 502. loc_veteran_female_a__mission_forge_elevator_conversation_three_c_01

유형: 기존 수정

**현재 영문**

You see? I've already got that nice warm glow of comradeship.

**기존 기본 번역**

내가 듣고싶었던 건 아니지만, 이만하면 괜찮았지.

**수정 기본 번역**

봤지? 벌써 동료애가 따뜻하게 느껴진다니까.

수정 이유: 현재 원문과 다른 대사 수정

## 503. loc_veteran_female_a__mission_hack_01

유형: 기존 수정

**현재 영문**

Don't trust these techie missions. Don't know one end of a data-interrogator from another.

**기존 기본 번역**

이런 기술 임무에 보내지 마. 난 데이터 탐색 장치의 한쪽 끝과 다른 쪽 끝을 구분하지 못한다고.

**수정 기본 번역**

이런 기계 만지는 임무는 못 믿겠어. 난 데이터 탐색 장치는 앞뒤도 구분 못 한다고.

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 504. loc_veteran_female_a__mission_propaganda_elevator_conversation_one_c_01

유형: 기존 수정

**현재 영문**

Must've slipped everyone's minds. Yeah.

**기존 기본 번역**

모두 헷갈렸나 보네. 그래.

**수정 기본 번역**

다들 깜빡한 모양이군. 그래.

수정 이유: slip one's mind를 혼동으로 옮긴 오류 수정

## 505. loc_veteran_female_a__mission_retrieve_02

유형: 기존 수정

**현재 영문**

Dragging stuff around under fire? Just a day like any other. Ain't that right, comrades?

**기존 기본 번역**

총 쏘면서 물건 끌고 다니는 거? 여느 날과 같군. 그렇지 않아, 동지들?

**수정 기본 번역**

총격을 받으며 물건을 끌고 다니는 거? 평소랑 같군. 그렇지 않아, 동지들?

수정 이유: under fire를 직접 사격하는 행동으로 옮긴 오류 수정

## 506. loc_veteran_female_a__mission_station_end_event_conversation_two_c_02

유형: 기존 수정

**현재 영문**

Fragging great. Time to be miracle workers.

**기존 기본 번역**

존나 좋군. 기적의 노동자가 될 시간이야!

**수정 기본 번역**

존나 좋군. 기적을 일으킬 시간이야!

수정 이유: miracle workers 관용 표현 수정

## 507. loc_veteran_female_a__mission_strain_atmosphere_shield_02

유형: 기존 수정

**현재 영문**

Wonder if there's anything worth having in the wasteland beyond that atmospheric shield?

**기존 기본 번역**

대기 보호막 너머 황무지에 과연 우리가 지켜야 할 만한 뭔가가 있을까?

**수정 기본 번역**

대기 보호막 너머 황무지에 과연 우리가 가질 만한 뭔가가 있을까?

수정 이유: worth having의 의미 수정

## 508. loc_veteran_female_a__response_for_friendly_fire_from_veteran_to_veteran_02

유형: 기존 수정

**현재 영문**

It's my sights.

**기존 기본 번역**

내 시야 안에 있어.

**수정 기본 번역**

조준기 탓이야.

수정 이유: 오발 관련 조준기 변명을 시야 확인으로 옮긴 오류 수정

## 509. loc_veteran_female_a__response_for_heard_horde_vector_01

유형: 기존 수정

**현재 영문**

Stand ready!

**기존 기본 번역**

정면으로 맞서라!

**수정 기본 번역**

준비 태세를 갖춰라!

수정 이유: Stand ready의 준비 지시 반영

## 510. loc_veteran_female_b__found_ammo_low_on_ammo_01

유형: 기존 수정

**현재 영문**

Ammo! About karking time!

**기존 기본 번역**

탄약이다! 빌어먹을 보급이로군!

**수정 기본 번역**

탄약이다! 빌어먹을, 이제야 나왔군!

수정 이유: about time의 지연 강조 복원

## 511. loc_veteran_female_b__knocked_down_1_07

유형: 기존 수정

**현재 영문**

No one say a bloody word!

**기존 기본 번역**

고약한 녀석들아! 도와줘!

**수정 기본 번역**

아무도 한마디도 하지 마라!

수정 이유: 현재 ID의 영문과 다른 자막 수정

## 512. loc_veteran_female_b__look_at_healthstation_06

유형: 기존 수정

**현재 영문**

Meds? There's a code for this, too…

**기존 기본 번역**

메디카에 스테이션? 이것도 쓰는 법이 있지...

**수정 기본 번역**

메디카에 스테이션? 이것도 암호명이 있었는데…

수정 이유: code를 사용법으로 옮긴 오류 수정; 영문과 기존 두 모드 번역이 완전히 같은 반복 문구에도 적용

## 513. loc_veteran_female_b__lore_the_warp_two_c_01

유형: 기존 수정

**현재 영문**

Long as the Gellar Fields hold, we'll be safe. Probably.

**기존 기본 번역**

고개 들어. 우리가 겔라 필드를 유지하는 이유도 바로 이거라고.

**수정 기본 번역**

겔라 필드가 유지되는 한 우린 안전할 거야. 아마도.

수정 이유: 서로 뒤바뀐 두 대사의 ID 연결 수정

## 514. loc_veteran_female_b__lore_the_warp_two_c_02

유형: 기존 수정

**현재 영문**

Chin up - this is why we have Gellar Fields.

**기존 기본 번역**

겔라 필드가 유지되는 한 우린 안전할 거야. 아마도.

**수정 기본 번역**

기운 내. 우리가 겔라 필드를 쓰는 이유가 바로 이거잖아.

수정 이유: 서로 뒤바뀐 두 대사의 ID 연결 수정

## 515. loc_veteran_female_b__mission_complex_elevator_conversation_1_a_01

유형: 기존 수정

**현재 영문**

Was I imagining all those nice, big comms arrays on the Mourningstar?

**기존 기본 번역**

모어닝스타에서 이렇게 장대한 통신 배열을 볼 거라고 상상은 했을까?

**수정 기본 번역**

모어닝스타에서 본 그 크고 멋진 통신 장비들은 다 내 상상이었나?

수정 이유: 회상하는 반문을 미래 예상으로 옮긴 오류 수정

## 516. loc_veteran_female_b__mission_cooling_long_way_down_01

유형: 기존 수정

**현재 영문**

It's a fair old drop, ain't it? You could lose a hab block in here.

**기존 기본 번역**

굉장히 오래된 곳인데? 여기에서는 거주 구역도 못 찾겠어.

**수정 기본 번역**

엄청 깊은데? 거주 구역 하나가 통째로 들어가도 안 보이겠어.

수정 이유: fair old drop을 오래된 장소로 옮긴 오류 수정

## 517. loc_veteran_female_b__mission_scan_02

유형: 기존 수정

**현재 영문**

Once the mission's done, let's see if we can't flog this servo-skull to one of the mud thumpers back at HQ.

**기존 기본 번역**

임무를 완수하면, 이 서보 스컬을 본부에 있는 진흙 투척기로 날려버릴 수 있는지 보자고.

**수정 기본 번역**

임무가 끝나면 이 서보 스컬을 본부에 있는 보병 중 누군가한테 팔아넘겨 볼까?

수정 이유: flog를 팔기가 아닌 날려버리기로 옮긴 오류 수정

## 518. loc_veteran_female_b__mission_strain_atmosphere_shield_01

유형: 기존 수정

**현재 영문**

[Cough] Some use that atmospheric shield is. Every breath's a mouthful of karking grit.

**기존 기본 번역**

[기침] 대기 보호막이라니 참 유용하기도 하네. 숨 쉴 때마다 소금을 들이마시는 거 같아.

**수정 기본 번역**

[기침] 대기 보호막이라니 참 유용하기도 하네. 숨 쉴 때마다 모래알을 들이마시는 거 같아.

수정 이유: grit을 소금으로 옮긴 오류 수정

## 519. loc_veteran_female_c__bonding_conversation_headshot_extension_vet_c_vet_a_d_01

유형: 기존 수정

**현재 영문**

Cadia was the Guard. Cadia is the Guard. Everyone else just copies what we do.

**기존 기본 번역**

카디아는 가드 그 자체였어. 진짜 가드 말이야. 그 외에는 모두 우리의 복제품일 뿐이지.

**수정 기본 번역**

카디아는 가드 그 자체였어. 지금도 가드 그 자체지. 다른 놈들은 우리가 하는 걸 따라 할 뿐이야.

수정 이유: 과거와 현재를 강조한 대사 복원

## 520. loc_veteran_female_c__enemy_kill_grenadier_04

유형: 기존 수정

**현재 영문**

Bomber kill!

**기존 기본 번역**

보머군. 처치해야 해!

**수정 기본 번역**

보머 처치!

수정 이유: 처치 완료 보고를 공격 지시로 옮긴 오류 수정

## 521. loc_veteran_female_c__enemy_kill_grenadier_07

유형: 기존 수정

**현재 영문**

Scratched the bomber!

**기존 기본 번역**

보머를 그어버렸다!

**수정 기본 번역**

보머를 처리했다!

수정 이유: scratch의 처치 관용 표현 수정

## 522. loc_veteran_female_c__lore_daemons_four_c_01

유형: 기존 수정

**현재 영문**

Cadia held the Eye shut for Millennia. Now it's gone, and Chaos is everywhere.

**기존 기본 번역**

카디아는 수백만 년 동안 그곳을 맞서고 있었지. 카디아가 없어진 뒤 사방에 카오스로 가득해졌어.

**수정 기본 번역**

카디아는 수천 년 동안 아이 오브 테러를 막고 있었지. 카디아가 없어진 뒤 사방이 카오스로 가득해졌어.

수정 이유: Millennia를 수백만 년으로 옮긴 단위 오류 수정

## 523. loc_veteran_female_c__lore_space_marines_three_c_02

유형: 기존 수정

**현재 영문**

Even if a son of the Emperor has returned, it's not going to help this sump hole of a world.

**기존 기본 번역**

황제 폐하의 아들이 돌아왔다 해도 그게 세상에 난 구멍을 막아주지는 못해.

**수정 기본 번역**

황제 폐하의 아들이 돌아왔다 해도 이 시궁창 같은 행성에는 도움이 안 될 거야.

수정 이유: sump hole of a world의 비유를 실제 구멍으로 옮긴 오류 수정

## 524. loc_veteran_female_c__lore_space_marines_two_b_02

유형: 기존 수정

**현재 영문**

Soldiers in the Guard don't get to read the words of the Emperor's sons.

**기존 기본 번역**

가드의 병사들은 황제 폐하의 아들들에 대한 글을 읽을 시간이 없거든.

**수정 기본 번역**

가드 병사들은 황제 폐하의 아들들이 쓴 글을 읽을 기회가 없어.

수정 이유: 글의 저자와 소재를 혼동한 오류 수정

## 525. loc_veteran_female_c__mission_complex_elevator_conversation_2_c_02

유형: 기존 수정

**현재 영문**

Need to know, is that it? Copy.

**기존 기본 번역**

알아야 할 사항은, 그게 다인가? 확인했다.

**수정 기본 번역**

알아야 할 것만 알려주겠다는 건가? 확인했다.

수정 이유: need to know의 정보 제한 의미 복원

## 526. loc_veteran_female_c__mission_cooling_elevator_conversation_three_line_one_02

유형: 기존 수정

**현재 영문**

Work force is gone. Any survivors will be executed. New population brought in. Count on it.

**기존 기본 번역**

노동 인력은 사라졌어. 살아남은 자들은 모두 처형되겠지. 이후 새로운 사람들이 유입될 거고. 기대하라고.

**수정 기본 번역**

노동 인력은 사라졌어. 살아남은 자들은 모두 처형되겠지. 이후 새로운 사람들이 유입될 거고. 틀림없어.

수정 이유: 확신을 나타내는 표현을 기대하라는 권유로 옮긴 오류 수정

## 527. loc_veteran_male_a__ability_ranger_10

유형: 기존 수정

**현재 영문**

Engaging critical target.

**기존 기본 번역**

중요 목표물을 제거하겠다.

**수정 기본 번역**

중요 목표물과 교전한다.

수정 이유: Engaging을 처치 완료로 오해하지 않도록 수정

## 528. loc_veteran_male_a__event_survive_keep_coming_a_02

유형: 기존 수정

**현재 영문**

Give me some fragging fire discipline!

**기존 기본 번역**

빌어먹을 사격 훈련 좀 시켜달라고!

**수정 기본 번역**

빌어먹을, 사격 규율 좀 지켜!

수정 이유: 사격 규율 지시를 훈련 요청으로 옮긴 오류 수정

## 529. loc_veteran_male_a__heard_enemy_chaos_spawn_01

유형: 기존 수정

**현재 영문**

It's a Fleshbag!

**기존 기본 번역**

부패덩어리다!

**수정 기본 번역**

살덩이다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 530. loc_veteran_male_a__heard_enemy_chaos_spawn_02

유형: 기존 수정

**현재 영문**

Fleshbag, coming in!

**기존 기본 번역**

부패덩어리다, 응답하라!

**수정 기본 번역**

살덩이가 다가온다!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 531. loc_veteran_male_a__heard_enemy_chaos_spawn_03

유형: 기존 수정

**현재 영문**

Fleshbag!

**기존 기본 번역**

부패덩어리다!

**수정 기본 번역**

살덩이다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 532. loc_veteran_male_a__heard_enemy_chaos_spawn_04

유형: 기존 수정

**현재 영문**

I hear a Fleshbag!

**기존 기본 번역**

부패덩어리 소리가 들려!

**수정 기본 번역**

살덩이 소리가 들려!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 533. loc_veteran_male_a__heard_enemy_chaos_spawn_08

유형: 기존 수정

**현재 영문**

Hear that? Could be a Fleshbag.

**기존 기본 번역**

들었어? 부패덩어리 소리 같아.

**수정 기본 번역**

들었어? 살덩이 소리 같아.

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 534. loc_veteran_male_a__heard_enemy_chaos_spawn_09

유형: 기존 수정

**현재 영문**

Is that a Fleshbag?

**기존 기본 번역**

부패덩어리인가!

**수정 기본 번역**

살덩이인가!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 535. loc_veteran_male_a__heard_enemy_chaos_spawn_10

유형: 기존 수정

**현재 영문**

Sounds like a fragging Fleshbag…

**기존 기본 번역**

부패덩어리 소리 같은데...

**수정 기본 번역**

살덩이 소리 같은데...

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 536. loc_veteran_male_a__lore_the_warp_four_b_01

유형: 기존 수정

**현재 영문**

Well, it sort of folds into the Immaterium and... um... Does anyone else wanna take this?

**기존 기본 번역**

이렇게 접어서 이마테리움을 만들고... 그... 음... 이어서 설명해줄 사람?

**수정 기본 번역**

그게, 이마테리움 안으로 접혀 들어가서... 음... 누가 대신 설명 좀 해줄래?

수정 이유: 이마테리움으로 진입하는 것을 생성으로 옮긴 오류 수정

## 537. loc_veteran_male_a__mission_complex_start_banter_a_01

유형: 기존 수정

**현재 영문**

Another mission with spotty intel. Just my fragging luck.

**기존 기본 번역**

짜증나는 정보원과 또 임무를 하라니. 빌어먹을 운이로군.

**수정 기본 번역**

부실한 정보로 또 임무를 하라니. 빌어먹을 내 팔자야.

수정 이유: spotty intel을 짜증나는 정보원으로 옮긴 오류 수정

## 538. loc_veteran_male_a__mission_cooling_elevator_conversation_three_line_one_01

유형: 기존 수정

**현재 영문**

Even if we can save the manufactorum, I reckon the workers have had it.

**기존 기본 번역**

우리가 이 매뉴팩토룸을 구한다 해도, 노동자들은 이미 알게 되었을 텐데.

**수정 기본 번역**

매뉴팩토룸을 구해도, 노동자들은 이미 끝장났을 것 같은데.

수정 이유: have had it을 알게 됨으로 옮긴 오류 수정

## 539. loc_veteran_male_a__mission_cooling_long_way_down_01

유형: 기존 수정

**현재 영문**

Now that? … That's a long way down.

**기존 기본 번역**

이제 와서? ...너무 늦었잖아.

**수정 기본 번역**

저기? ...까마득하게 깊군.

수정 이유: long way down을 시간 지연으로 옮긴 오류 수정

## 540. loc_veteran_male_a__mission_forge_elevator_conversation_one_c_02

유형: 기존 수정

**현재 영문**

So Atoman tanks are tougher than most? Can I have one? Might be handy.

**기존 기본 번역**

아토마 전차가 우리보다 강하다고? 나도 하나 가질 수 있어? 유용할 텐데.

**수정 기본 번역**

아토마 전차가 다른 전차보다 튼튼하다고? 나도 하나 가질 수 있어? 유용할 텐데.

수정 이유: 전차끼리의 비교를 전차와 사람의 비교로 옮긴 오류 수정

## 541. loc_veteran_male_a__mission_forge_elevator_conversation_three_c_01

유형: 기존 수정

**현재 영문**

You see? I've already got that nice warm glow of comradeship.

**기존 기본 번역**

내가 듣고싶었던 건 아니지만, 이만하면 괜찮았지.

**수정 기본 번역**

봤지? 벌써 동료애가 따뜻하게 느껴진다니까.

수정 이유: 현재 원문과 다른 대사 수정

## 542. loc_veteran_male_a__mission_hack_01

유형: 기존 수정

**현재 영문**

Don't trust these techie missions. I don't know one end of a data-interrogator from another.

**기존 기본 번역**

이런 기술 임무에 보내지 마. 난 데이터 탐색 장치의 한쪽 끝과 다른 쪽 끝을 구분하지 못한다고.

**수정 기본 번역**

이런 기계 만지는 임무는 못 믿겠어. 난 데이터 탐색 장치는 앞뒤도 구분 못 한다고.

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 543. loc_veteran_male_a__mission_propaganda_elevator_conversation_one_c_01

유형: 기존 수정

**현재 영문**

Must've slipped everyone's minds. Yeah.

**기존 기본 번역**

모두 헷갈렸나 보네. 그래.

**수정 기본 번역**

다들 깜빡한 모양이군. 그래.

수정 이유: slip one's mind를 혼동으로 옮긴 오류 수정

## 544. loc_veteran_male_a__mission_retrieve_02

유형: 기존 수정

**현재 영문**

Dragging stuff around under fire? Just a day like any other. Ain't that right, comrades?

**기존 기본 번역**

총 쏘면서 물건 끌고 다니는 거? 여느 날과 같군. 그렇지 않아, 동지들?

**수정 기본 번역**

총격을 받으며 물건을 끌고 다니는 거? 평소랑 같군. 그렇지 않아, 동지들?

수정 이유: under fire를 직접 사격하는 행동으로 옮긴 오류 수정

## 545. loc_veteran_male_a__mission_station_end_event_conversation_two_c_02

유형: 기존 수정

**현재 영문**

Fragging great. Time to be miracle workers.

**기존 기본 번역**

존나 좋군. 기적의 노동자가 될 시간이야!

**수정 기본 번역**

존나 좋군. 기적을 일으킬 시간이야!

수정 이유: miracle workers 관용 표현 수정

## 546. loc_veteran_male_a__mission_strain_atmosphere_shield_02

유형: 기존 수정

**현재 영문**

Wonder if there's anything worth having in the wasteland beyond that atmospheric shield?

**기존 기본 번역**

대기 보호막 너머 황무지에 과연 우리가 지켜야 할 만한 뭔가가 있을까?

**수정 기본 번역**

대기 보호막 너머 황무지에 과연 우리가 가질 만한 뭔가가 있을까?

수정 이유: worth having의 의미 수정

## 547. loc_veteran_male_a__response_for_friendly_fire_from_veteran_to_veteran_02

유형: 기존 수정

**현재 영문**

It's my sights.

**기존 기본 번역**

내 시야 안에 있어.

**수정 기본 번역**

조준기 탓이야.

수정 이유: 오발 관련 조준기 변명을 시야 확인으로 옮긴 오류 수정

## 548. loc_veteran_male_a__response_for_heard_horde_vector_01

유형: 기존 수정

**현재 영문**

Stand ready!

**기존 기본 번역**

정면으로 맞서라!

**수정 기본 번역**

준비 태세를 갖춰라!

수정 이유: Stand ready의 준비 지시 반영

## 549. loc_veteran_male_a__seen_enemy_shocktrooper_04

유형: 기존 수정

**현재 영문**

They've got a shotgun!

**기존 기본 번역**

샷건 발견!

**수정 기본 번역**

놈이 샷건을 들고 있다!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 550. loc_veteran_male_b__found_ammo_low_on_ammo_01

유형: 기존 수정

**현재 영문**

Ammo! About karking time!

**기존 기본 번역**

탄약이다! 빌어먹을 보급이로군!

**수정 기본 번역**

탄약이다! 빌어먹을, 이제야 나왔군!

수정 이유: about time의 지연 강조 복원

## 551. loc_veteran_male_b__heard_enemy_chaos_spawn_03

유형: 기존 수정

**현재 영문**

Fleshbag!

**기존 기본 번역**

부패덩어리야!

**수정 기본 번역**

살덩이야!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 552. loc_veteran_male_b__knocked_down_1_07

유형: 기존 수정

**현재 영문**

No one say a bloody word!

**기존 기본 번역**

고약한 녀석들아! 도와줘!

**수정 기본 번역**

아무도 한마디도 하지 마라!

수정 이유: 현재 ID의 영문과 다른 자막 수정

## 553. loc_veteran_male_b__look_at_healthstation_06

유형: 기존 수정

**현재 영문**

Meds? There's a code for this, too…

**기존 기본 번역**

메디카에 스테이션? 이것도 쓰는 법이 있지...

**수정 기본 번역**

메디카에 스테이션? 이것도 암호명이 있었는데…

수정 이유: code를 사용법으로 옮긴 오류 수정

## 554. loc_veteran_male_b__lore_the_emperor_one_a_01

유형: 기존 수정

**현재 영문**

Always wondered what the voice of the Emperor sounds like.

**기존 기본 번역**

황제 폐하께서는 누구에게 명령을 내리시는 걸까? 항상 궁금했어.

**수정 기본 번역**

황제 폐하의 목소리는 어떨까 늘 궁금했어.

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 555. loc_veteran_male_b__lore_the_emperor_one_a_04

유형: 기존 수정

**현재 영문**

Ever wonder how the Emperor gives his orders?

**기존 기본 번역**

황제 폐하께서 누구한테 명령을 내리시는 걸까 생각해본 적 있어?

**수정 기본 번역**

황제 폐하께서 어떻게 명령을 내리실지 생각해 본 적 있어?

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 556. loc_veteran_male_b__lore_the_warp_two_c_01

유형: 기존 수정

**현재 영문**

Long as the Gellar Fields hold, we'll be safe. Probably.

**기존 기본 번역**

고개 들어. 우리가 겔라 필드를 유지하는 이유도 바로 이거라고.

**수정 기본 번역**

겔라 필드가 유지되는 한 우린 안전할 거야. 아마도.

수정 이유: 서로 뒤바뀐 두 대사의 ID 연결 수정

## 557. loc_veteran_male_b__lore_the_warp_two_c_02

유형: 기존 수정

**현재 영문**

Chin up - this is why we have Gellar Fields.

**기존 기본 번역**

겔라 필드가 유지되는 한 우린 안전할 거야. 아마도.

**수정 기본 번역**

기운 내. 우리가 겔라 필드를 쓰는 이유가 바로 이거잖아.

수정 이유: 서로 뒤바뀐 두 대사의 ID 연결 수정

## 558. loc_veteran_male_b__mission_complex_elevator_conversation_1_a_01

유형: 기존 수정

**현재 영문**

Was I imagining all those nice, big comms arrays on the Mourningstar?

**기존 기본 번역**

모어닝스타에서 이렇게 장대한 통신 배열을 볼 거라고 상상은 했을까?

**수정 기본 번역**

모어닝스타에서 본 그 크고 멋진 통신 장비들은 다 내 상상이었나?

수정 이유: 회상하는 반문을 미래 예상으로 옮긴 오류 수정

## 559. loc_veteran_male_b__mission_cooling_long_way_down_01

유형: 기존 수정

**현재 영문**

It's a fair old drop, ain't it? You could lose a hab block in here.

**기존 기본 번역**

굉장히 오래된 곳인데? 여기에서는 거주 구역도 못 찾겠어.

**수정 기본 번역**

엄청 깊은데? 거주 구역 하나가 통째로 들어가도 안 보이겠어.

수정 이유: fair old drop을 오래된 장소로 옮긴 오류 수정

## 560. loc_veteran_male_b__mission_scan_02

유형: 기존 수정

**현재 영문**

Once the mission's done, let's see if we can't flog this servo-skull to one of the mud thumpers back at HQ.

**기존 기본 번역**

임무를 완수하면, 이 서보 스컬을 본부에 있는 진흙 투척기로 날려버릴 수 있는지 보자고.

**수정 기본 번역**

임무가 끝나면 이 서보 스컬을 본부에 있는 보병 중 누군가한테 팔아넘겨 볼까?

수정 이유: flog를 팔기가 아닌 날려버리기로 옮긴 오류 수정

## 561. loc_veteran_male_b__mission_strain_atmosphere_shield_01

유형: 기존 수정

**현재 영문**

[Cough] Some use that atmospheric shield is. Every breath's a mouthful of karking grit.

**기존 기본 번역**

[기침] 대기 보호막이라니 참 유용하기도 하네. 숨 쉴 때마다 소금을 들이마시는 거 같아.

**수정 기본 번역**

[기침] 대기 보호막이라니 참 유용하기도 하네. 숨 쉴 때마다 모래알을 들이마시는 거 같아.

수정 이유: grit을 소금으로 옮긴 오류 수정

## 562. loc_veteran_male_c__enemy_kill_grenadier_04

유형: 기존 수정

**현재 영문**

Bomber kill!

**기존 기본 번역**

보머군. 처치해야 해!

**수정 기본 번역**

보머 처치!

수정 이유: 처치 완료 보고를 공격 지시로 옮긴 오류 수정; 영문과 기존 두 모드 번역이 완전히 같은 반복 문구에도 적용

## 563. loc_veteran_male_c__enemy_kill_grenadier_07

유형: 기존 수정

**현재 영문**

Scratched the bomber!

**기존 기본 번역**

보머를 그어버렸다!

**수정 기본 번역**

보머를 처리했다!

수정 이유: scratch의 처치 관용 표현 수정; 영문과 기존 두 모드 번역이 완전히 같은 반복 문구에도 적용

## 564. loc_veteran_male_c__lore_daemons_four_c_01

유형: 기존 수정

**현재 영문**

Cadia held the Eye shut for Millennia. Now it's gone, and Chaos is everywhere.

**기존 기본 번역**

카디아는 수백만 년 동안 그곳을 맞서고 있었지. 카디아가 없어진 뒤 사방에 카오스로 가득해졌어.

**수정 기본 번역**

카디아는 수천 년 동안 아이 오브 테러를 막고 있었지. 카디아가 없어진 뒤 사방이 카오스로 가득해졌어.

수정 이유: Millennia를 수백만 년으로 옮긴 단위 오류 수정

## 565. loc_veteran_male_c__lore_space_marines_three_c_02

유형: 기존 수정

**현재 영문**

Even if a son of the Emperor has returned, it's not going to help this sump hole of a world.

**기존 기본 번역**

황제 폐하의 아들이 돌아왔다 해도 그게 세상에 난 구멍을 막아주지는 못해.

**수정 기본 번역**

황제 폐하의 아들이 돌아왔다 해도 이 시궁창 같은 행성에는 도움이 안 될 거야.

수정 이유: sump hole of a world의 비유를 실제 구멍으로 옮긴 오류 수정

## 566. loc_veteran_male_c__lore_space_marines_two_b_02

유형: 기존 수정

**현재 영문**

Soldiers in the Guard don't get to read the words of the Emperor's sons.

**기존 기본 번역**

가드의 병사들은 황제 폐하의 아들들에 대한 글을 읽을 시간이 없거든.

**수정 기본 번역**

가드 병사들은 황제 폐하의 아들들이 쓴 글을 읽을 기회가 없어.

수정 이유: 글의 저자와 소재를 혼동한 오류 수정

## 567. loc_veteran_male_c__lore_the_warp_two_c_01

유형: 기존 수정

**현재 영문**

Pray and don't listen to the whispers. That's my advice.

**기존 기본 번역**

겔라 필드가 버티길 빌자고. 우리가 할 수 있는 건 그게 다야.

**수정 기본 번역**

기도하고, 속삭임에는 귀 기울이지 마. 그게 내 조언이야.

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 568. loc_veteran_male_c__mission_complex_elevator_conversation_2_c_02

유형: 기존 수정

**현재 영문**

Need to know, is that it? Copy.

**기존 기본 번역**

알아야 할 사항은, 그게 다인가? 확인했다.

**수정 기본 번역**

알아야 할 것만 알려주겠다는 건가? 확인했다.

수정 이유: need to know의 정보 제한 의미 복원

## 569. loc_veteran_male_c__mission_cooling_elevator_conversation_three_line_one_02

유형: 기존 수정

**현재 영문**

Work force is gone. Any survivors will be executed. New population brought in. Count on it.

**기존 기본 번역**

노동 인력은 사라졌어. 살아남은 자들은 모두 처형되겠지. 이후 새로운 사람들이 유입될 거고. 기대하라고.

**수정 기본 번역**

노동 인력은 사라졌어. 살아남은 자들은 모두 처형되겠지. 이후 새로운 사람들이 유입될 거고. 틀림없어.

수정 이유: 확신을 나타내는 표현을 기대하라는 권유로 옮긴 오류 수정

## 570. loc_veteran_male_c__mission_station_the_bridge_01

유형: 기존 수정

**현재 영문**

Small arms fire to the south. Low level.

**기존 기본 번역**

남쪽에 소형 화기 소리야. 심각하지 않은 교전 같군.

**수정 기본 번역**

남쪽에서 소화기 사격 소리. 낮은 곳이다.

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 571. loc_veteran_male_c__seen_enemy_sniper_04

유형: 기존 수정

**현재 영문**

Sniper! Down! Down!

**기존 기본 번역**

스나이퍼! 제압해! 제압!

**수정 기본 번역**

스나이퍼다! 숙여! 엎드려!

수정 이유: Down을 적 제압 명령으로 옮긴 오류 수정

## 572. loc_vocator_b__hub_propaganda_announcement_24

유형: 기존 수정

**현재 영문**

Guard thy tongue, lest it speak heresy unbidden.

**기존 기본 번역**

입 조심하십시오. 배교를 논하는 것은 금지되어 있습니다.

**수정 기본 번역**

입을 조심하십시오. 자신도 모르게 이단의 말을 내뱉지 않도록.

수정 이유: unbidden의 비의도적 발언 의미 복원

## 573. loc_vocator_b__hub_propaganda_announcement_25

유형: 기존 수정

**현재 영문**

Struggle has ever been humanity's lot. Disgrace not those who walked this path before.

**기존 기본 번역**

분쟁은 항상 인류가 원래 걷는 길이었습니다. 이 길을 걷지 않는 자들이여, 부끄러워하십시오.

**수정 기본 번역**

투쟁은 언제나 인류의 숙명이었습니다. 앞서 이 길을 걸은 이들을 욕되게 하지 마십시오.

수정 이유: 욕되게 하지 말아야 하는 대상 복원

## 574. loc_weapon_family_autogun_p2_m1

유형: 기존 수정

**현재 영문**

Braced Autogun

**기존 기본 번역**

브레이스드 오토건

**수정 기본 번역**

브레이스드 오토건

**기존 / 수정 커스텀 번역**

버팀목 오토건

→ 견착식 오토건

수정 이유: Braced의 무기 견착 의미 반영

## 575. loc_weapon_family_autogun_p2_m2

유형: 기존 수정

**현재 영문**

Braced Autogun

**기존 기본 번역**

브레이스드 오토건

**수정 기본 번역**

브레이스드 오토건

**기존 / 수정 커스텀 번역**

버팀목 오토건

→ 견착식 오토건

수정 이유: Braced의 무기 견착 의미 반영

## 576. loc_weapon_family_autogun_p2_m3

유형: 기존 수정

**현재 영문**

Braced Autogun

**기존 기본 번역**

브레이스드 오토건

**수정 기본 번역**

브레이스드 오토건

**기존 / 수정 커스텀 번역**

버팀목 오토건

→ 견착식 오토건

수정 이유: Braced의 무기 견착 의미 반영

## 577. loc_weapon_family_powermaul_p3_m1

유형: 추가 ID 덮어쓰기

**현재 영문**

Arc Maul

**기존 기본 번역**

아크 몰

**수정 기본 번역**

아크 마울

수정 이유: 기존 무기 용어와 통일

## 578. loc_weapon_family_powersword_p3_m1

유형: 추가 ID 덮어쓰기

**현재 영문**

Mechanicus Power Sword

**기존 기본 번역**

메카니쿠스 파워 검

**수정 기본 번역**

메카니쿠스 파워 소드

수정 이유: 기존 무기 용어와 통일

## 579. loc_weapon_family_transonic_claw_p1_m1

유형: 추가 ID 덮어쓰기

**현재 영문**

*Transonic claw

**기존 기본 번역**

*Transonic claw

**수정 기본 번역**

*트랜소닉 클로

수정 이유: 한국어에도 영어로 남아 있는 무기 계열명 번역; 원문의 별표 보존

## 580. loc_weapon_family_transonic_knife_p1_m1

유형: 추가 ID 덮어쓰기

**현재 영문**

*Transonic Knife

**기존 기본 번역**

*Transonic Knife

**수정 기본 번역**

*트랜소닉 나이프

수정 이유: 한국어에도 영어로 남아 있는 무기 계열명 번역; 원문의 별표 보존

## 581. loc_weapon_family_transonic_sword_p1_m1

유형: 추가 ID 덮어쓰기

**현재 영문**

*Transonic Sword

**기존 기본 번역**

*Transonic Sword

**수정 기본 번역**

*트랜소닉 소드

수정 이유: 한국어에도 영어로 남아 있는 무기 계열명 번역; 원문의 별표 보존

## 582. loc_weapon_special_defensive_stance_desc

유형: 기존 수정

**현재 영문**

Plant the Slab Shield into the ground and enter a defensive stance, capable of withstanding all but the strongest attacks.

**기존 기본 번역**

슬랩 실드를 바닥에 꽂고 방어 자세를 취해 아무리 강한 공격에도 견뎌낼 수 있습니다.

**수정 기본 번역**

슬랩 실드를 바닥에 꽂고 방어 자세를 취합니다. 가장 강력한 공격을 제외한 대부분의 공격을 견뎌낼 수 있습니다.

수정 이유: all but the strongest의 예외 조건 누락 복원

## 583. loc_zealot_female_a__ability_maniac_03

유형: 기존 수정

**현재 영문**

Praise the Master!

**기존 기본 번역**

주인님께서 내게 힘을 주신다!

**수정 기본 번역**

주인님을 찬양하라!

수정 이유: 해당 문구 ID의 현재 대사로 수정

## 584. loc_zealot_female_a__com_wheel_vo_for_the_emperor_01

유형: 기존 수정

**현재 영문**

For the Master of Mankind!

**기존 기본 번역**

주인님께서 우릴 보신다!

**수정 기본 번역**

인류의 주인님을 위하여!

수정 이유: 현재 원문과 다른 대사 수정

## 585. loc_zealot_female_a__conversation_combat_chaos_spawn_chew_c_01

유형: 기존 수정

**현재 영문**

Unhand the sinner, creature!

**기존 기본 번역**

인류의 주인님이시여! 사방에 피로군!

**수정 기본 번역**

그 죄인을 놓아라, 괴물아!

수정 이유: 현재 원문과 다른 대사 수정

## 586. loc_zealot_female_a__conversation_plague_ogryn_weakpoint_03_02

유형: 기존 수정

**현재 영문**

I approve this holy course!

**기존 기본 번역**

이 성스러운 과정에 자원하겠다!

**수정 기본 번역**

이 성스러운 방침에 찬성한다!

수정 이유: approve를 자원으로 옮긴 오류 수정

## 587. loc_zealot_female_a__hacking_auspex_mutter_a_03

유형: 기존 수정

**현재 영문**

Confound this thing ...

**기존 기본 번역**

이거 헷갈리잖아...

**수정 기본 번역**

빌어먹을 녀석...

수정 이유: confound의 저주 표현을 혼란으로 옮긴 오류 수정

## 588. loc_zealot_female_a__head_shot_04

유형: 기존 수정

**현재 영문**

The Master of Mankind guide thy aim!

**기존 기본 번역**

인류의 주인님께서 그대의 목표를 인도하신다!

**수정 기본 번역**

인류의 주인님께서 그대의 조준를 인도하신다!

수정 이유: aim 용어 수정

## 589. loc_zealot_female_a__heard_horde_vector_02

유형: 기존 수정

**현재 영문**

They come in search of cleansing wrath. They shall find it.

**기존 기본 번역**

녀석들은 분노를 씻기 위해 오는 것이다. 그들이 찾아낼 거다.

**수정 기본 번역**

놈들은 정화의 분노를 찾아오는 것이다. 원하는 대로 받게 될 것이다.

수정 이유: cleansing wrath의 수식 관계 수정

## 590. loc_zealot_female_a__look_at_healthstation_07

유형: 기존 수정

**현재 영문**

Respite, and well-earned.

**기존 기본 번역**

휴식을 취해야, 결과도 좋아진다.

**수정 기본 번역**

휴식이로군. 충분히 누릴 자격이 있지.

수정 이유: well-earned respite의 뜻 복원

## 591. loc_zealot_female_a__lore_daemons_four_b_02

유형: 기존 수정

**현재 영문**

Tis the Ocularis Terribus... A great rent in the Immaterium, in which lurketh heresy and madness.

**기존 기본 번역**

오큘라리스 테리부스... 이마테리움에 있는 이 거대한 장소에는 배교와 광기가 판을 치고 있다.

**수정 기본 번역**

오큘라리스 테리부스... 이마테리움의 거대한 균열이며, 이단과 광기가 도사리는 곳이지.

수정 이유: rent를 장소로만 옮겨 빠진 균열 의미 복원

## 592. loc_zealot_female_a__lore_space_marines_four_c_02

유형: 기존 수정

**현재 영문**

The Adeptus Astartes are as close to the Master's image as can be. Their nature is inscrutable to mere mortals.

**기존 기본 번역**

아뎁투스 아스타르테스는 주인님의 모습을 최대한 본땄다. 이들의 성정 역시 죄인에게는 불가해한 것이지.

**수정 기본 번역**

아뎁투스 아스타르테스는 주인님의 모습을 최대한 본땄다. 이들의 성정 역시 필멸자에게는 불가해한 것이지.

수정 이유: mere mortals를 죄인으로 옮긴 오류 수정

## 593. loc_zealot_female_a__lore_the_emperor_three_c_01

유형: 기존 수정

**현재 영문**

And what of the great choir of the Astronomican? Proof that even the most wretched can attain glory in the Master's name!

**기존 기본 번역**

그렇다면 아스트로노미칸의 위업은? 가장 더러워진 자들도 주인님의 이름으로 영광을 얻을 수 있는 것이다!

**수정 기본 번역**

그렇다면 아스트로노미칸의 위대한 성가대는? 가장 비천한 자도 주인님의 이름으로 영광을 얻을 수 있다는 증거다!

수정 이유: choir를 위업으로 옮긴 오류 수정

## 594. loc_zealot_female_a__lore_the_warp_three_c_01

유형: 기존 수정

**현재 영문**

I hath heard tales of vessels lost for millennia within the Immaterium, their crews put to the sword as surety against corruption.

**기존 기본 번역**

이마테리움에서 수만 년 전 사라진 함선들의 이야기를 들었다. 그 함선에 탄 자들은 타락을 막기 위해 모두 죽였다고 하더군.

**수정 기본 번역**

이마테리움에서 수천 년 동안 실종됐던 함선들의 이야기를 들었다. 오염을 막으려고 승조원들을 모두 처형했다더군.

수정 이유: millennia의 규모와 실종 기간 수정

## 595. loc_zealot_female_a__lore_zola_one_c_01

유형: 기존 수정

**현재 영문**

Unlike you imbeciles, Sister Zola alloweth not distraction to cloud her mind.

**기존 기본 번역**

그런 발언은 옥좌의 충실한 종에 대한 모독이다.

**수정 기본 번역**

그대들 같은 얼간이와 달리, 졸라 자매는 잡념이 마음을 흐리게 두지 않는다.

수정 이유: 현재 원문과 다른 대사 수정

## 596. loc_zealot_female_a__lore_zola_three_b_01

유형: 기존 수정

**현재 영문**

Sister Zola keepeth the gates of her mind locked and barred - mayhap tis wise 'gainst the likes of thee!

**기존 기본 번역**

졸라는 아군으로부터 비밀을 지킬 수 있을지 모르겠지만, 인류의 주인님은 모든 걸 보고 계신다.

**수정 기본 번역**

졸라 자매는 마음의 문을 단단히 잠가 두었지. 그대 같은 자들을 상대하려면 현명한 일일지도 모르겠군!

수정 이유: 현재 원문과 다른 대사 수정

## 597. loc_zealot_female_a__lore_zola_three_c_02

유형: 기존 수정

**현재 영문**

She hath thus far been nought but a dependable servant of the Master. Let that be an end to it.

**기존 기본 번역**

그 여자는 오랫동안 주인님을 섬기는 충실한 종이었다. 그 끝도 그렇기를 빌자.

**수정 기본 번역**

그녀는 지금껏 주인님의 믿음직한 종이었다. 그걸로 이 이야기는 끝내도록 하지.

수정 이유: let that be an end to it 관용 표현 수정

## 598. loc_zealot_female_a__mission_cartel_elevator_conversation_two_line_three_01

유형: 기존 수정

**현재 영문**

Thou hast no secrets from the Master of Mankind.

**기존 기본 번역**

인류의 주인님께선 비밀은 없으시다.

**수정 기본 번역**

인류의 주인님께 그대의 비밀을 숨길 수는 없다.

수정 이유: 주인님에게 비밀이 없다는 문장으로 주체가 바뀐 오류 수정

## 599. loc_zealot_female_a__mission_cooling_elevator_conversation_one_line_one_02

유형: 기존 수정

**현재 영문**

A tragedy to see a holy forge so slighted. Can its harms be undone?

**기존 기본 번역**

거룩한 단조가 그렇게 무시당하다니 참 비극이군. 그 해악은 돌이킬 수 있나?

**수정 기본 번역**

신성한 단조장이 이토록 훼손되다니 비극이군. 이 피해를 되돌릴 수 있나?

수정 이유: forge가 시설임을 반영

## 600. loc_zealot_female_a__mission_cooling_overseer_office_02

유형: 기존 수정

**현재 영문**

Feel the heat of thy  labours, sinners! It is as naught to the fires of damnation!

**기존 기본 번역**

노동의 열기를 느껴라, 죄인들이여! 이건 저주의 불길에 불과하다!

**수정 기본 번역**

노동의 열기를 느껴라, 죄인들이여! 이것은 저주의 불길에 비하면 아무것도 아니다!

수정 이유: as naught to 비교 구문 누락 복원

## 601. loc_zealot_female_a__mission_forge_elevator_conversation_one_a_01

유형: 기존 수정

**현재 영문**

All of the Master's battle tanks are sacred. Why single out these few?

**기존 기본 번역**

주인님의 전차는 모두 신성하다. 그런데 이렇게 소수만 여기로 보낸 이유는 무엇이지?

**수정 기본 번역**

주인님의 전차는 모두 신성하다. 그런데 왜 이 몇 대만 특별히 고르는 것이지?

수정 이유: single out을 파견으로 옮긴 오류 수정

## 602. loc_zealot_female_a__mission_forge_lifeless_01

유형: 기존 수정

**현재 영문**

No one toils here now. Wouldst that we all meet our ends in the Master's service.

**기존 기본 번역**

여기선 모두 고통 받지 않는군. 주인님을 섬기는 모든 종들의 결말이지.

**수정 기본 번역**

이제 이곳에서 일하는 자는 아무도 없군. 우리 모두 주인님을 섬기다 최후를 맞기를.

수정 이유: toil을 고통으로 옮기고 소망을 사실로 바꾼 오류 수정

## 603. loc_zealot_female_a__mission_hack_01

유형: 기존 수정

**현재 영문**

I understandeth little about machines and servitors, so I shall look to thy knowledge should something go astray.

**기존 기본 번역**

난 기계와 서비터에 대해 아는 게 별로 없으니, 뭔가 잘못되지 않도록 주의해 보겠다.

**수정 기본 번역**

난 기계와 서비터를 잘 모르니, 뭔가 잘못되면 그대의 지식에 의지하겠다.

수정 이유: look to thy knowledge의 의존 대상 복원

## 604. loc_zealot_female_a__mission_propaganda_short_elevator_conversation_three_a_01

유형: 기존 수정

**현재 영문**

Better up here, closer to the Master's light, than down there in the depths of depravity.

**기존 기본 번역**

주인님의 빛에 보다, 가까이 갔다가, 타락의 가장 깊은 곳으로 떨어지다니.

**수정 기본 번역**

타락의 깊은 구렁 저 아래보다는, 주인님의 빛에 가까운 이 위가 낫지.

수정 이유: 위와 아래의 비교를 추락 사건으로 옮긴 오류 수정

## 605. loc_zealot_female_a__mission_raid_trapped_b_03

유형: 기존 수정

**현재 영문**

The vox is dead. Art we to follow?

**기존 기본 번역**

복스는 먹통이야. 기술을 살펴봐야 하나?

**수정 기본 번역**

복스가 죽었군. 다음은 우리 차례인가?

수정 이유: 고어 art를 기술로 혼동한 오류 수정

## 606. loc_zealot_female_a__mission_retrieve_02

유형: 기존 수정

**현재 영문**

The Master of Mankind didst not send me into the world to drag things from place to place!

**기존 기본 번역**

인류의 주인님께서는 날 이리저리 끌고 다니라고 세상에 보내신 게 아니다!

**수정 기본 번역**

인류의 주인님께서 나를 세상에 보내신 건 물건이나 나르라는 뜻이 아니다!

수정 이유: drag things의 목적어를 화자 자신으로 옮긴 오류 수정

## 607. loc_zealot_female_a__mission_scavenge_elevator_conversation_one_line_three_01

유형: 기존 수정

**현재 영문**

The Master of Mankind's works shall endure ten thousand lifetimes, so long as our faith remains true.

**기존 기본 번역**

인류의 주인님의 업적은 우리의 믿음이 진실하게 남아있는 만 년동안 지속될 것이다.

**수정 기본 번역**

우리의 믿음이 진실한 한, 인류의 주인님의 위업은 만 번의 생애가 지나도록 이어질 것이다.

수정 이유: ten thousand lifetimes를 만 년으로 옮긴 오류 수정

## 608. loc_zealot_female_a__mission_scavenge_elevator_conversation_three_line_one_02

유형: 기존 수정

**현재 영문**

Eradicating unholy plague from the Master of Mankind's realm is a most fitting task for us.

**기존 기본 번역**

인류의 주인님의 영역에서 신성불가침한 역병을 퇴치하는 것은 우리에게 가장 잘 맞는 일이지.

**수정 기본 번역**

인류의 주인님의 영역에서 불경한 역병을 퇴치하는 것은 우리에게 가장 잘 맞는 일이지.

수정 이유: unholy를 반대 의미로 옮긴 오류 수정

## 609. loc_zealot_female_a__mission_scavenge_underhalls_01

유형: 기존 수정

**현재 영문**

This ruin is an infested, heretic-riddled warren! Wouldst that we could purge it with flame!

**기존 기본 번역**

이 폐허는 이교도들이 득실거리는 워렌이다! 화염으로 소탕해버릴 수 있으면 좋겠군!

**수정 기본 번역**

이 폐허는 이교도들이 득실거리는 소굴이다! 화염으로 소탕해버릴 수 있으면 좋겠군!

수정 이유: warren을 고유명사로 옮긴 오류 수정

## 610. loc_zealot_female_a__mission_station_station_approach_02

유형: 기존 수정

**현재 영문**

There lieth Chasm Terminus. A grand edifice in need of purification!

**기존 기본 번역**

저기에 캐즘 터미누스가 있다. 정화를 위한 위대한 조형물이지!

**수정 기본 번역**

저기에 캐즘 터미누스가 있다. 정화가 필요한 웅장한 건축물이지!

수정 이유: 정화가 필요한 대상을 정화용 시설로 옮긴 오류 수정

## 611. loc_zealot_female_a__mission_stockpile_main_access_02

유형: 기존 수정

**현재 영문**

Content not with turning from the Master's light, the heretics destroy all they touch.

**기존 기본 번역**

주인님의 빛을 외면하지 말라, 이교도들이 그대의 모든 것을 파괴하리라.

**수정 기본 번역**

주인님의 빛을 등지는 것만으로도 모자라, 이교도들은 손대는 모든 것을 파괴하는군.

수정 이유: content not with의 문장 구조와 주체 복원

## 612. loc_zealot_female_a__mission_stockpile_ruined_hab_01

유형: 기존 수정

**현재 영문**

This hab block is as rotten as the black hearts of its denizens.

**기존 기본 번역**

이 거주 구역은 여기 사는 놈들의 뱃속처럼 시커멓군.

**수정 기본 번역**

이 거주 구역은 주민들의 시커먼 마음만큼이나 썩었군.

수정 이유: rotten의 의미와 비유 대상 복원

## 613. loc_zealot_female_a__mission_strain_inert_tanks_01

유형: 기존 수정

**현재 영문**

These tanks are devoid of heretical contagion. Delve deeper, imbeciles!

**기존 기본 번역**

이 탱크는 이교도의 병원균에 오염됐다. 더 깊이 들어가라, 어리석은 자들아!

**수정 기본 번역**

이 탱크들에는 이단의 병원균이 없다. 더 깊이 들어가라, 어리석은 자들아!

수정 이유: devoid of를 감염됨으로 반대로 옮긴 오류 수정

## 614. loc_zealot_female_a__mission_strain_mid_event_conversation_three_a_01

유형: 기존 수정

**현재 영문**

Exposure to this pathogen is only a worry to the impure of thought. Bad luck, imbeciles!

**기존 기본 번역**

병원체 감염을 걱정하는 건 그저 머릿속에 오염을 더할 뿐이다. 불길한 소리하지 마라, 어리석은 자들!

**수정 기본 번역**

이 병원체에 노출되어 걱정할 자는 생각이 불순한 자들뿐이다. 유감이군, 어리석은 자들아!

수정 이유: 감염 우려의 대상과 조롱을 다른 의미로 옮긴 오류 수정

## 615. loc_zealot_female_a__mission_strain_mid_event_conversation_three_c_02

유형: 기존 수정

**현재 영문**

Thine flesh shall endure so long as thine souls are righteous!

**기존 기본 번역**

그대의 영혼이 정의로운 한, 그대의 육체도 정의롭기를!

**수정 기본 번역**

그대들의 영혼이 의로운 한 육신도 버틸 것이다!

수정 이유: endure의 생존 의미 복원

## 616. loc_zealot_female_a__mission_strain_start_banter_a_01

유형: 기존 수정

**현재 영문**

Master protect us in this den of filth and corruption!

**기존 기본 번역**

주인님께서 우리를 이 오물과 부패의 소굴에서 보호하실 거다!

**수정 기본 번역**

주인님이시여, 이 오물과 부패의 소굴에서 저희를 보호하소서!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 617. loc_zealot_female_a__response_for_zealot_enemy_kill_monster_04

유형: 기존 수정

**현재 영문**

The Master of Mankind is served well this day!

**기존 기본 번역**

인류의 주인님께서 우릴 도우셨도다!

**수정 기본 번역**

오늘 우리는 인류의 주인님을 훌륭히 섬겼도다!

수정 이유: 섬김을 받는 대상과 돕는 주체가 뒤바뀐 오류 수정

## 618. loc_zealot_female_a__surrounded_01

유형: 기존 수정

**현재 영문**

The heretics are numberless!

**기존 기본 번역**

우린 인류의 주인님을 위해 싸운다!

**수정 기본 번역**

이교도들이 끝도 없군!

수정 이유: 현재 원문과 다른 대사 수정

## 619. loc_zealot_female_a__zealot_seen_killstreak_ogryn_01

유형: 기존 수정

**현재 영문**

So the Slab can serve holy cause!

**기존 기본 번역**

그래! 그래! 황제 폐하의 분노로 몸을 채워라, 오그린!

**수정 기본 번역**

그러니 저 덩치도 성스러운 대의를 섬길 수 있군!

수정 이유: 현재 원문과 다른 대사 수정

## 620. loc_zealot_female_b__ability_banisher_05

유형: 기존 수정

**현재 영문**

Let wrath gather! Let all be cleansed!

**기존 기본 번역**

나의 분노로 너희들을 정화하리라, 가여운 자들이여!

**수정 기본 번역**

분노를 모아라! 모두 정화하라!

수정 이유: 해당 문구 ID의 현재 대사로 수정

## 621. loc_zealot_female_b__conversation_plague_ogryn_weakpoint_02_02

유형: 기존 수정

**현재 영문**

God-Emperor guide our blows upon the creature’s vile head.

**기존 기본 번역**

신-황제 폐하께서 저 괴물의 머리를 쏘라고 하셨다.

**수정 기본 번역**

신-황제 폐하시여, 저 괴물의 사악한 머리에 저희의 일격을 인도하소서.

수정 이유: 기도를 황제의 사격 명령으로 옮긴 오류 수정

## 622. loc_zealot_female_b__conversation_tech_priest_one_a_01

유형: 기존 수정

**현재 영문**

Do ye not find that Tech-Priest ... disconcerting?

**기존 기본 번역**

테크프리스트 연결이 끊긴 걸 몰랐나?

**수정 기본 번역**

저 테크프리스트가... 불안하게 느껴지지 않나?

수정 이유: disconcerting을 연결 끊김으로 옮긴 오류 수정

## 623. loc_zealot_female_b__event_kill_target_damaged_04

유형: 기존 수정

**현재 영문**

Emperor's mercy, the heretic still stands!

**기존 기본 번역**

황제 폐하의 자비인가, 이교도는 아직 살아있다!

**수정 기본 번역**

황제 폐하시여, 이교도가 아직도 버티고 있다!

수정 이유: 감탄을 적에 대한 자비의 원인으로 옮긴 오류 수정

## 624. loc_zealot_female_b__look_at_healthstation_03

유형: 기존 수정

**현재 영문**

See yon med station?

**기존 기본 번역**

메디카에 스테이션에서 만날까?

**수정 기본 번역**

저 메디카에 스테이션이 보이나?

수정 이유: See yon을 만남 약속으로 옮긴 오류 수정

## 625. loc_zealot_female_b__lore_hadron_two_a_02

유형: 기존 수정

**현재 영문**

I'd be not surprised to learn the Tech-Priest is centuries old, judging by appearances.

**기존 기본 번역**

외관으로만 판단한다면 테크프리스트가 한 세기는 살았다고 해도 놀랍지 않을 거야.

**수정 기본 번역**

외관으로만 판단한다면 테크프리스트가 수 세기는 살았다고 해도 놀랍지 않을 거야.

수정 이유: 복수형 centuries 반영

## 626. loc_zealot_female_b__lore_hadron_two_a_04

유형: 기존 수정

**현재 영문**

The Tech-Priest seems blessed with great age.

**기존 기본 번역**

테크프리스트는 위대한 시대의 축복을 받은 것처럼 보인다.

**수정 기본 번역**

테크프리스트는 장수의 축복을 받은 듯하군.

수정 이유: great age를 위대한 시대로 옮긴 오류 수정

## 627. loc_zealot_female_b__lore_space_marines_four_b_01

유형: 기존 수정

**현재 영문**

I've heard it called the "Forge of Strength", possessed by all the Adeptus Astartes.

**기존 기본 번역**

모든 아뎁투스 아스타르테스가 '힘의 제련'을 한다고 하더군.

**수정 기본 번역**

아뎁투스 아스타르테스는 모두 "힘의 제련소"라는 것을 지니고 있다고 들었다.

수정 이유: possessed by를 행동 수행으로 옮긴 오류 수정

## 628. loc_zealot_female_b__lore_space_marines_two_a_01

유형: 기존 수정

**현재 영문**

There be much wisdom in Guilliman's Codex Astartes, even for mere mortals.

**기존 기본 번역**

길리먼의 코덱스 아스타르테스에는 죄인도 읽을 수 있는 많은 배움이 담겨 있다.

**수정 기본 번역**

길리먼의 코덱스 아스타르테스에는 평범한 필멸자에게도 도움이 될 지혜가 가득하다.

수정 이유: mere mortals와 wisdom의 뜻 복원

## 629. loc_zealot_female_b__lore_the_emperor_two_c_01

유형: 기존 수정

**현재 영문**

Praise the Emperor whose sacrifice is life as ours is death.

**기존 기본 번역**

죽음으로 자신을 희생하셔서 우리에게 삶을 주신 그분을 찬양하라.

**수정 기본 번역**

황제 폐하를 찬양하라. 우리의 희생이 죽음이라면, 그분의 희생은 삶이다.

수정 이유: 황제와 추종자의 희생을 대비하는 뜻 복원

## 630. loc_zealot_female_b__mission_cargo_end_event_conversation_two_c_02

유형: 기존 수정

**현재 영문**

If they be tardy, there'll be no heretics left for 'em to smite!

**기존 기본 번역**

지각하게 되면, 이교도들을 처단할 수 없게 된다!

**수정 기본 번역**

늑장을 부리면 저들이 처단할 이교도는 하나도 안 남을 것이다!

수정 이유: 지원팀이 늦을 때 처치 몫이 없어진다는 의미 복원

## 631. loc_zealot_female_b__mission_cargo_start_banter_a_02

유형: 기존 수정

**현재 영문**

So these lazy slugs stand watch while we do the God-Emperor's work?

**기존 기본 번역**

우리가 신-황제 폐하의 과업을 수행하는 동안 저 게으름뱅이들은 우릴 보기만 한다고?

**수정 기본 번역**

우리가 신-황제 폐하의 과업을 수행하는 동안 저 게으름뱅이들은 경계만 서는 건가?

수정 이유: stand watch를 구경으로 옮긴 오류 수정

## 632. loc_zealot_female_b__mission_complex_elevator_conversation_3_c_01

유형: 기존 수정

**현재 영문**

Aye, worthy enough. Wars turn on less.

**기존 기본 번역**

아, 충분히 가치가 있었다. 전쟁이 덜 발생하겠군.

**수정 기본 번역**

아, 충분히 가치가 있지. 전쟁의 향방은 그보다 사소한 일에도 바뀌니.

수정 이유: wars turn on less 관용 표현 수정

## 633. loc_zealot_female_b__mission_propaganda_cultist_town_02

유형: 기존 수정

**현재 영문**

These apostates scrape a meagre living outside the God-Emperor's light.

**기존 기본 번역**

이 변절자는 신-황제 폐하의 빛 속에서 하찮은 삶을 겨우 살았군.

**수정 기본 번역**

이 변절자는 신-황제 폐하의 빛 바깥에서 하찮은 삶을 겨우 살았군.

수정 이유: outside의 방향을 반대로 옮긴 오류 수정

## 634. loc_zealot_female_b__mission_propaganda_short_elevator_conversation_two_a_02

유형: 기존 수정

**현재 영문**

Dig deep, kindred. The road to redemption be long. And tiresome.

**기존 기본 번역**

파고들어라, 동지. 회개의 길은 멀고도 험하지.

**수정 기본 번역**

힘을 내라, 동지. 구원의 길은 멀고도 고되지.

수정 이유: dig deep 관용 표현 수정

## 635. loc_zealot_female_b__mission_rails_district_gate_02

유형: 기존 수정

**현재 영문**

No way through. The district gate be shut fast.

**기존 기본 번역**

통과할 수 없다. 지역 관문이 빨리 닫혔군.

**수정 기본 번역**

통과할 수 없다. 지역 관문이 굳게 닫혔군.

수정 이유: shut fast를 빠른 속도로 옮긴 오류 수정

## 636. loc_zealot_female_b__mission_rails_start_banter_a_02

유형: 기존 수정

**현재 영문**

Scuttling about in the dark like heretics...

**기존 기본 번역**

이교도처럼 어둠 속을 해매야하는 건가...

**수정 기본 번역**

이교도처럼 어둠 속을 헤매야 하는 건가...

수정 이유: 맞춤법 수정

## 637. loc_zealot_female_b__mission_scavenge_underhalls_02

유형: 기존 수정

**현재 영문**

Stay alert! Evil festers in this maze.

**기존 기본 번역**

경계를 늦추지 마. 이 미로에서 악의 축제가 열리고 있다.

**수정 기본 번역**

경계를 늦추지 마라! 이 미로에서는 악이 곪아가고 있다.

수정 이유: festers를 축제로 옮긴 오류 수정

## 638. loc_zealot_female_b__mission_station_start_banter_a_02

유형: 기존 수정

**현재 영문**

Look at them. Martyrs in the making. It fair makes the heart sing!

**기존 기본 번역**

저들을 봐라. 순교자들이 탄생하는 중이지. 공정한 마음이 노래하게 만드는군!

**수정 기본 번역**

저들을 봐라. 순교자가 되어가고 있지. 절로 가슴이 노래하는군!

수정 이유: 강조 부사 fair를 공정한 마음으로 옮긴 오류 수정

## 639. loc_zealot_female_b__mission_strain_inert_tanks_01

유형: 기존 수정

**현재 영문**

There be nought of import here... Emperor guide our search.

**기존 기본 번역**

여긴 수입품도 없고... 황제 폐하께서 우리의 수색을 인도해주신다.

**수정 기본 번역**

여기엔 중요한 것이 없군... 황제 폐하시여, 우리의 수색을 인도하소서.

수정 이유: of import를 수입품으로 옮긴 오류 수정

## 640. loc_zealot_female_b__response_for_enemy_kill_monster_10

유형: 기존 수정

**현재 영문**

Heresy carries a price. Today we collected on the debt.

**기존 기본 번역**

배교에는 대가가 따른다. 오늘 우리는 빚을 갚은 거다.

**수정 기본 번역**

배교에는 대가가 따른다. 오늘 우리는 그 빚을 받아낸 것이다.

수정 이유: 채무 회수를 상환으로 옮긴 오류 수정

## 641. loc_zealot_female_b__response_for_zealot_enemy_kill_monster_02

유형: 기존 수정

**현재 영문**

Killing in fine faith, Guardian!

**기존 기본 번역**

선의의 살인이로다, 가디언!

**수정 기본 번역**

훌륭한 믿음으로 처단했도다, 가디언!

수정 이유: faith를 선의로 옮긴 오류 수정

## 642. loc_zealot_female_b__seen_enemy_berserker_05

유형: 기존 수정

**현재 영문**

A Rager to chastise!

**기존 기본 번역**

징벌한 레이저로군!

**수정 기본 번역**

징벌할 레이저로군!

수정 이유: 발견 시 아직 처치하지 않은 대상을 완료형으로 옮긴 오류 수정

## 643. loc_zealot_female_b__seen_enemy_grenadier_08

유형: 기존 수정

**현재 영문**

Bomber! Kill the blaggard!

**기존 기본 번역**

보머다! 블랙가드를 죽여라!

**수정 기본 번역**

보머다! 저 악당을 죽여라!

수정 이유: blackguard를 고유명사로 옮긴 오류 수정

## 644. loc_zealot_female_b__seen_enemy_tox_flamer_04

유형: 기존 수정

**현재 영문**

Kindred! Heretic fire abounds!

**기존 기본 번역**

동지! 이교도에겐 불이 많다!

**수정 기본 번역**

동지! 사방에 이교도의 불길이 있다!

수정 이유: 화염 위험 경고를 단순 보유량 표현으로 옮긴 오류 수정

## 645. loc_zealot_female_b__zealot_seen_killstreak_zealot_05

유형: 기존 수정

**현재 영문**

See what ruin a Guardian wreaks!

**기존 기본 번역**

그대의 영광은 정말 끝이 없군, 가디언!

**수정 기본 번역**

가디언이 적들을 어떻게 쓸어버리는지 보아라!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 646. loc_zealot_female_b__zealot_start_revive_zealot_06

유형: 기존 수정

**현재 영문**

Let the God-Emperor's rage fill ye, and immolate them!

**기존 기본 번역**

신-황제 폐하의 분노가 그대를 집어 삼키게 해라!

**수정 기본 번역**

신-황제 폐하의 분노로 그대를 채워라. 그리고 놈들을 불태워라!

수정 이유: 불태우는 대상이 아군으로 뒤바뀐 오류 수정

## 647. loc_zealot_female_c__lore_daemons_four_c_01

유형: 기존 수정

**현재 영문**

The Eye of Terror was the doom of Cadia. If the Empire's finest can fall, what hope for us?

**기존 기본 번역**

아이 오브 테러는 카디아의 멸망이다. 만약 황제 폐하의 경관들도 타락하게 된다면, 우리에게 무슨 희망이 있는가?

**수정 기본 번역**

아이 오브 테러가 카디아를 파멸시켰다. 제국의 최정예조차 무너진다면, 우리에게 무슨 희망이 있겠는가?

수정 이유: finest를 경관으로, fall을 타락으로 옮긴 오류 수정

## 648. loc_zealot_female_c__lore_the_emperor_two_b_01

유형: 기존 수정

**현재 영문**

An act of surpassing love, to immure himself in the Golden Throne for all time.

**기존 기본 번역**

영원히 황금 옥좌에 몸을 담그는 행위, 그것이 바로 사랑을 뛰어넘는 예술이지.

**수정 기본 번역**

영원히 황금 옥좌에 자신을 가두시다니, 그보다 큰 사랑은 없을 것이다.

수정 이유: act와 immure를 예술과 담금으로 옮긴 오류 수정

## 649. loc_zealot_female_c__lore_the_warp_four_b_02

유형: 기존 수정

**현재 영문**

Great is the mind too small for doubt. These matters are best left unconsidered.

**기존 기본 번역**

정신은 너무나도 위대하여 의심을 품을 여지도 없다. 이 문제는 고려하지 않는 것이 최선이지.

**수정 기본 번역**

의심조차 품지 못할 만큼 작은 정신이야말로 위대하다. 이런 문제는 생각하지 않는 편이 최선이지.

수정 이유: too small for doubt의 역설을 반대로 옮긴 오류 수정

## 650. loc_zealot_female_c__mission_cargo_end_event_conversation_three_a_01

유형: 기존 수정

**현재 영문**

How did a Tech-Priest such as you find your way to an inquisitorial retinue?

**기존 기본 번역**

그대 같은 테크프리스트가 어떻게 조사 수행관의 길을 찾은건가?

**수정 기본 번역**

그대 같은 테크프리스트가 어떻게 이단심문관의 수행단에 들어왔는가?

수정 이유: inquisitorial retinue를 조사 수행관이라는 직책으로 옮긴 오류 수정

## 651. loc_zealot_female_c__mission_propaganda_elevator_conversation_two_c_01

유형: 기존 수정

**현재 영문**

To the Warp with it.

**기존 기본 번역**

워프로 이동하지.

**수정 기본 번역**

워프에나 처박혀라.

수정 이유: To the Warp with it을 이동 지시로 옮긴 오류 수정

## 652. loc_zealot_female_c__mission_rails_end_event_conversation_two_c_01

유형: 기존 수정

**현재 영문**

Huh. That's gratitude for you.

**기존 기본 번역**

그게 그대가 받을 감사 인사다.

**수정 기본 번역**

허. 고마움에 대한 보답이 고작 이거로군.

수정 이유: that's gratitude for you의 빈정거림 복원

## 653. loc_zealot_female_c__mission_station_mid_event_conversation_one_c_02

유형: 기존 수정

**현재 영문**

Very well. But I cannot promise to do it with any skill.

**기존 기본 번역**

잘했군. 하지만 어떤 기술로도 해낼 수 있다고 장담할 수는 없다.

**수정 기본 번역**

좋다. 하지만 내가 능숙하게 해낼 거라고는 장담할 수 없다.

수정 이유: 화자의 숙련도 문제를 기술의 가능 여부로 옮긴 오류 수정

## 654. loc_zealot_female_c__mission_station_start_banter_a_01

유형: 기존 수정

**현재 영문**

These soldiers could use a rousing sermon to rekindle their faith.

**기존 기본 번역**

이 병사들은 신앙에 다시 불을 붙일 수 있는 감동적인 설교를 들을 수 있겠군.

**수정 기본 번역**

이 병사들에게는 믿음에 다시 불을 붙여줄 힘찬 설교가 필요하겠군.

수정 이유: could use를 단순 가능 표현으로 옮긴 오류 수정

## 655. loc_zealot_female_c__mission_stockpile_cartel_habs_02

유형: 기존 수정

**현재 영문**

Such misery in this place. Who can be surprised the enemy has made it their own?

**기존 기본 번역**

이 곳은 정말 비참하군. 적들이 자기들 것으로 만들었다니 누가 놀라지 않을 수 있겠나?

**수정 기본 번역**

이곳은 참 비참하군. 적들이 이곳을 차지한들 놀랄 일이겠는가?

수정 이유: 놀랍지 않다는 반문을 반대로 옮긴 오류 수정

## 656. loc_zealot_male_a__ability_maniac_03

유형: 기존 수정

**현재 영문**

Praise the Master!

**기존 기본 번역**

주인님께서 내게 힘을 주신다!

**수정 기본 번역**

주인님을 찬양하라!

수정 이유: 해당 문구 ID의 현재 대사로 수정

## 657. loc_zealot_male_a__almost_there_04

유형: 기존 수정

**현재 영문**

Almost there!

**기존 기본 번역**

주인님을 찬양하라, 우리의 말이 기다린다!

**수정 기본 번역**

거의 다 왔다!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 658. loc_zealot_male_a__almost_there_05

유형: 기존 수정

**현재 영문**

Don't give up now, kindred!

**기존 기본 번역**

주인님을 찬양하라, 승리를 거두고 돌아왔도다!

**수정 기본 번역**

이제 와서 포기하지 마라, 동지여!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 659. loc_zealot_male_a__com_wheel_vo_for_the_emperor_01

유형: 기존 수정

**현재 영문**

For the Master of Mankind!

**기존 기본 번역**

주인님께서 우릴 보신다!

**수정 기본 번역**

인류의 주인님을 위하여!

수정 이유: 현재 원문과 다른 대사 수정

## 660. loc_zealot_male_a__conversation_combat_chaos_spawn_chew_c_01

유형: 기존 수정

**현재 영문**

Unhand the sinner, creature!

**기존 기본 번역**

인류의 주인님이시여! 사방에 피로군!

**수정 기본 번역**

그 죄인을 놓아라, 괴물아!

수정 이유: 현재 원문과 다른 대사 수정

## 661. loc_zealot_male_a__conversation_plague_ogryn_weakpoint_03_02

유형: 기존 수정

**현재 영문**

I approve this holy course!

**기존 기본 번역**

이 성스러운 과정에 자원하겠다!

**수정 기본 번역**

이 성스러운 방침에 찬성한다!

수정 이유: approve를 자원으로 옮긴 오류 수정

## 662. loc_zealot_male_a__hacking_auspex_mutter_a_03

유형: 기존 수정

**현재 영문**

Confound this thing ...

**기존 기본 번역**

이거 헷갈리잖아...

**수정 기본 번역**

빌어먹을 녀석...

수정 이유: confound의 저주 표현을 혼란으로 옮긴 오류 수정

## 663. loc_zealot_male_a__head_shot_04

유형: 기존 수정

**현재 영문**

The Master of Mankind guide thy aim!

**기존 기본 번역**

인류의 주인님께서 그대의 목표를 인도하신다!

**수정 기본 번역**

인류의 주인님께서 그대의 조준를 인도하신다!

수정 이유: aim 용어 수정

## 664. loc_zealot_male_a__heard_horde_vector_02

유형: 기존 수정

**현재 영문**

They come in search of cleansing wrath. They shall find it.

**기존 기본 번역**

녀석들은 분노를 씻기 위해 오는 것이다. 그들이 찾아낼 거다.

**수정 기본 번역**

놈들은 정화의 분노를 찾아오는 것이다. 원하는 대로 받게 될 것이다.

수정 이유: cleansing wrath의 수식 관계 수정

## 665. loc_zealot_male_a__look_at_healthstation_07

유형: 기존 수정

**현재 영문**

Respite, and well-earned.

**기존 기본 번역**

휴식을 취해야, 결과도 좋아진다.

**수정 기본 번역**

휴식이로군. 충분히 누릴 자격이 있지.

수정 이유: well-earned respite의 뜻 복원

## 666. loc_zealot_male_a__lore_daemons_four_b_02

유형: 기존 수정

**현재 영문**

Tis the Ocularis Terribus... A great rent in the Immaterium, in which lurketh heresy and madness.

**기존 기본 번역**

오큘라리스 테리부스... 이마테리움에 있는 이 거대한 장소에는 배교와 광기가 판을 치고 있다.

**수정 기본 번역**

오큘라리스 테리부스... 이마테리움의 거대한 균열이며, 이단과 광기가 도사리는 곳이지.

수정 이유: rent를 장소로만 옮겨 빠진 균열 의미 복원

## 667. loc_zealot_male_a__lore_space_marines_four_c_02

유형: 기존 수정

**현재 영문**

The Adeptus Astartes are as close to the Master's image as can be. Their nature is inscrutable to mere mortals.

**기존 기본 번역**

아뎁투스 아스타르테스는 주인님의 모습을 최대한 본땄다. 이들의 성정 역시 죄인에게는 불가해한 것이지.

**수정 기본 번역**

아뎁투스 아스타르테스는 주인님의 모습을 최대한 본땄다. 이들의 성정 역시 필멸자에게는 불가해한 것이지.

수정 이유: mere mortals를 죄인으로 옮긴 오류 수정

## 668. loc_zealot_male_a__lore_the_emperor_one_c_01

유형: 기존 수정

**현재 영문**

Only the Senatorum Imperialis can interpret the Master's will from the blessed signs he leaveth.

**기존 기본 번역**

테라의 하이 로드만이 주인님께서 남기신 신성한 징후를 통해 그 의지를 해석해낼 수 있다.

**수정 기본 번역**

세나토룸 임페리얼리스만이 주인님께서 남기신 신성한 징후를 통해 그 의지를 해석할 수 있다.

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 669. loc_zealot_male_a__lore_the_emperor_three_c_01

유형: 기존 수정

**현재 영문**

And what of the great choir of the Astronomican? Proof that even the most wretched can attain glory in the Master's name!

**기존 기본 번역**

그렇다면 아스트로노미칸의 위업은? 가장 더러워진 자들도 주인님의 이름으로 영광을 얻을 수 있는 것이다!

**수정 기본 번역**

그렇다면 아스트로노미칸의 위대한 성가대는? 가장 비천한 자도 주인님의 이름으로 영광을 얻을 수 있다는 증거다!

수정 이유: choir를 위업으로 옮긴 오류 수정

## 670. loc_zealot_male_a__lore_the_warp_three_c_01

유형: 기존 수정

**현재 영문**

I hath heard tales of vessels lost for millennia within the Immaterium, their crews put to the sword as surety against corruption.

**기존 기본 번역**

이마테리움에서 수만 년 전 사라진 함선들의 이야기를 들었다. 그 함선에 탄 자들은 타락을 막기 위해 모두 죽였다고 하더군.

**수정 기본 번역**

이마테리움에서 수천 년 동안 실종됐던 함선들의 이야기를 들었다. 오염을 막으려고 승조원들을 모두 처형했다더군.

수정 이유: millennia의 규모와 실종 기간 수정

## 671. loc_zealot_male_a__lore_zola_one_c_01

유형: 기존 수정

**현재 영문**

Unlike you imbeciles, Sister Zola alloweth not distraction to cloud her mind.

**기존 기본 번역**

그런 발언은 옥좌의 충실한 종에 대한 모독이다.

**수정 기본 번역**

그대들 같은 얼간이와 달리, 졸라 자매는 잡념이 마음을 흐리게 두지 않는다.

수정 이유: 현재 원문과 다른 대사 수정

## 672. loc_zealot_male_a__lore_zola_three_b_01

유형: 기존 수정

**현재 영문**

Sister Zola keepeth the gates of her mind locked and barred - mayhap tis wise 'gainst the likes of thee!

**기존 기본 번역**

졸라는 아군으로부터 비밀을 지킬 수 있을지 모르겠지만, 인류의 주인님은 모든 걸 보고 계신다.

**수정 기본 번역**

졸라 자매는 마음의 문을 단단히 잠가 두었지. 그대 같은 자들을 상대하려면 현명한 일일지도 모르겠군!

수정 이유: 현재 원문과 다른 대사 수정

## 673. loc_zealot_male_a__lore_zola_three_c_02

유형: 기존 수정

**현재 영문**

She hath thus far been nought but a dependable servant of the Master. Let that be an end to it.

**기존 기본 번역**

그 여자는 오랫동안 주인님을 섬기는 충실한 종이었다. 그 끝도 그렇기를 빌자.

**수정 기본 번역**

그녀는 지금껏 주인님의 믿음직한 종이었다. 그걸로 이 이야기는 끝내도록 하지.

수정 이유: let that be an end to it 관용 표현 수정

## 674. loc_zealot_male_a__mission_cartel_elevator_conversation_two_line_three_01

유형: 기존 수정

**현재 영문**

Thou hast no secrets from the Master of Mankind.

**기존 기본 번역**

인류의 주인님께선 비밀은 없으시다.

**수정 기본 번역**

인류의 주인님께 그대의 비밀을 숨길 수는 없다.

수정 이유: 주인님에게 비밀이 없다는 문장으로 주체가 바뀐 오류 수정

## 675. loc_zealot_male_a__mission_cooling_elevator_conversation_one_line_one_02

유형: 기존 수정

**현재 영문**

A tragedy to see a holy forge so slighted. Can its harms be undone?

**기존 기본 번역**

거룩한 단조가 그렇게 무시당하다니 참 비극이군. 그 해악은 돌이킬 수 있나?

**수정 기본 번역**

신성한 단조장이 이토록 훼손되다니 비극이군. 이 피해를 되돌릴 수 있나?

수정 이유: forge가 시설임을 반영

## 676. loc_zealot_male_a__mission_cooling_overseer_office_02

유형: 기존 수정

**현재 영문**

Feel the heat of thy  labours, sinners! It is as naught to the fires of damnation!

**기존 기본 번역**

노동의 열기를 느껴라, 죄인들이여! 이건 저주의 불길에 불과하다!

**수정 기본 번역**

노동의 열기를 느껴라, 죄인들이여! 이것은 저주의 불길에 비하면 아무것도 아니다!

수정 이유: as naught to 비교 구문 누락 복원

## 677. loc_zealot_male_a__mission_forge_elevator_conversation_one_a_01

유형: 기존 수정

**현재 영문**

All of the Master's battle tanks are sacred. Why single out these few?

**기존 기본 번역**

주인님의 전차는 모두 신성하다. 그런데 이렇게 소수만 여기로 보낸 이유는 무엇이지?

**수정 기본 번역**

주인님의 전차는 모두 신성하다. 그런데 왜 이 몇 대만 특별히 고르는 것이지?

수정 이유: single out을 파견으로 옮긴 오류 수정

## 678. loc_zealot_male_a__mission_forge_lifeless_01

유형: 기존 수정

**현재 영문**

No one toils here now. Wouldst that we all meet our ends in the Master's service.

**기존 기본 번역**

여기선 모두 고통 받지 않는군. 주인님을 섬기는 모든 종들의 결말이지.

**수정 기본 번역**

이제 이곳에서 일하는 자는 아무도 없군. 우리 모두 주인님을 섬기다 최후를 맞기를.

수정 이유: toil을 고통으로 옮기고 소망을 사실로 바꾼 오류 수정

## 679. loc_zealot_male_a__mission_hack_01

유형: 기존 수정

**현재 영문**

I understandeth little about machines and servitors, so I shall look to thy knowledge should something go astray.

**기존 기본 번역**

난 기계와 서비터에 대해 아는 게 별로 없으니, 뭔가 잘못되지 않도록 주의해 보겠다.

**수정 기본 번역**

난 기계와 서비터를 잘 모르니, 뭔가 잘못되면 그대의 지식에 의지하겠다.

수정 이유: look to thy knowledge의 의존 대상 복원

## 680. loc_zealot_male_a__mission_propaganda_short_elevator_conversation_three_a_01

유형: 기존 수정

**현재 영문**

Better up here, closer to the Master's light, than down there in the depths of depravity.

**기존 기본 번역**

주인님의 빛에 보다, 가까이 갔다가, 타락의 가장 깊은 곳으로 떨어지다니.

**수정 기본 번역**

타락의 깊은 구렁 저 아래보다는, 주인님의 빛에 가까운 이 위가 낫지.

수정 이유: 위와 아래의 비교를 추락 사건으로 옮긴 오류 수정

## 681. loc_zealot_male_a__mission_raid_trapped_b_03

유형: 기존 수정

**현재 영문**

The vox is dead. Art we to follow?

**기존 기본 번역**

복스는 먹통이야. 기술을 살펴봐야 하나?

**수정 기본 번역**

복스가 죽었군. 다음은 우리 차례인가?

수정 이유: 고어 art를 기술로 혼동한 오류 수정

## 682. loc_zealot_male_a__mission_retrieve_02

유형: 기존 수정

**현재 영문**

The Master of Mankind didst not send me into the world to drag things from place to place!

**기존 기본 번역**

인류의 주인님께서는 날 이리저리 끌고 다니라고 세상에 보내신 게 아니다!

**수정 기본 번역**

인류의 주인님께서 나를 세상에 보내신 건 물건이나 나르라는 뜻이 아니다!

수정 이유: drag things의 목적어를 화자 자신으로 옮긴 오류 수정

## 683. loc_zealot_male_a__mission_scavenge_elevator_conversation_one_line_three_01

유형: 기존 수정

**현재 영문**

The Master of Mankind's works shall endure ten thousand lifetimes, so long as our faith remains true.

**기존 기본 번역**

인류의 주인님의 업적은 우리의 믿음이 진실하게 남아있는 만 년동안 지속될 것이다.

**수정 기본 번역**

우리의 믿음이 진실한 한, 인류의 주인님의 위업은 만 번의 생애가 지나도록 이어질 것이다.

수정 이유: ten thousand lifetimes를 만 년으로 옮긴 오류 수정

## 684. loc_zealot_male_a__mission_scavenge_elevator_conversation_three_line_one_02

유형: 기존 수정

**현재 영문**

Eradicating unholy plague from the Master of Mankind's realm is a most fitting task for us.

**기존 기본 번역**

인류의 주인님의 영역에서 신성불가침한 역병을 퇴치하는 것은 우리에게 가장 잘 맞는 일이지.

**수정 기본 번역**

인류의 주인님의 영역에서 불경한 역병을 퇴치하는 것은 우리에게 가장 잘 맞는 일이지.

수정 이유: unholy를 반대 의미로 옮긴 오류 수정

## 685. loc_zealot_male_a__mission_scavenge_underhalls_01

유형: 기존 수정

**현재 영문**

This ruin is an infested, heretic-riddled warren! Wouldst that we could purge it with flame!

**기존 기본 번역**

이 폐허는 이교도들이 득실거리는 워렌이다! 화염으로 소탕해버릴 수 있으면 좋겠군!

**수정 기본 번역**

이 폐허는 이교도들이 득실거리는 소굴이다! 화염으로 소탕해버릴 수 있으면 좋겠군!

수정 이유: warren을 고유명사로 옮긴 오류 수정

## 686. loc_zealot_male_a__mission_station_station_approach_02

유형: 기존 수정

**현재 영문**

There lieth Chasm Terminus. A grand edifice in need of purification!

**기존 기본 번역**

저기에 캐즘 터미누스가 있다. 정화를 위한 위대한 조형물이지!

**수정 기본 번역**

저기에 캐즘 터미누스가 있다. 정화가 필요한 웅장한 건축물이지!

수정 이유: 정화가 필요한 대상을 정화용 시설로 옮긴 오류 수정

## 687. loc_zealot_male_a__mission_stockpile_main_access_02

유형: 기존 수정

**현재 영문**

Content not with turning from the Master's light, the heretics destroy all they touch.

**기존 기본 번역**

주인님의 빛을 외면하지 말라, 이교도들이 그대의 모든 것을 파괴하리라.

**수정 기본 번역**

주인님의 빛을 등지는 것만으로도 모자라, 이교도들은 손대는 모든 것을 파괴하는군.

수정 이유: content not with의 문장 구조와 주체 복원

## 688. loc_zealot_male_a__mission_stockpile_ruined_hab_01

유형: 기존 수정

**현재 영문**

This hab block is as rotten as the black hearts of its denizens.

**기존 기본 번역**

이 거주 구역은 여기 사는 놈들의 뱃속처럼 시커멓군.

**수정 기본 번역**

이 거주 구역은 주민들의 시커먼 마음만큼이나 썩었군.

수정 이유: rotten의 의미와 비유 대상 복원

## 689. loc_zealot_male_a__mission_strain_inert_tanks_01

유형: 기존 수정

**현재 영문**

These tanks are devoid of heretical contagion. Delve deeper, imbeciles!

**기존 기본 번역**

이 탱크는 이교도의 병원균에 오염됐다. 더 깊이 들어가라, 어리석은 자들아!

**수정 기본 번역**

이 탱크들에는 이단의 병원균이 없다. 더 깊이 들어가라, 어리석은 자들아!

수정 이유: devoid of를 감염됨으로 반대로 옮긴 오류 수정

## 690. loc_zealot_male_a__mission_strain_mid_event_conversation_three_a_01

유형: 기존 수정

**현재 영문**

Exposure to this pathogen is only a worry to the impure of thought. Bad luck, imbeciles!

**기존 기본 번역**

병원체 감염을 걱정하는 건 그저 머릿속에 오염을 더할 뿐이다. 불길한 소리하지 마라, 어리석은 자들!

**수정 기본 번역**

이 병원체에 노출되어 걱정할 자는 생각이 불순한 자들뿐이다. 유감이군, 어리석은 자들아!

수정 이유: 감염 우려의 대상과 조롱을 다른 의미로 옮긴 오류 수정

## 691. loc_zealot_male_a__mission_strain_mid_event_conversation_three_c_02

유형: 기존 수정

**현재 영문**

Thine flesh shall endure so long as thine souls are righteous!

**기존 기본 번역**

그대의 영혼이 정의로운 한, 그대의 육체도 정의롭기를!

**수정 기본 번역**

그대들의 영혼이 의로운 한 육신도 버틸 것이다!

수정 이유: endure의 생존 의미 복원

## 692. loc_zealot_male_a__response_for_zealot_enemy_kill_monster_04

유형: 기존 수정

**현재 영문**

The Master of Mankind is served well this day!

**기존 기본 번역**

인류의 주인님께서 우릴 도우셨도다!

**수정 기본 번역**

오늘 우리는 인류의 주인님을 훌륭히 섬겼도다!

수정 이유: 섬김을 받는 대상과 돕는 주체가 뒤바뀐 오류 수정

## 693. loc_zealot_male_a__surrounded_01

유형: 기존 수정

**현재 영문**

The heretics are numberless!

**기존 기본 번역**

우린 인류의 주인님을 위해 싸운다!

**수정 기본 번역**

이교도들이 끝도 없군!

수정 이유: 현재 원문과 다른 대사 수정

## 694. loc_zealot_male_a__zealot_seen_killstreak_ogryn_01

유형: 기존 수정

**현재 영문**

So the Slab can serve holy cause!

**기존 기본 번역**

그래! 그래! 황제 폐하의 분노로 몸을 채워라, 오그린!

**수정 기본 번역**

그러니 저 덩치도 성스러운 대의를 섬길 수 있군!

수정 이유: 현재 원문과 다른 대사 수정

## 695. loc_zealot_male_b__ability_banisher_05

유형: 기존 수정

**현재 영문**

Let wrath gather! Let all be cleansed!

**기존 기본 번역**

나의 분노로 너희들을 정화하리라, 가여운 자들이여!

**수정 기본 번역**

분노를 모아라! 모두 정화하라!

수정 이유: 해당 문구 ID의 현재 대사로 수정

## 696. loc_zealot_male_b__conversation_plague_ogryn_weakpoint_02_02

유형: 기존 수정

**현재 영문**

God-Emperor guide our blows upon the creature’s vile head.

**기존 기본 번역**

신-황제 폐하께서 저 괴물의 머리를 쏘라고 하셨다.

**수정 기본 번역**

신-황제 폐하시여, 저 괴물의 사악한 머리에 저희의 일격을 인도하소서.

수정 이유: 기도를 황제의 사격 명령으로 옮긴 오류 수정

## 697. loc_zealot_male_b__conversation_tech_priest_one_a_01

유형: 기존 수정

**현재 영문**

Do ye not find that Tech-Priest ... disconcerting?

**기존 기본 번역**

테크프리스트 연결이 끊긴 걸 몰랐나?

**수정 기본 번역**

저 테크프리스트가... 불안하게 느껴지지 않나?

수정 이유: disconcerting을 연결 끊김으로 옮긴 오류 수정

## 698. loc_zealot_male_b__event_kill_target_damaged_04

유형: 기존 수정

**현재 영문**

Emperor's mercy, the heretic still stands!

**기존 기본 번역**

황제 폐하의 자비인가, 이교도는 아직 살아있다!

**수정 기본 번역**

황제 폐하시여, 이교도가 아직도 버티고 있다!

수정 이유: 감탄을 적에 대한 자비의 원인으로 옮긴 오류 수정

## 699. loc_zealot_male_b__heard_enemy_chaos_spawn_01

유형: 기존 수정

**현재 영문**

Rotbag!

**기존 기본 번역**

살덩이다!

**수정 기본 번역**

부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 700. loc_zealot_male_b__heard_enemy_chaos_spawn_02

유형: 기존 수정

**현재 영문**

Vile Rotbag!

**기존 기본 번역**

사악한 살덩이다!

**수정 기본 번역**

사악한 부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 701. loc_zealot_male_b__heard_enemy_chaos_spawn_04

유형: 기존 수정

**현재 영문**

Rotbag! Destroy it!

**기존 기본 번역**

살덩이다! 없애버려!

**수정 기본 번역**

부패덩어리다! 없애버려!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 702. loc_zealot_male_b__heard_enemy_chaos_spawn_05

유형: 기존 수정

**현재 영문**

Rotbag ahoy!

**기존 기본 번역**

살덩이다!

**수정 기본 번역**

부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 703. loc_zealot_male_b__heard_enemy_chaos_spawn_06

유형: 기존 수정

**현재 영문**

It's a Rotbag!

**기존 기본 번역**

살덩이다!

**수정 기본 번역**

부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 704. loc_zealot_male_b__heard_enemy_chaos_spawn_07

유형: 기존 수정

**현재 영문**

D'ye see the Rotbag?

**기존 기본 번역**

살덩이가 보이는가?

**수정 기본 번역**

부패덩어리가 보이는가?

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 705. loc_zealot_male_b__heard_enemy_chaos_spawn_08

유형: 기존 수정

**현재 영문**

Rotbag, my kindred!

**기존 기본 번역**

살덩이다, 내 동지여!

**수정 기본 번역**

부패덩어리다, 내 동지여!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 706. loc_zealot_male_b__heard_enemy_chaos_spawn_09

유형: 기존 수정

**현재 영문**

By the God-Emperor! A Rotbag!

**기존 기본 번역**

신-황제 폐하시여! 살덩이다!

**수정 기본 번역**

신-황제 폐하시여! 부패덩어리다!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 707. loc_zealot_male_b__heard_enemy_chaos_spawn_10

유형: 기존 수정

**현재 영문**

Kill the Rotbag!

**기존 기본 번역**

살덩이를 죽여라!

**수정 기본 번역**

부패덩어리를 죽여라!

수정 이유: 남녀 음성별 Fleshbag/Rotbag 원문 차이를 ID별로 반영

## 708. loc_zealot_male_b__look_at_healthstation_03

유형: 기존 수정

**현재 영문**

See yon med station?

**기존 기본 번역**

메디카에 스테이션에서 만날까?

**수정 기본 번역**

저 메디카에 스테이션이 보이나?

수정 이유: See yon을 만남 약속로 옮긴 오류 수정

## 709. loc_zealot_male_b__lore_hadron_two_a_02

유형: 기존 수정

**현재 영문**

I'd be not surprised to learn the Tech-Priest is centuries old, judging by appearances.

**기존 기본 번역**

외관으로만 판단한다면 테크프리스트가 한 세기는 살았다고 해도 놀랍지 않을 거야.

**수정 기본 번역**

외관으로만 판단한다면 테크프리스트가 수 세기는 살았다고 해도 놀랍지 않을 거야.

수정 이유: 복수형 centuries 반영

## 710. loc_zealot_male_b__lore_hadron_two_a_04

유형: 기존 수정

**현재 영문**

The Tech-Priest seems blessed with great age.

**기존 기본 번역**

테크프리스트는 위대한 시대의 축복을 받은 것처럼 보인다.

**수정 기본 번역**

테크프리스트는 장수의 축복을 받은 듯하군.

수정 이유: great age를 위대한 시대로 옮긴 오류 수정

## 711. loc_zealot_male_b__lore_space_marines_four_b_01

유형: 기존 수정

**현재 영문**

I've heard it called the "Forge of Strength", possessed by all the Adeptus Astartes.

**기존 기본 번역**

모든 아뎁투스 아스타르테스가 '힘의 제련'을 한다고 하더군.

**수정 기본 번역**

아뎁투스 아스타르테스는 모두 "힘의 제련소"라는 것을 지니고 있다고 들었다.

수정 이유: possessed by를 행동 수행으로 옮긴 오류 수정

## 712. loc_zealot_male_b__lore_space_marines_two_a_01

유형: 기존 수정

**현재 영문**

There be much wisdom in Guilliman's Codex Astartes, even for mere mortals.

**기존 기본 번역**

길리먼의 코덱스 아스타르테스에는 죄인도 읽을 수 있는 많은 배움이 담겨 있다.

**수정 기본 번역**

길리먼의 코덱스 아스타르테스에는 평범한 필멸자에게도 도움이 될 지혜가 가득하다.

수정 이유: mere mortals와 wisdom의 뜻 복원

## 713. loc_zealot_male_b__lore_the_emperor_two_c_01

유형: 기존 수정

**현재 영문**

Praise the Emperor whose sacrifice is life as ours is death.

**기존 기본 번역**

죽음으로 자신을 희생하셔서 우리에게 삶을 주신 그분을 찬양하라.

**수정 기본 번역**

황제 폐하를 찬양하라. 우리의 희생이 죽음이라면, 그분의 희생은 삶이다.

수정 이유: 황제와 추종자의 희생을 대비하는 뜻 복원

## 714. loc_zealot_male_b__mission_cargo_end_event_conversation_two_c_02

유형: 기존 수정

**현재 영문**

If they be tardy, there'll be no heretics left for 'em to smite!

**기존 기본 번역**

지각하게 되면, 이교도들을 처단할 수 없게 된다!

**수정 기본 번역**

늑장을 부리면 저들이 처단할 이교도는 하나도 안 남을 것이다!

수정 이유: 지원팀이 늦을 때 처치 몫이 없어진다는 의미 복원

## 715. loc_zealot_male_b__mission_cargo_start_banter_a_02

유형: 기존 수정

**현재 영문**

So these lazy slugs stand watch while we do the God-Emperor's work?

**기존 기본 번역**

우리가 신-황제 폐하의 과업을 수행하는 동안 저 게으름뱅이들은 우릴 보기만 한다고?

**수정 기본 번역**

우리가 신-황제 폐하의 과업을 수행하는 동안 저 게으름뱅이들은 경계만 서는 건가?

수정 이유: stand watch를 구경으로 옮긴 오류 수정

## 716. loc_zealot_male_b__mission_complex_elevator_conversation_3_c_01

유형: 기존 수정

**현재 영문**

Aye, worthy enough. Wars turn on less.

**기존 기본 번역**

아, 충분히 가치가 있었다. 전쟁이 덜 발생하겠군.

**수정 기본 번역**

아, 충분히 가치가 있지. 전쟁의 향방은 그보다 사소한 일에도 바뀌니.

수정 이유: wars turn on less 관용 표현 수정

## 717. loc_zealot_male_b__mission_propaganda_cultist_town_02

유형: 기존 수정

**현재 영문**

These apostates scrape a meagre living outside the God-Emperor's light.

**기존 기본 번역**

이 변절자는 신-황제 폐하의 빛 속에서 하찮은 삶을 겨우 살았군.

**수정 기본 번역**

이 변절자는 신-황제 폐하의 빛 바깥에서 하찮은 삶을 겨우 살았군.

수정 이유: outside의 방향을 반대로 옮긴 오류 수정

## 718. loc_zealot_male_b__mission_propaganda_short_elevator_conversation_two_a_02

유형: 기존 수정

**현재 영문**

Dig deep, kindred. The road to redemption be long. And tiresome.

**기존 기본 번역**

파고들어라, 동지. 회개의 길은 멀고도 험하지.

**수정 기본 번역**

힘을 내라, 동지. 구원의 길은 멀고도 고되지.

수정 이유: dig deep 관용 표현 수정

## 719. loc_zealot_male_b__mission_rails_district_gate_02

유형: 기존 수정

**현재 영문**

No way through. The district gate be shut fast.

**기존 기본 번역**

통과할 수 없다. 지역 관문이 빨리 닫혔군.

**수정 기본 번역**

통과할 수 없다. 지역 관문이 굳게 닫혔군.

수정 이유: shut fast를 빠른 속도로 옮긴 오류 수정

## 720. loc_zealot_male_b__mission_rails_start_banter_a_02

유형: 기존 수정

**현재 영문**

Scuttling about in the dark like heretics...

**기존 기본 번역**

이교도처럼 어둠 속을 해매야하는 건가...

**수정 기본 번역**

이교도처럼 어둠 속을 헤매야 하는 건가...

수정 이유: 맞춤법 수정

## 721. loc_zealot_male_b__mission_scavenge_underhalls_02

유형: 기존 수정

**현재 영문**

Stay alert! Evil festers in this maze.

**기존 기본 번역**

경계를 늦추지 마. 이 미로에서 악의 축제가 열리고 있다.

**수정 기본 번역**

경계를 늦추지 마라! 이 미로에서는 악이 곪아가고 있다.

수정 이유: festers를 축제로 옮긴 오류 수정

## 722. loc_zealot_male_b__mission_station_start_banter_a_02

유형: 기존 수정

**현재 영문**

Look at them. Martyrs in the making. It fair makes the heart sing!

**기존 기본 번역**

저들을 봐라. 순교자들이 탄생하는 중이지. 공정한 마음이 노래하게 만드는군!

**수정 기본 번역**

저들을 봐라. 순교자가 되어가고 있지. 절로 가슴이 노래하는군!

수정 이유: 강조 부사 fair를 공정한 마음으로 옮긴 오류 수정

## 723. loc_zealot_male_b__mission_strain_inert_tanks_01

유형: 기존 수정

**현재 영문**

There be nought of import here... Emperor guide our search.

**기존 기본 번역**

여긴 수입품도 없고... 황제 폐하께서 우리의 수색을 인도해주신다.

**수정 기본 번역**

여기엔 중요한 것이 없군... 황제 폐하시여, 우리의 수색을 인도하소서.

수정 이유: of import를 수입품으로 옮긴 오류 수정

## 724. loc_zealot_male_b__response_for_enemy_kill_monster_10

유형: 기존 수정

**현재 영문**

Heresy carries a price. Today we collected on the debt.

**기존 기본 번역**

배교에는 대가가 따른다. 오늘 우리는 빚을 갚은 거다.

**수정 기본 번역**

배교에는 대가가 따른다. 오늘 우리는 그 빚을 받아낸 것이다.

수정 이유: 채무 회수를 상환으로 옮긴 오류 수정

## 725. loc_zealot_male_b__response_for_zealot_enemy_kill_monster_02

유형: 기존 수정

**현재 영문**

Killing in fine faith, Guardian!

**기존 기본 번역**

선의의 살인이로다, 가디언!

**수정 기본 번역**

훌륭한 믿음으로 처단했도다, 가디언!

수정 이유: faith를 선의로 옮긴 오류 수정

## 726. loc_zealot_male_b__seen_enemy_grenadier_08

유형: 기존 수정

**현재 영문**

Bomber! Kill the blackguard!

**기존 기본 번역**

보머다! 블랙가드를 죽여라!

**수정 기본 번역**

보머다! 저 악당을 죽여라!

수정 이유: blackguard를 고유명사로 옮긴 오류 수정

## 727. loc_zealot_male_b__seen_enemy_tox_flamer_04

유형: 기존 수정

**현재 영문**

Kindred! Heretic fire abounds!

**기존 기본 번역**

동지! 이교도에겐 불이 많다!

**수정 기본 번역**

동지! 사방에 이교도의 불길이 있다!

수정 이유: 화염 위험 경고를 단순 보유량 표현으로 옮긴 오류 수정

## 728. loc_zealot_male_b__zealot_seen_killstreak_zealot_05

유형: 기존 수정

**현재 영문**

See what ruin a Guardian wreaks!

**기존 기본 번역**

그대의 영광은 정말 끝이 없군, 가디언!

**수정 기본 번역**

가디언이 적들을 어떻게 쓸어버리는지 보아라!

수정 이유: 공유 번역 안의 서로 다른 원문을 문구 ID별로 구분하여 번역

## 729. loc_zealot_male_b__zealot_start_revive_zealot_06

유형: 기존 수정

**현재 영문**

Let the God-Emperor's rage fill ye, and immolate them!

**기존 기본 번역**

신-황제 폐하의 분노가 그대를 집어 삼키게 해라!

**수정 기본 번역**

신-황제 폐하의 분노로 그대를 채워라. 그리고 놈들을 불태워라!

수정 이유: 불태우는 대상이 아군으로 뒤바뀐 오류 수정

## 730. loc_zealot_male_c__lore_daemons_four_c_01

유형: 기존 수정

**현재 영문**

The Eye of Terror was the doom of Cadia. If the Empire's finest can fall, what hope for us?

**기존 기본 번역**

아이 오브 테러는 카디아의 멸망이다. 만약 황제 폐하의 경관들도 타락하게 된다면, 우리에게 무슨 희망이 있는가?

**수정 기본 번역**

아이 오브 테러가 카디아를 파멸시켰다. 제국의 최정예조차 무너진다면, 우리에게 무슨 희망이 있겠는가?

수정 이유: finest를 경관으로, fall을 타락으로 옮긴 오류 수정

## 731. loc_zealot_male_c__lore_the_emperor_two_b_01

유형: 기존 수정

**현재 영문**

An act of surpassing love, to immure himself in the Golden Throne for all time.

**기존 기본 번역**

영원히 황금 옥좌에 몸을 담그는 행위, 그것이 바로 사랑을 뛰어넘는 예술이지.

**수정 기본 번역**

영원히 황금 옥좌에 자신을 가두시다니, 그보다 큰 사랑은 없을 것이다.

수정 이유: act와 immure를 예술과 담금으로 옮긴 오류 수정

## 732. loc_zealot_male_c__lore_the_warp_four_b_02

유형: 기존 수정

**현재 영문**

Great is the mind too small for doubt. These matters are best left unconsidered.

**기존 기본 번역**

정신은 너무나도 위대하여 의심을 품을 여지도 없다. 이 문제는 고려하지 않는 것이 최선이지.

**수정 기본 번역**

의심조차 품지 못할 만큼 작은 정신이야말로 위대하다. 이런 문제는 생각하지 않는 편이 최선이지.

수정 이유: too small for doubt의 역설을 반대로 옮긴 오류 수정

## 733. loc_zealot_male_c__mission_cargo_end_event_conversation_three_a_01

유형: 기존 수정

**현재 영문**

How did a Tech-Priest such as you find your way to an inquisitorial retinue?

**기존 기본 번역**

그대 같은 테크프리스트가 어떻게 조사 수행관의 길을 찾은건가?

**수정 기본 번역**

그대 같은 테크프리스트가 어떻게 이단심문관의 수행단에 들어왔는가?

수정 이유: inquisitorial retinue를 조사 수행관이라는 직책으로 옮긴 오류 수정

## 734. loc_zealot_male_c__mission_propaganda_elevator_conversation_two_c_01

유형: 기존 수정

**현재 영문**

To the Warp with it.

**기존 기본 번역**

워프로 이동하지.

**수정 기본 번역**

워프에나 처박혀라.

수정 이유: To the Warp with it을 이동 지시로 옮긴 오류 수정

## 735. loc_zealot_male_c__mission_rails_end_event_conversation_two_c_01

유형: 기존 수정

**현재 영문**

Huh. That's gratitude for you.

**기존 기본 번역**

그게 그대가 받을 감사 인사다.

**수정 기본 번역**

허. 고마움에 대한 보답이 고작 이거로군.

수정 이유: that's gratitude for you의 빈정거림 복원

## 736. loc_zealot_male_c__mission_station_mid_event_conversation_one_c_02

유형: 기존 수정

**현재 영문**

Very well. But I cannot promise to do it with any skill.

**기존 기본 번역**

잘했군. 하지만 어떤 기술로도 해낼 수 있다고 장담할 수는 없다.

**수정 기본 번역**

좋다. 하지만 내가 능숙하게 해낼 거라고는 장담할 수 없다.

수정 이유: 화자의 숙련도 문제를 기술의 가능 여부로 옮긴 오류 수정

## 737. loc_zealot_male_c__mission_station_start_banter_a_01

유형: 기존 수정

**현재 영문**

These soldiers could use a rousing sermon to rekindle their faith.

**기존 기본 번역**

이 병사들은 신앙에 다시 불을 붙일 수 있는 감동적인 설교를 들을 수 있겠군.

**수정 기본 번역**

이 병사들에게는 믿음에 다시 불을 붙여줄 힘찬 설교가 필요하겠군.

수정 이유: could use를 단순 가능 표현으로 옮긴 오류 수정

## 738. loc_zealot_male_c__mission_stockpile_cartel_habs_02

유형: 기존 수정

**현재 영문**

Such misery in this place. Who can be surprised the enemy has made it their own?

**기존 기본 번역**

이 곳은 정말 비참하군. 적들이 자기들 것으로 만들었다니 누가 놀라지 않을 수 있겠나?

**수정 기본 번역**

이곳은 참 비참하군. 적들이 이곳을 차지한들 놀랄 일이겠는가?

수정 이유: 놀랍지 않다는 반문을 반대로 옮긴 오류 수정
