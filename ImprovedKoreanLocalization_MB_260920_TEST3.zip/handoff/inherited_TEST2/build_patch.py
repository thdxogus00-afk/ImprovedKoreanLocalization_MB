from pathlib import Path
import json, hashlib, shutil
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MOD_REL = Path("scripts/mods/ImprovedKoreanLocalization/ImprovedKoreanLocalization.lua")
def lua_string(s):
    # UTF-8 text, with Lua 5.1-compatible ASCII escaping only.
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\r', '\\r').replace('\n', '\\n').replace('\t', '\\t') + '"'

def render_extension(changes):
    lines = [
        '', '', '-- MB continuation 260919 TEST2; reviewed 2026-09-19.',
        '-- Original work: Polarmingo / DARKS0UND. Continuation: Songshin; review assistance: Codex.',
        '-- See handoff/CHANGES.json for source text, original translations, and reasons.',
        '-- Registered after the original templates; WhatTheLocalization processes these in order.',
        'do',
        '    local function make_reviewed_handler(default_text, custom_text)',
        '        return function(locale, value)',
        '            if locale ~= "ko" then return value end',
        '            if mode == "custom" then return custom_text end',
        '            return default_text',
        '        end',
        '    end',
        '    local reviewed_entries = {',
    ]
    for c in changes:
        lines.append('        {' + ', '.join(lua_string(c[k]) for k in ('key', 'final_ko_default', 'final_ko_custom')) + '},')
    lines += [
        '    }',
        '    for review_index, entry in ipairs(reviewed_entries) do',
        '        table.insert(mod.localization_templates, {',
        '            id = "mb_260919_review_" .. review_index,',
        '            loc_keys = {entry[1]},',
        '            locales = {"ko"},',
        '            handle_func = make_reviewed_handler(entry[2], entry[3]),',
        '        })',
        '    end',
        'end', '',
    ]
    return '\r\n'.join(lines).encode('utf-8')

def main():
    changes = json.loads((HERE / "CHANGES.json").read_text(encoding="utf-8"))
    manifest = json.loads((HERE / "MANIFEST.json").read_text(encoding="utf-8"))
    baseline = HERE / "baseline/ImprovedKoreanLocalization"
    original = (baseline / MOD_REL).read_bytes()
    assert hashlib.sha256(original).hexdigest() == manifest["baseline_sha256"], "Baseline hash mismatch"
    keys = [c["key"] for c in changes]
    assert len(keys) == len(set(keys)), "Duplicate override keys"
    output = ROOT / "ImprovedKoreanLocalization"
    shutil.copytree(baseline, output, dirs_exist_ok=True)
    target = output / MOD_REL
    target.write_bytes(original + render_extension(changes))
    print("Rebuilt", target)
    print("SHA-256", hashlib.sha256(target.read_bytes()).hexdigest())
if __name__ == "__main__": main()
