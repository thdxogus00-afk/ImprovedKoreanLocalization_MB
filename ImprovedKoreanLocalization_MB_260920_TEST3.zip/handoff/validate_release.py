"""Meaningful regression checks using actual WTL and LocalizationManager source.

Requires liblua5.4, Node.js, and bundled luaparse. Game services are mocked.
This does not certify the in-game LuaJIT environment or actual display/layout.
"""
import collections
import ctypes
import ctypes.util
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

from build_patch import MOD_REL, lua_string, render_extension
from compare_exports import read_dump

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

# Same grammar as the bundled LocalizationManager: ':' is optional, a missing
# format is tostring, and {#...} markup is not a context interpolation token.
INTERPOLATION = re.compile(r'\{([a-zA-Z0-9_]*):*([a-zA-Z0-9.%]*)\}')
MACRO = re.compile(r'\$([a-zA-Z0-9_]*):*([a-zA-Z0-9,_]*)\$')

def bindings(text):
    return collections.Counter(('context', key, fmt or '%s') for key, fmt in INTERPOLATION.findall(text)) + collections.Counter(
        ('macro', name, param) for name, param in MACRO.findall(text))

def exact_tokens(text):
    return collections.Counter(re.findall(r'\{[^{}]+\}|\$[^$\n]+\$', text))

def lua_run(code):
    name = ctypes.util.find_library('lua5.4')
    if not name: raise RuntimeError('liblua5.4 is required')
    lib = ctypes.CDLL(name)
    lib.luaL_newstate.restype = ctypes.c_void_p
    lib.luaL_openlibs.argtypes = [ctypes.c_void_p]
    lib.luaL_loadstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    lib.luaL_loadstring.restype = ctypes.c_int
    lib.lua_pcallk.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_longlong, ctypes.c_void_p]
    lib.lua_pcallk.restype = ctypes.c_int
    lib.lua_tolstring.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
    lib.lua_tolstring.restype = ctypes.c_char_p
    lib.lua_close.argtypes = [ctypes.c_void_p]
    state = lib.luaL_newstate()
    lib.luaL_openlibs(state)
    try:
        status = lib.luaL_loadstring(state, code.encode())
        if not status: status = lib.lua_pcallk(state, 0, 1, 0, 0, None)
        result = lib.lua_tolstring(state, -1, None)
        result = result.decode() if result else ''
        if status: raise RuntimeError(result)
        return result
    finally: lib.lua_close(state)

def main():
    manifest = json.loads((HERE / 'MANIFEST.json').read_text())
    changes = json.loads((HERE / 'CHANGES_TEST3.json').read_text())
    changed = {c['key']:c for c in changes}
    old = HERE / 'previous_TEST2/ImprovedKoreanLocalization'
    current = ROOT / 'ImprovedKoreanLocalization'
    original_bytes = (old / MOD_REL).read_bytes()
    current_bytes = (current / MOD_REL).read_bytes()
    assert sha(old / MOD_REL) == manifest['previous_main_sha256']
    assert current_bytes == original_bytes + render_extension(changes), 'Rebuild/prefix mismatch'
    for f in old.rglob('*'):
        if f.is_file() and f.relative_to(old) != MOD_REL:
            assert f.read_bytes() == (current / f.relative_to(old)).read_bytes()
    for source in manifest['sources']:
        assert sha(ROOT / source['path']) == source['sha256']
    hashes = json.loads((HERE / 'SOURCE_REFERENCE_HASHES.json').read_text())['files']
    for filename, expected in hashes.items():
        assert sha(HERE / 'reference' / filename) == expected
    en_meta, en = read_dump(HERE / 'sources/expanded_en.jsonl')
    ko_meta, ko = read_dump(HERE / 'sources/expanded_ko.jsonl')
    assert en_meta['build_identifier'] == ko_meta['build_identifier'] == manifest['game_build']
    assert en_meta['catalogue_sha256'] == ko_meta['catalogue_sha256']
    previous = {}
    for line in (HERE / 'inherited_TEST2/ALL_8425_REVIEW.jsonl').open():
        r = json.loads(line)
        for row in r['current']:
            previous[row['key']] = dict(default=row['final_ko_default'], custom=row['final_ko_custom'])
    for c in json.loads((HERE / 'inherited_TEST2/CHANGES.json').read_text()):
        previous[c['key']] = dict(default=c['final_ko_default'], custom=c['final_ko_custom'])
    assert len(previous) == 12484
    assert not (set(changed) & {c['key'] for c in json.loads((HERE / 'inherited_TEST2/CHANGES.json').read_text())}), 'TEST2 reviewed overrides must be retained'
    exact_checks = 0
    for c in changes:
        assert c['current_en'] == en[c['key']]['raw']
        assert c['builtin_ko'] == ko[c['key']]['raw']
        for mode in ('default','custom'):
            assert exact_tokens(c['current_en']) == exact_tokens(c['final_ko_'+mode]), c['key']
            exact_checks += 1

    # Check all available paired strings after applying the actual expected mod
    # outputs. Report markup differences separately; do not call them lost variables.
    binding_checks, binding_mismatches = 0, []
    markup_differences = []
    for key, row in en.items():
        if row['status'] != 'found': continue
        if ko.get(key, {}).get('status') != 'found': continue
        for mode in ('default','custom'):
            after = (changed[key]['final_ko_'+mode] if key in changed else
                     previous[key][mode] if key in previous else ko[key]['raw'])
            binding_checks += 1
            if bindings(row['raw']) != bindings(after):
                binding_mismatches.append(dict(key=key, mode=mode, current_en=row['raw'], final_ko=after))
            if re.findall(r'\{#[^{}]*\}', row['raw']) != re.findall(r'\{#[^{}]*\}', after):
                markup_differences.append(dict(key=key, mode=mode, inherited=key in previous))
    assert not binding_mismatches, binding_mismatches[:4]
    (HERE / 'MARKUP_DIFFERENCES.json').write_text(json.dumps(markup_differences, ensure_ascii=False, indent=2)+'\n')

    node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
    if not node: raise RuntimeError('Node.js is required for Lua 5.1 syntax validation')
    syntax = json.loads(subprocess.check_output([node, str(HERE / 'validate_lua.js')], text=True))

    with tempfile.TemporaryDirectory(prefix='ikl_test3_') as directory:
        fixtures = Path(directory) / 'fixtures.lua'
        lines = ['return {']
        for key in sorted(set(previous)|set(changed)):
            raw_ko = ko.get(key,{}).get('raw') or '__raw_ko__'+key
            raw_en = en.get(key,{}).get('raw') or '__raw_en__'+key
            d = changed[key]['final_ko_default'] if key in changed else previous[key]['default']
            c = changed[key]['final_ko_custom'] if key in changed else previous[key]['custom']
            values = [key,raw_ko,raw_en,d,c]
            context = {}
            for context_key, fmt in INTERPOLATION.findall(raw_en):
                context[context_key] = '17' if fmt and fmt[-1:]!='s' else '"TOKEN_'+context_key+'"'
            ctx = '{'+','.join('['+lua_string(k)+']='+v for k,v in sorted(context.items()))+'}'
            lines.append('{'+','.join(lua_string(s) for s in values)+','+str(key in changed).lower()+','+ctx+'},')
        lines.append('}')
        fixtures.write_text('\n'.join(lines))
        prefix = '\n'.join([
            'local MAIN = '+lua_string(str(current/MOD_REL)),
            'local REF = '+lua_string(str(HERE/'reference')),
            'local FIXTURES = '+lua_string(str(fixtures)),
            'local EXPECTED_TEMPLATES = '+str(manifest['counts']['runtime_templates']),
        ])
        runtime = json.loads(lua_run(prefix+'\n'+(HERE/'runtime_regression.lua').read_text()))
    result = dict(result='PASS', test3_exact_token_mode_checks=exact_checks,
                  full_paired_effective_binding_mode_checks=binding_checks,
                  effective_binding_mismatches=0,
                  inherited_or_builtin_markup_differences=len(markup_differences),
                  lua51=syntax, runtime=runtime, previous_file_byte_prefix_preserved=True,
                  test2_738_reviewed_overrides_preserved=True,
                  rebuilt_bytes_equal=True, installed_main_sha256=sha(current/MOD_REL),
                  in_game_tested=False,
                  limitations=['Lua 5.4 simulation with actual bundled WTL/LocalizationManager code; engine services mocked.',
                               'Lua 5.1 syntax parsed; game LuaJIT execution, UI clipping, audio timing and gameplay not tested.',
                               'Full binding check uses LocalizationManager grammar: optional colon and implicit string format are equivalent.',
                               'No claim that automatic checks constitute complete semantic review.'])
    (HERE/'VALIDATION_TEST3.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    manifest['installed_main_sha256'] = result['installed_main_sha256']
    (HERE/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__ == '__main__': main()
