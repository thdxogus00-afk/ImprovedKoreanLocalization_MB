"""Explicit, source-paired TEST3 decisions. No blanket translation replacement."""
CHANGES = {}

def change(key, text, reason, source_note=None):
    assert key not in CHANGES, key
    CHANGES[key] = dict(text=text, reason=reason, source_note=source_note)

def talent(suffix, text, reason, source_note=None):
    change('loc_talent_cryptic_' + suffix, text, reason, source_note)

talent('afflicted_increased_damage_desc',
       '근접 또는 원거리 공격으로 감전, 소울블레이즈, 화상, 출혈 또는 중독 상태인 적을 맞히면 {duration:%s}초 동안 대미지가 {damage:%s} 증가합니다.',
       '열거한 상태 중 하나만 충족하면 되는 OR 조건을 명시.')
talent('ally_coherency_defenses_desc',
       '자신 또는 단결 내 아군이 강인함 대미지를 받으면, 대미지를 받은 대상의 스태미나가 {stamina:%s} 회복됩니다. 쿨다운은 {stamina_cd:%s}초입니다.\n자신 또는 단결 내 아군이 체력 대미지를 받으면, 대미지를 받은 대상의 강인함이 {toughness:%s} 회복됩니다. 쿨다운은 {toughness_cd:%s}초입니다.',
       '회복 대상을 대미지를 받은 당사자로 명시하고 Toughness를 기존 모드의 강인함으로 통일.',
       'cryptic_buff_templates.lua: cryptic_ally_coherency_defenses_stamina/toughness는 params.attacked_unit을 회복시킨다.')
talent('ammo_reserve_desc', '탄약 보유량이 {ammo:%s} 증가합니다.', '문장 앞의 불필요한 공백 제거.')
talent('arc_grenades_capacitance_gain_desc',
       '아크 수류탄을 던져 전기 폭발을 일으킵니다. 폭발은 {number:%s}회 연쇄되며, 장갑 적과 스페셜리스트를 우선적으로 타격하여 막대한 대미지와 충격을 가합니다. 아크 수류탄으로 엘리트 또는 스페셜리스트를 처치할 때마다 {capacitance_keyword:%s}을 {capacitance:%s} 생성합니다.',
       'Specialist를 기존 모드의 스페셜리스트로 통일하고 정전용량의 수치·조사를 정리.')
talent('better_heavies_desc',
       '근접 공격을 충전하는 동안 방해받지 않습니다. 근접 강한 공격의 대미지가 {damage:%s} 증가합니다.',
       'Heavy Melee Damage의 수식 관계를 명확히 정리.')
talent('crits_grant_power_desc',
       '치명타 적중 시 {duration:%s}초에 걸쳐 {capacitance_keyword:%s}을 {power:%s} 생성합니다.',
       '누락된 목적격 조사와 정전용량 수치의 띄어쓰기 수정.')
talent('crits_grant_tdr_desc',
       '치명타 적중 시 {duration:%s}초 동안 강인함을 총 {toughness:%s} 회복하며, 강인함 대미지 감소율이 {tdr:%s} 증가합니다.',
       '강인함은 지속 회복되고 대미지 감소 효과는 같은 시간 동안 유지됨을 명확히 설명.',
       'cryptic_buff_templates.lua: cryptic_crits_grant_tdr는 _toughness_regen_over_time_on_proc_generator를 사용하며 toughness_regen_per_second = toughness_restored / duration, proc_stat_buffs로 대미지 감소를 부여한다. 코드 스냅샷은 현재 실행 파일 자체가 아니므로 게임 내 확인은 별도.')
talent('disabled_allies_defense_post_boost_desc',
       '단결 내 아군이 무력화되면 구출될 때까지 해당 아군의 대미지 저항이 {damage_resistance:%s} 증가합니다. 자신이 직접 구출하면 해당 아군은 {duration:%s}초 동안 기절 면역을 얻고 대미지 저항이 {damage_resistance_post:%s} 증가합니다.',
       '직접 구출해야 하는 추가 효과의 조건과 혜택을 받는 아군을 명시.')
talent('discharge_arc_bonus_desc',
       '{ability_name:%s} 사용 시 소비한 충전 하나당 전방으로 아크를 {num_arcs:%s}개 방출합니다. 각 아크는 높은 대미지와 충격을 가합니다.',
       'Impact를 확정 비틀거림 효과로 단정하지 않고 기존 능력치 용어인 충격으로 표기.')
talent('discharge_desc',
       '주위에 전류 방출을 일으킵니다. {range:%s}미터 내의 적은 {duration:%s}초 동안 감전되어 기절하고 대미지를 받습니다.\n\n충전이 {charge_two:%s}개 이상일 때 {talent_name:%s}을 사용하면 {far_range:%s}미터 내 원거리 적의 무기가 {malfunction_duration:%s}초 동안 고장 납니다.\n\n충전이 {charge_three:%s}개 이상일 때 {talent_name:%s}을 사용하면, 이후 {buff_duration:%s}초 동안 자신의 공격이 적을 {short_duration:%s}초 동안 감전시켜 대미지를 줍니다.\n\n전류 확장기 능력의 강화판입니다.',
       'Voltaic Expander의 실제 능력명인 전류 확장기와 참조 이름을 일치시키고 충전 조건을 정리.')
talent('dissector_desc',
       '{talent_name:%s} 중첩을 최대 {max_stacks:%s}회까지 보유할 수 있습니다. 각 중첩은 대미지를 {damage:%s} 증가시키고 강인함 대미지 감소를 {tdr:%s} 부여합니다.\n\n대미지를 받으면 중첩이 {removed_stacks:%s}회 제거됩니다. 이 효과는 {icd:%s}초마다 한 번씩만 발생합니다. 엘리트 또는 스페셜리스트를 처치하면 중첩이 {elite_special_stack:%s}회 회복되고 강인함이 {toughness:%s} 회복됩니다.',
       'Specialist의 전문가 오역을 스페셜리스트로 수정하고 개별 처치 조건을 분명히 표시.')
talent('dissector_power_desc',
       '엘리트 또는 스페셜리스트를 처치하면 {capacitance_keyword:%s}을 추가로 {power:%s} 회복합니다.',
       'Specialist 용어와 목적격 조사를 수정.')
talent('increased_passive_cooldown_regen_desc',
       '매초 {capacitance_keyword:%s}을 {power:%s} 생성합니다.',
       '자원 이름과 수치가 붙는 표기를 정리.')
talent('melee_cleave_and_impact_desc',
       '강인함이 {toughness:%s}를 초과하면 근접 쪼개기가 {cleave:%s} 증가하고, 그 이하이면 근접 충격이 {impact:%s} 증가합니다.',
       '경계값 조건을 이상/미만에서 초과/이하로 수정.',
       '영문 above 및 cryptic_buff_templates.lua의 cryptic_cleave_while_above_stamina_threshold: current_toughness_percent > threshold, cryptic_impact_while_below_stamina_threshold: <= threshold를 대조. 실행 중인 게임에서 경계값 확인은 별도.')
talent('multi_hits_grant_power_desc',
       '한 번의 공격으로 적을 {number:%s}명 이상 맞히면 {capacitance_keyword:%s}을 {power:%s} 회복합니다.',
       '한 번의 공격이라는 발동 단위와 누락된 조사를 명확히 표기.')
talent('multi_hits_restore_toughness_desc',
       '한 번의 공격으로 적을 {number:%s}명 이상 맞히면 {duration:%s}초에 걸쳐 강인함을 {toughness:%s} 회복합니다.',
       '여러 공격의 누적 타격 수로 오해하지 않도록 한 번의 공격 조건을 명시.')
talent('no_braced_movement_penalty_desc',
       '지향 사격 또는 정조준 중 이동 속도 페널티: {movement_speed_modifier:%s}\n탄 분산: {spread:%s}',
       'bracing을 버팀대로 번역한 오류를 수정. 부호가 포함된 변수에 감소를 중복 붙이지 않도록 능력치 형식으로 표시.',
       'cryptic_talents.lua: movement_speed_modifier는 - 접두사, spread는 signed percentage. talent_settings_cryptic.lua 스냅샷 값으로 -50%, -30% 표시를 확인할 수 있으며 번역에 수치를 고정하지 않는다.')
talent('overload_keystone_coherency_desc',
       '자신 또는 단결 내 아군이 적을 처치하면 {talent_name:%s} 중첩을 {low_stack:%s}회 얻습니다. 엘리트 또는 스페셜리스트를 처치하면 {elite_stacks:%s}회 얻습니다. 최대 {max_stacks:%s}회 중첩됩니다. 최대 중첩에 도달하면 과부하가 발생하고 중첩이 {zero:%s}회로 초기화됩니다.\n\n과부하가 발생하면 {duration:%s}초 동안 자신과 단결 내 아군의 대미지가 {damage:%s} 증가하고 강인함 대미지 감소를 {tdr:%s} 얻습니다.',
       'Specialist 용어, 누락된 중첩 단위, 처치 주체를 정리.')
talent('passive_cooldown_regen_desc',
       '능력은 {talent_name:%s}을 동력으로 사용합니다.\n\n기본 충전은 {num_base_charges:%s}개입니다. 능력을 사용하려면 충전이 최소 {min_charge:%s}개 필요하며, 최대 {max_charge:%s}개를 소모합니다. 소모한 충전마다 추가 효과를 얻습니다.\n\n매초 {capacitance_keyword:%s}을 {power:%s} 생성합니다. {capacitance_keyword:%s}이 {max_power:%s}에 도달하면 충전을 {gained_charges:%s}개 얻고 {capacitance_keyword:%s}이 초기화됩니다. 적을 처치할 때도 {capacitance_keyword:%s}을 {kill_power:%s} 생성하며, 엘리트 또는 스페셜리스트 처치 시 생성량이 {elite_power:%s}로 증가합니다.',
       'powered by를 단순 강화가 아닌 능력 사용 동력으로 설명하고 충전 수·소모량·생성량의 관계 및 Specialist 용어를 정리.')
talent('precision_stance_drain_cost_desc',
       '{capacitance_keyword:%s}을 {capacitance_instant:%s} 소모하고 보조 무기로 전환합니다. 무기가 조준점 근처의 적을 자동으로 조준하여 초인적인 명중률을 제공합니다. 활성화 중 탄 분산 {spread:%s}, 반동 {recoil:%s} 효과를 얻습니다.\n\n활성화 중에는 매초 {capacitance_keyword:%s}을 {capacitance_drain:%s} 소모하며, 사격할 때마다 추가로 {capacitance_shot:%s} 소모합니다. 재장전 중에는 소모가 일시 중지됩니다.\n\n보조 무기에서 다른 무기로 전환하거나, {capacitance_keyword:%s}이 {zero_capacitance:%s}이고 충전이 {zero_charges:%s}개가 되거나, 능력 입력을 다시 누르면 종료됩니다. 충전이 최소 {charge_min:%s}개 있어야 사용할 수 있습니다.\n\n쿨다운은 없습니다.',
       'locks onto를 적의 이동을 고정하는 효과로 오해하지 않도록 자동 조준으로 설명. 자원 고갈의 AND 조건과 보조 무기 전환 조건을 명시하고 음수 능력치 변수의 부호를 보존.')
talent('precision_stance_fire_rate_increased_desc',
       '{talent_name:%s} 활성화 중 연사 속도가 {fire_rate:%s} 증가하며, {duration:%s}초 후에는 증가량이 {fire_rate_increased:%s}로 높아집니다.',
       'Fire Rate의 발사 속도/연사 속도 혼용을 통일하고 이후 수치가 증가량임을 명시.')
talent('push_stagger_stamina_desc',
       '스태미나가 {stamina:%s} 이상이면 밀치기의 충격이 {push_strength:%s} 증가합니다.',
       '뒤바뀐 스태미나 조건 변수와 밀치기 충격 변수를 올바른 자리에 배치.',
       '영문 및 cryptic_talents.lua의 format_values: stamina=target_stamina_percent, push_strength=push_impact_modifier; cryptic_buff_templates.lua는 >= 조건.')
talent('revive_speed_and_dr_desc',
       '쓰러진 아군을 소생시키는 동안 대미지 저항이 {damage_reduction:%s} 증가합니다. 소생 속도가 {revive_speed:%s} 증가합니다.',
       'Revive를 사망 후 부활과 혼동하지 않도록 쓰러진 아군의 소생으로 설명.')
talent('servo_skull_flamethrower_new_desc',
       '플레이머를 장착한 추가 서보 스컬을 보유합니다. 대상 위치를 지정해 배치합니다. 기본 행동 입력으로 분산 사격과 집중 사격 모드를 전환합니다.\n\n{flamer_talent:%s}와 {medicae_talent:%s}를 모두 선택하면 충전을 {bonus_charge:%s}개 추가로 얻습니다.',
       'Servo-Skull 띄어쓰기와 입력 안내를 통일하고 두 재능 선택 시 충전 증가가 추가 혜택임을 명시.')
talent('servo_skull_improved', '장인 서보 스컬', 'Artificer를 종자로 옮긴 오류 수정. 장인이라는 제작·기술 의미를 반영.')
talent('servo_skull_inject_ally', '의료 서보 스컬', 'Medicae의 의료 기능을 반영하여 약 서보 스컬을 수정.')
talent('servo_skull_inject_ally_revive_new_desc',
       '개조된 의료용 주사기를 장착한 추가 서보 스컬을 보유합니다. 쓰러졌거나 포박되었거나 그물에 걸린 아군을 조준해 주사합니다.\n\n주사를 맞은 아군은 소생하며, {duration:%s}초 동안 강인함 대미지 감소를 {tdr:%s} 얻고 매초 강인함을 {toughness_per_second:%s} 회복합니다.\n\n{flamer_talent:%s}와 {medicae_talent:%s}를 모두 선택하면 충전을 {bonus_charge:%s}개 추가로 얻습니다.',
       'Medicae Syringes의 물약 오역을 의료용 주사기로 수정하고 회복·감소 효과의 지속시간과 충전 증가를 명시.')
talent('specials_marking_desc',
       '자신의 {range:%s}미터 이내에 접근한 스페셜리스트에게 표식이 표시됩니다.',
       'Specialists를 전문가에서 스페셜리스트로 통일.')
talent('stun_dr_power_desc',
       '기절에 면역이 되며 대미지 저항이 {damage:%s} 증가합니다. 근접 대미지를 받으면 {capacitance_keyword:%s}을 {power:%s} 소모합니다.',
       '누락된 목적격 조사와 자원 수치 표기를 수정.')
talent('weakspot_damage', '명사수 코지테이터 동기화', 'Cogitator를 인지로 옮긴 의미 누락을 기존 모드의 코지테이터 용어로 수정.')
talent('weakspot_kills_grant_power_desc',
       '약점 공격으로 적을 처치하면 {capacitance_keyword:%s}을 {power:%s} 생성합니다.',
       '누락된 목적격 조사와 자원 수치 표기를 수정.')

change('loc_achievement_cryptic_hacking_solves_description',
       '서보 스컬을 사용하여 다음 임무에서 데이터 심문 이벤트를 자동화하십시오.',
       'missions를 레벨이 아닌 임무로 수정.')
change('loc_achievement_cryptic_medicae_saves_description',
       '의료 서보 스컬을 사용하여 다음 상태에 빠진 아군을 구출하십시오.',
       '의료 서보 스컬의 수정된 능력명과 고행의 참조 이름을 일치시킴.')
change('loc_class_cryptic_description',
       '스키타리 알파 프리무스는 신성한 전투 교리와 첨단 전술 코지테이터로 개조·강화된 베테랑 스키타리 전사입니다.',
       '스키아리 오타, combat doctrines의 의식 오역, tactical cogitators의 전략적 사고 오역을 수정.')
change('loc_character_backstory_snippet_cryptic',
       '옴니시아를 섬겨 온 당신은 이제 아토마에 이르러 스키타리 알파 프리무스라는 영예로운 지위에 올랐습니다. 새롭게 강화된 전투 교리와 개량된 이식물만이 테르티움 하이브의 도살장에서 살아남을 유일한 희망일지도 모릅니다. 계속해서 세력을 넓히는 그렌딜의 워밴드에서 당신은 어뎁투스 메카니쿠스의 이익을 수호하고, 이 행성을 뒤덮은 어둠을 걷어낼 것입니다.',
       'your를 이들의로 옮긴 주체 오류와 exalted status의 의미를 바로잡고 생존의 유일한 희망이라는 원문 한정 표현을 복원.')
change('loc_tutorial_cryptic_capacitance_desc',
       '스키타리는 정전용량을 동력으로 능력을 사용합니다. 정전용량이 100%에 도달하면 충전이 하나 생성됩니다.\n정전용량은 시간이 지남에 따라 자동으로 생성되며, 적을 처치해도 얻을 수 있습니다.',
       '정전용량이 능력을 추가 강화하기만 하는 자원처럼 보이지 않도록 사용 동력임을 설명.')

# Complete source strings found unchanged in the Korean resource, plus token errors.
UI_FIXES = {
    'loc_achievement_broker_enemies_hit_by_flash_grenade_name': ('실명!', '영문에 없는 {tier} 변수를 제거하여 미치환 변수가 표시될 위험을 해소.'),
    'loc_achievement_broker_enemies_killed_by_missile_launcher_name': ('폭탄 투하', '영문에 없는 {tier} 변수를 제거. 기존 한국어 제목은 유지.'),
    'loc_talent_zealot_3_passive_3_description': ('받는 부패가 {corruption_reduction:%s} 감소합니다.', '예전 printf 자리표시자 %d%%를 현재 영문의 이름 있는 변수로 교체.'),
    'loc_talent_zealot_3_tier_2_ability_3_description': ('쪼개기가 {max_hit:%s} 증가합니다.', '예전 printf 자리표시자 %d%%를 현재 영문의 이름 있는 변수로 교체.'),
    'loc_penance_grid_show_all': ('모든 고행 표시', '한국어 덤프에 영어로 남은 필터 이름 번역.'),
    'loc_penance_grid_show_completed': ('완료한 고행 표시', '한국어 덤프에 영어로 남은 필터 이름 번역.'),
    'loc_penance_grid_show_uncompleted': ('미완료 고행 표시', '한국어 덤프에 영어로 남은 필터 이름 번역.'),
    'loc_premium_currency_purchase_error_generic': ('알 수 없는 오류로 유료 화폐를 구매하지 못했습니다.\n\n결제가 청구되었다면 고객 지원에 문의하세요.', '한국어 덤프에 영어로 남은 구매 실패 안내 번역.'),
    'loc_notification_acqusition_failed': ('보급소에서 구매하지 못했습니다. 다시 시도하세요.', '한국어 덤프에 영어로 남은 보급소 구매 실패 안내 번역.'),
    'loc_stolen_rations_destroyed_stat_name': ('파괴한 식량: {value}', '한국어 덤프에 영어로 남은 임무 통계 번역. 변수 보존.'),
    'loc_stolen_rations_recovered_stat_name': ('회수한 식량: {value}', '한국어 덤프에 영어로 남은 임무 통계 번역. 변수 보존.'),
    'loc_setting_resolution_custom': ('사용자 지정', '한국어 덤프에 영어로 남은 해상도 옵션 번역.'),
    'loc_setting_dlss_model_neural_network': ('합성곱 신경망', '기술 이름의 뜻을 번역. 모델 동작 설명은 추가하지 않음.'),
    'loc_talent_max_ammo_low': ('탄약 보유량 증가', '한국어 덤프에 영어로 남은 재능 이름 번역.'),
    'loc_talent_max_ammo_low_desc': ('탄약 보유량이 {ammo:%s} 증가합니다.', '한국어 덤프에 영어로 남은 재능 설명 번역. 변수 보존.'),
    'loc_objective_dm_stockpile_wait_purge_desc': ('시스템 정화 절차가 완료될 때까지 적을 막아내세요.', '한국어 덤프에 영어로 남은 완결된 임무 지시 번역.'),
    'loc_objective_find_corruptor_desc': ('주변의 데몬 오염을 파괴하세요.', '한국어 덤프에 영어로 남은 완결된 임무 지시 번역.'),
    'loc_objective_hm_complex_final_event_running_desc': ('메시지를 전송할 수 있도록 송신기를 재정렬하세요.', '한국어 덤프에 영어로 남은 완결된 임무 지시 번역.'),
    'loc_objective_hub_command_central_desc': ('전략실에서 모로와 졸라를 만나세요.', '한국어 덤프에 영어로 남은 완결된 임무 지시 번역.'),
    'loc_objective_survive_desc': ('버티면서 이 구역을 방어하세요.', '한국어 덤프에 영어로 남은 완결된 임무 지시 번역.'),
    'loc_objective_survive_header': ('진지를 사수하세요', '한국어 덤프에 영어로 남은 완결된 임무 제목 번역.'),
    'loc_objective_zone_scanning_desc': ('오스펙스를 사용하여 주변 구역의 물체를 스캔하세요.', '한국어 덤프에 영어로 남은 완결된 임무 지시 번역.'),
    'loc_objective_zone_scanning_pathogen_desc': ('오스펙스로 주변 구역의 물체를 스캔하여 병원체의 근원지를 찾으세요.', '한국어 덤프에 영어로 남은 완결된 임무 지시 번역.'),
    'loc_pickup_breaching_charge': ('돌파용 폭약', '한국어 덤프에 영어로 남은 습득물 이름 번역.'),
}
for key, (text, reason) in UI_FIXES.items():
    change(key, text, reason)

change('loc_ogryn_a__mission_strain_mid_event_conversation_three_c_02',
       '걱정 마, 친구들. 내가 끈적이한테서 너희를 지켜줄게.',
       '복수의 친구들과 점액으로부터 지키겠다는 대상을 복원.')
change('loc_ogryn_a__mission_strain_mid_event_conversation_two_c_01',
       '그러니까... 끈적이라는 거지. 또 끈적이야, 응?',
       'So를 매우로 옮긴 오류와 More goo를 더 끈적해진다는 변화로 옮긴 오류를 수정.')
change('loc_past_young_sergeant_a__story_echo_morrow_02_d_01',
       '사망했습니다. 직전 참호에서 총에 맞았습니다.',
       'the last trench는 지나온 참호 위치이며 별도의 과거 참호전을 뜻하지 않음.')
change('loc_past_sergeant_a__story_echo_morrow_03_c_01',
       '죽음이다. 그게 전부야.',
       'Pure and simple은 단순하다는 성질 설명이 아닌 앞말을 강조하는 관용 표현.')
change('loc_past_sergeant_a__story_echo_morrow_03_f_01',
       '좋아, 가망 없는 놈들아! 무기를 들어라! 놈을 쓰러뜨려! [라스건 사격 소리]',
       'All right를 체념의 할 수 없지에서 전투를 독려하는 말로 수정. 기존 라스건 표기 유지.')
change('loc_pilot_a__mission_strain_mid_event_conversation_three_b_02',
       '걱정할 것 없어. 정보에 따르면 이 변종은 아직 전염되지 않는대.',
       'this strain과 not yet의 아직이라는 제한을 복원.')

def paired_dialogue(archetype, personality, suffix, text, reason):
    # Only these exact male/female pairs, read together with both existing outputs.
    for gender in ('female', 'male'):
        change(f'loc_{archetype}_{gender}_{personality}__mission_strain_mid_event_conversation_{suffix}',
               text, reason, '같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.')

paired_dialogue('psyker', 'a', 'two_a_01',
                '병원체에 관해 들은 게 거의 없다는 게 신경 쓰이는군.',
                '병원체 얘기 자체가 아니라 제공받은 정보가 적다는 불만을 복원.')
paired_dialogue('psyker', 'a', 'two_a_02',
                "우리 '고용주'가 병원체의 정체를 좀 덜 숨겼으면 좋겠군...",
                'less secretive를 덜 말해 달라는 반대 뜻으로 옮긴 오류 수정.')
paired_dialogue('psyker', 'a', 'two_c_01',
                '멋져라. 우리가 곧 녹아내릴 것 같으면 꼭 알려줘, 알겠지?',
                '액체될이라는 비문을 녹아내릴로 수정하고 비꼬는 어조 유지.')
paired_dialogue('psyker', 'b', 'two_a_02',
                '분명 내가 꿈을 꿔서 이 병원체를 만들어냈을 텐데, 정작 아는 게 없네.',
                'dreamed into being의 꿈으로 존재를 만들어냈다는 의미를 복원. 단순히 관련 꿈을 꿨다는 뜻이 아님.')
paired_dialogue('psyker', 'b', 'two_c_01',
                '아... 설명을 들어도 별로 알겠는 게 없네.',
                'any the wiser는 설명을 듣고도 이해가 나아지지 않았다는 의미.')
paired_dialogue('psyker', 'c', 'three_a_02',
                '우리의 감염을 막을 예방 조치가 마련되어 있는지 확인해 줘.',
                'confirm precautions have been taken의 확인 요청을 자연스러운 문장으로 정리.')
paired_dialogue('psyker', 'c', 'three_c_01',
                '그 말은 좀 안심이 되는군.',
                'somewhat을 아주로 강화한 오류 수정.')
paired_dialogue('veteran', 'a', 'two_c_01',
                '황제 폐하, 저희를 지켜주소서!',
                '보호를 비는 기원문을 사실 진술로 옮긴 오류 수정.')
paired_dialogue('veteran', 'b', 'three_c_01',
                '이질로 설사를 쏟아내기 시작하면 참 위로도 되겠군.',
                'projectile dysentery는 격렬한 설사를 비유한 표현이며 발사형 병원균이 아님. 빈정대는 어조 유지.')
paired_dialogue('veteran', 'b', 'two_c_02',
                '오, 악몽에나 나올 얘기잖아!',
                'stuff of nightmares의 관용적 의미를 복원. 실제 악몽 물질이라는 뜻이 아님.')
paired_dialogue('veteran', 'c', 'two_a_01',
                '이 병원체는 어떤 성질을 지녔지?',
                '병원체라는 단어의 뜻이 아닌 해당 병원체의 성질을 묻는 질문으로 수정.')
paired_dialogue('zealot', 'c', 'three_a_01',
                '이... 병원체가 어떻게 퍼지는지는 알고 있나?',
                '전파를 알아채는 방법이 아닌 전파 경로를 묻는 질문으로 수정.')
paired_dialogue('zealot', 'c', 'three_a_02',
                '이... 전염병의 증상이 뭐지? 혹시 나 말고도 열이 나는 사람 있나?',
                'feel warm을 주변이 따뜻하다는 뜻이 아닌 감염을 걱정하는 맥락의 열감으로 옮김.')
