# TEST3 변경 기록

원작: Polarmingo / DARKS0UND · 후속: 송신 · 검토 지원: Codex

TEST2 이후 변경만 기록합니다. 실제 게임 검증은 미실시입니다.

## loc_achievement_broker_enemies_hit_by_flash_grenade_name

**영문**

Blinding!

**변경 전 기본 / 커스텀**

실명 ({tier})!

(두 모드 동일)

**변경 후**

실명!

**이유:** 영문에 없는 {tier} 변수를 제거하여 미치환 변수가 표시될 위험을 해소.

## loc_achievement_broker_enemies_killed_by_missile_launcher_name

**영문**

Bring the Boom

**변경 전 기본 / 커스텀**

폭탄 투하 ({tier})

(두 모드 동일)

**변경 후**

폭탄 투하

**이유:** 영문에 없는 {tier} 변수를 제거. 기존 한국어 제목은 유지.

## loc_achievement_cryptic_hacking_solves_description

**영문**

Using the Servo-Skull, automate the Data Interrogation events on the following missions:

**변경 전 기본 / 커스텀**

서보 스컬을 사용하여 다음 레벨에서 데이터 심문 이벤트를 자동화하십시오.

(두 모드 동일)

**변경 후**

서보 스컬을 사용하여 다음 임무에서 데이터 심문 이벤트를 자동화하십시오.

**이유:** missions를 레벨이 아닌 임무로 수정.

## loc_achievement_cryptic_medicae_saves_description

**영문**

Using the Medicae Servo-Skull, save an Ally from the following states:

**변경 전 기본 / 커스텀**

약 서보 스컬을 사용하여 다음 상태에 빠진 아군을 구출하십시오.

(두 모드 동일)

**변경 후**

의료 서보 스컬을 사용하여 다음 상태에 빠진 아군을 구출하십시오.

**이유:** 의료 서보 스컬의 수정된 능력명과 고행의 참조 이름을 일치시킴.

## loc_character_backstory_snippet_cryptic

**영문**

Your service to the Omnissiah now brings you to Atoma and the exalted status of Skitarii Alpha Primus. Your newly enhanced combat doctrines and augmetic upgrades may be your only hope of survival in the meatgrinder of Tertium Hive. As part of Grendyl's ever-expanding warband, you will protect the interests of the Adeptus Mechanicus and rid this world of the shadow under which it has fallen.

**변경 전 기본 / 커스텀**

당신은 옴니시아를 섬기며 아토마에 당도했고, 이곳에서 스키타리 알파 프리무스라는 놀라운 지위에 올랐습니다. 어쩌면 테르티움 하이브의 도살장에서 살아남기 위해서는 이들의 새롭게 강화된 전투 교리와 이식물 업그레이드가 필수일지도 모릅니다. 그렌딜이 계속 키워나가고 있는 워밴드에서 당신은 어뎁투스 메카니쿠스의 뜻을 수호하고, 이 행성을 뒤덮고 있는 그림자를 몰아내야 합니다.

(두 모드 동일)

**변경 후**

옴니시아를 섬겨 온 당신은 이제 아토마에 이르러 스키타리 알파 프리무스라는 영예로운 지위에 올랐습니다. 새롭게 강화된 전투 교리와 개량된 이식물만이 테르티움 하이브의 도살장에서 살아남을 유일한 희망일지도 모릅니다. 계속해서 세력을 넓히는 그렌딜의 워밴드에서 당신은 어뎁투스 메카니쿠스의 이익을 수호하고, 이 행성을 뒤덮은 어둠을 걷어낼 것입니다.

**이유:** your를 이들의로 옮긴 주체 오류와 exalted status의 의미를 바로잡고 생존의 유일한 희망이라는 원문 한정 표현을 복원.

## loc_class_cryptic_description

**영문**

The Skitarii Alpha Primus are veteran Skitarii warriors, upgraded and enhanced with sacred combat doctrines and advanced tactical cogitators.

**변경 전 기본 / 커스텀**

스키아리 알파 프리무스는 신성한 전투 의식과 뛰어난 전략적 사고로 업그레이드된 더욱 강한 베테랑 스키타리 전사입니다.

(두 모드 동일)

**변경 후**

스키타리 알파 프리무스는 신성한 전투 교리와 첨단 전술 코지테이터로 개조·강화된 베테랑 스키타리 전사입니다.

**이유:** 스키아리 오타, combat doctrines의 의식 오역, tactical cogitators의 전략적 사고 오역을 수정.

## loc_notification_acqusition_failed

**영문**

Acquisition from Commisary failed, please try again.

**변경 전 기본 / 커스텀**

Acquisition from Commisary failed, please try again.

(두 모드 동일)

**변경 후**

보급소에서 구매하지 못했습니다. 다시 시도하세요.

**이유:** 한국어 덤프에 영어로 남은 보급소 구매 실패 안내 번역.

## loc_objective_dm_stockpile_wait_purge_desc

**영문**

Hold of the enemies while the System Purge runs through its cycles.

**변경 전 기본 / 커스텀**

Hold of the enemies while the System Purge runs through its cycles.

(두 모드 동일)

**변경 후**

시스템 정화 절차가 완료될 때까지 적을 막아내세요.

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 지시 번역.

## loc_objective_find_corruptor_desc

**영문**

Destroy the daemonic infestation in the area

**변경 전 기본 / 커스텀**

Destroy the daemonic infestation in the area

(두 모드 동일)

**변경 후**

주변의 데몬 오염을 파괴하세요.

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 지시 번역.

## loc_objective_hm_complex_final_event_running_desc

**영문**

Realign the transmitter to be able to send the message

**변경 전 기본 / 커스텀**

Realign the transmitter to be able to send the message

(두 모드 동일)

**변경 후**

메시지를 전송할 수 있도록 송신기를 재정렬하세요.

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 지시 번역.

## loc_objective_hub_command_central_desc

**영문**

Meet up Morrow and Zola in the strategium

**변경 전 기본 / 커스텀**

Meet up Morrow and Zola in the strategium

(두 모드 동일)

**변경 후**

전략실에서 모로와 졸라를 만나세요.

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 지시 번역.

## loc_objective_survive_desc

**영문**

Hold out and defend the area

**변경 전 기본 / 커스텀**

Hold out and defend the area

(두 모드 동일)

**변경 후**

버티면서 이 구역을 방어하세요.

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 지시 번역.

## loc_objective_survive_header

**영문**

Stand your ground

**변경 전 기본 / 커스텀**

Stand your ground

(두 모드 동일)

**변경 후**

진지를 사수하세요

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 제목 번역.

## loc_objective_zone_scanning_desc

**영문**

Scan objects in the surrounding area using your auspex

**변경 전 기본 / 커스텀**

Scan objects in the surrounding area using your auspex

(두 모드 동일)

**변경 후**

오스펙스를 사용하여 주변 구역의 물체를 스캔하세요.

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 지시 번역.

## loc_objective_zone_scanning_pathogen_desc

**영문**

Scan objects in the surrounding area for pathogen sources using your auspex

**변경 전 기본 / 커스텀**

Scan objects in the surrounding area for pathogen sources using your auspex

(두 모드 동일)

**변경 후**

오스펙스로 주변 구역의 물체를 스캔하여 병원체의 근원지를 찾으세요.

**이유:** 한국어 덤프에 영어로 남은 완결된 임무 지시 번역.

## loc_ogryn_a__mission_strain_mid_event_conversation_three_c_02

**영문**

Do not worry, friends. I protect you from the goo.

**변경 전 기본 / 커스텀**

걱정 마, 친구들. 내가 널 지켜줄게.

(두 모드 동일)

**변경 후**

걱정 마, 친구들. 내가 끈적이한테서 너희를 지켜줄게.

**이유:** 복수의 친구들과 점액으로부터 지키겠다는 대상을 복원.

## loc_ogryn_a__mission_strain_mid_event_conversation_two_c_01

**영문**

So... it is goo. More goo, yes?

**변경 전 기본 / 커스텀**

매우... 끈적하군. 더 끈적해지겠지?

(두 모드 동일)

**변경 후**

그러니까... 끈적이라는 거지. 또 끈적이야, 응?

**이유:** So를 매우로 옮긴 오류와 More goo를 더 끈적해진다는 변화로 옮긴 오류를 수정.

## loc_past_sergeant_a__story_echo_morrow_03_c_01

**영문**

That's death. Pure and simple.

**변경 전 기본 / 커스텀**

죽음이야. 아주 단순하지.

(두 모드 동일)

**변경 후**

죽음이다. 그게 전부야.

**이유:** Pure and simple은 단순하다는 성질 설명이 아닌 앞말을 강조하는 관용 표현.

## loc_past_sergeant_a__story_echo_morrow_03_f_01

**영문**

All right, no-hopers! Weapons up! Bring it down! [Volley of Las Fire]

**변경 전 기본 / 커스텀**

할 수 없지. 가망 없는 놈들아, 무기를 들어라! 놈을 처치한다! [라스건 사격 소리]

(두 모드 동일)

**변경 후**

좋아, 가망 없는 놈들아! 무기를 들어라! 놈을 쓰러뜨려! [라스건 사격 소리]

**이유:** All right를 체념의 할 수 없지에서 전투를 독려하는 말로 수정. 기존 라스건 표기 유지.

## loc_past_young_sergeant_a__story_echo_morrow_02_d_01

**영문**

Dead, ma'am. Copped a round in the last trench.

**변경 전 기본 / 커스텀**

사망했습니다. 저번 참호전 때 총격을 당했습니다.

(두 모드 동일)

**변경 후**

사망했습니다. 직전 참호에서 총에 맞았습니다.

**이유:** the last trench는 지나온 참호 위치이며 별도의 과거 참호전을 뜻하지 않음.

## loc_penance_grid_show_all

**영문**

Show all penances

**변경 전 기본 / 커스텀**

Show all penances

(두 모드 동일)

**변경 후**

모든 고행 표시

**이유:** 한국어 덤프에 영어로 남은 필터 이름 번역.

## loc_penance_grid_show_completed

**영문**

Show completed penances

**변경 전 기본 / 커스텀**

Show completed penances

(두 모드 동일)

**변경 후**

완료한 고행 표시

**이유:** 한국어 덤프에 영어로 남은 필터 이름 번역.

## loc_penance_grid_show_uncompleted

**영문**

Show uncompleted penances

**변경 전 기본 / 커스텀**

Show uncompleted penances

(두 모드 동일)

**변경 후**

미완료 고행 표시

**이유:** 한국어 덤프에 영어로 남은 필터 이름 번역.

## loc_pickup_breaching_charge

**영문**

Breaching Charge

**변경 전 기본 / 커스텀**

Breaching Charge

(두 모드 동일)

**변경 후**

돌파용 폭약

**이유:** 한국어 덤프에 영어로 남은 습득물 이름 번역.

## loc_pilot_a__mission_strain_mid_event_conversation_three_b_02

**영문**

I wouldn't worry about it. Intel says this strain is not yet transmissible.

**변경 전 기본 / 커스텀**

신경 쓰지 마. 정보에 의하면 이건 전파는 안 된다고 하니까.

(두 모드 동일)

**변경 후**

걱정할 것 없어. 정보에 따르면 이 변종은 아직 전염되지 않는대.

**이유:** this strain과 not yet의 아직이라는 제한을 복원.

## loc_premium_currency_purchase_error_generic

**영문**

Purchasing premium currency has failed due to an unknown error.

If your payment method has been charged please contact support.

**변경 전 기본 / 커스텀**

Purchasing premium currency has failed due to an unknown error.

If your payment method has been charged please contact support.

(두 모드 동일)

**변경 후**

알 수 없는 오류로 유료 화폐를 구매하지 못했습니다.

결제가 청구되었다면 고객 지원에 문의하세요.

**이유:** 한국어 덤프에 영어로 남은 구매 실패 안내 번역.

## loc_psyker_female_a__mission_strain_mid_event_conversation_two_a_01

**영문**

I cannot help but notice we've been told little about the pathogen.

**변경 전 기본 / 커스텀**

병원균 얘기가 나온 게 자꾸 신경이 쓰이는데.

(두 모드 동일)

**변경 후**

병원체에 관해 들은 게 거의 없다는 게 신경 쓰이는군.

**이유:** 병원체 얘기 자체가 아니라 제공받은 정보가 적다는 불만을 복원.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_female_a__mission_strain_mid_event_conversation_two_a_02

**영문**

I wish our 'employer' was less secretive about the pathogen's nature ...

**변경 전 기본 / 커스텀**

우리 '고용주'가 병원균에 대해 좀 덜 말해줬으면 좋았을 텐데...

(두 모드 동일)

**변경 후**

우리 '고용주'가 병원체의 정체를 좀 덜 숨겼으면 좋겠군...

**이유:** less secretive를 덜 말해 달라는 반대 뜻으로 옮긴 오류 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_female_a__mission_strain_mid_event_conversation_two_c_01

**영문**

Splendid. You will warn us if we're about to liquify, won't you?

**변경 전 기본 / 커스텀**

멋져라. 우리가 곧 액체될 것 같으면 꼭 알려줘, 알겠지?

(두 모드 동일)

**변경 후**

멋져라. 우리가 곧 녹아내릴 것 같으면 꼭 알려줘, 알겠지?

**이유:** 액체될이라는 비문을 녹아내릴로 수정하고 비꼬는 어조 유지.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_female_b__mission_strain_mid_event_conversation_two_a_02

**영문**

I'm sure I must have dreamed this pathogen into being, but I know nothing about it.

**변경 전 기본 / 커스텀**

분명 이 병원균의 꿈을 꾼 적이 있을 텐데, 기억이 안 나네.

(두 모드 동일)

**변경 후**

분명 내가 꿈을 꿔서 이 병원체를 만들어냈을 텐데, 정작 아는 게 없네.

**이유:** dreamed into being의 꿈으로 존재를 만들어냈다는 의미를 복원. 단순히 관련 꿈을 꿨다는 뜻이 아님.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_female_b__mission_strain_mid_event_conversation_two_c_01

**영문**

Oh ... I'm not really sure I'm any the wiser.

**변경 전 기본 / 커스텀**

아... 나라고 뭐 더 아는 건 아닌데.

(두 모드 동일)

**변경 후**

아... 설명을 들어도 별로 알겠는 게 없네.

**이유:** any the wiser는 설명을 듣고도 이해가 나아지지 않았다는 의미.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_female_c__mission_strain_mid_event_conversation_three_a_02

**영문**

Please confirm precautions have been taken to prevent us getting infected?

**변경 전 기본 / 커스텀**

우리가 감염되지 않기 위한 사전 예방책이 있는지 확인 요청 바라겠어.

(두 모드 동일)

**변경 후**

우리의 감염을 막을 예방 조치가 마련되어 있는지 확인해 줘.

**이유:** confirm precautions have been taken의 확인 요청을 자연스러운 문장으로 정리.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_female_c__mission_strain_mid_event_conversation_three_c_01

**영문**

That is somewhat reassuring.

**변경 전 기본 / 커스텀**

아주 안심이 되는걸.

(두 모드 동일)

**변경 후**

그 말은 좀 안심이 되는군.

**이유:** somewhat을 아주로 강화한 오류 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_male_a__mission_strain_mid_event_conversation_two_a_01

**영문**

I cannot help but notice we've been told little about the pathogen.

**변경 전 기본 / 커스텀**

병원균 얘기가 나온 게 자꾸 신경이 쓰이는데.

(두 모드 동일)

**변경 후**

병원체에 관해 들은 게 거의 없다는 게 신경 쓰이는군.

**이유:** 병원체 얘기 자체가 아니라 제공받은 정보가 적다는 불만을 복원.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_male_a__mission_strain_mid_event_conversation_two_a_02

**영문**

I wish our 'employer' was less secretive about the pathogen's nature ...

**변경 전 기본 / 커스텀**

우리 '고용주'가 병원균에 대해 좀 덜 말해줬으면 좋았을 텐데...

(두 모드 동일)

**변경 후**

우리 '고용주'가 병원체의 정체를 좀 덜 숨겼으면 좋겠군...

**이유:** less secretive를 덜 말해 달라는 반대 뜻으로 옮긴 오류 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_male_a__mission_strain_mid_event_conversation_two_c_01

**영문**

Splendid. You will warn us if we're about to liquify, won't you?

**변경 전 기본 / 커스텀**

멋져라. 우리가 곧 액체될 것 같으면 꼭 알려줘, 알겠지?

(두 모드 동일)

**변경 후**

멋져라. 우리가 곧 녹아내릴 것 같으면 꼭 알려줘, 알겠지?

**이유:** 액체될이라는 비문을 녹아내릴로 수정하고 비꼬는 어조 유지.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_male_b__mission_strain_mid_event_conversation_two_a_02

**영문**

I'm sure I must have dreamed this pathogen into being, but I know nothing about it.

**변경 전 기본 / 커스텀**

분명 이 병원균의 꿈을 꾼 적이 있을 텐데, 기억이 안 나네.

(두 모드 동일)

**변경 후**

분명 내가 꿈을 꿔서 이 병원체를 만들어냈을 텐데, 정작 아는 게 없네.

**이유:** dreamed into being의 꿈으로 존재를 만들어냈다는 의미를 복원. 단순히 관련 꿈을 꿨다는 뜻이 아님.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_male_b__mission_strain_mid_event_conversation_two_c_01

**영문**

Oh ... I'm not really sure I'm any the wiser.

**변경 전 기본 / 커스텀**

아... 나라고 뭐 더 아는 건 아닌데.

(두 모드 동일)

**변경 후**

아... 설명을 들어도 별로 알겠는 게 없네.

**이유:** any the wiser는 설명을 듣고도 이해가 나아지지 않았다는 의미.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_male_c__mission_strain_mid_event_conversation_three_a_02

**영문**

Please confirm precautions have been taken to prevent us getting infected?

**변경 전 기본 / 커스텀**

우리가 감염되지 않기 위한 사전 예방책이 있는지 확인 요청 바라겠어.

(두 모드 동일)

**변경 후**

우리의 감염을 막을 예방 조치가 마련되어 있는지 확인해 줘.

**이유:** confirm precautions have been taken의 확인 요청을 자연스러운 문장으로 정리.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_psyker_male_c__mission_strain_mid_event_conversation_three_c_01

**영문**

That is somewhat reassuring.

**변경 전 기본 / 커스텀**

아주 안심이 되는걸.

(두 모드 동일)

**변경 후**

그 말은 좀 안심이 되는군.

**이유:** somewhat을 아주로 강화한 오류 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_setting_dlss_model_neural_network

**영문**

Convolutional Neural Network

**변경 전 기본 / 커스텀**

Convolutional Neural Network

(두 모드 동일)

**변경 후**

합성곱 신경망

**이유:** 기술 이름의 뜻을 번역. 모델 동작 설명은 추가하지 않음.

## loc_setting_resolution_custom

**영문**

Custom

**변경 전 기본 / 커스텀**

Custom

(두 모드 동일)

**변경 후**

사용자 지정

**이유:** 한국어 덤프에 영어로 남은 해상도 옵션 번역.

## loc_stolen_rations_destroyed_stat_name

**영문**

Destroyed rations: {value}

**변경 전 기본 / 커스텀**

Destroyed rations: {value}

(두 모드 동일)

**변경 후**

파괴한 식량: {value}

**이유:** 한국어 덤프에 영어로 남은 임무 통계 번역. 변수 보존.

## loc_stolen_rations_recovered_stat_name

**영문**

Recovered rations: {value}

**변경 전 기본 / 커스텀**

Recovered rations: {value}

(두 모드 동일)

**변경 후**

회수한 식량: {value}

**이유:** 한국어 덤프에 영어로 남은 임무 통계 번역. 변수 보존.

## loc_talent_cryptic_afflicted_increased_damage_desc

**영문**

{damage:%s} Damage for {duration:%s}s when hitting an Electrocuted, Soulblazed, Burning, Bleeding, or Toxin afflicted enemy with a Melee or Ranged attack.

**변경 전 기본 / 커스텀**

근접 또는 원거리 공격으로 감전, 소울블레이즈, 화상, 출혈, 중독 상태인 적을 명중시키면 {duration:%s}초 동안 대미지가 {damage:%s} 증가합니다.

(두 모드 동일)

**변경 후**

근접 또는 원거리 공격으로 감전, 소울블레이즈, 화상, 출혈 또는 중독 상태인 적을 맞히면 {duration:%s}초 동안 대미지가 {damage:%s} 증가합니다.

**이유:** 열거한 상태 중 하나만 충족하면 되는 OR 조건을 명시.

## loc_talent_cryptic_ally_coherency_defenses_desc

**영문**

When you or an Ally in Coherency take toughness damage, they restore {stamina:%s} Stamina. {stamina_cd:%s}s Cooldown.
When you or an Ally in Coherency take health damage, they restore {toughness:%s} Toughness. {toughness_cd:%s}s Cooldown.

**변경 전 기본 / 커스텀**

자신 또는 단결 내의 아군이 강인도 피해를 받으면 스태미나를 {stamina:%s} 회복합니다. 쿨다운은 {stamina_cd:%s}초입니다.
자신 또는 단결 내의 아군이 체력 피해를 받으면 강인함을 {toughness:%s} 회복합니다. 쿨다운은 {toughness_cd:%s}초입니다.

(두 모드 동일)

**변경 후**

자신 또는 단결 내 아군이 강인함 대미지를 받으면, 대미지를 받은 대상의 스태미나가 {stamina:%s} 회복됩니다. 쿨다운은 {stamina_cd:%s}초입니다.
자신 또는 단결 내 아군이 체력 대미지를 받으면, 대미지를 받은 대상의 강인함이 {toughness:%s} 회복됩니다. 쿨다운은 {toughness_cd:%s}초입니다.

**이유:** 회복 대상을 대미지를 받은 당사자로 명시하고 Toughness를 기존 모드의 강인함으로 통일.

**대조 근거:** cryptic_buff_templates.lua: cryptic_ally_coherency_defenses_stamina/toughness는 params.attacked_unit을 회복시킨다.

## loc_talent_cryptic_ammo_reserve_desc

**영문**

 {ammo:%s} Ammo Reserve.

**변경 전 기본 / 커스텀**

 탄약 보유량이 {ammo:%s} 증가합니다.

(두 모드 동일)

**변경 후**

탄약 보유량이 {ammo:%s} 증가합니다.

**이유:** 문장 앞의 불필요한 공백 제거.

## loc_talent_cryptic_arc_grenades_capacitance_gain_desc

**영문**

Throw an Arc Grenade, creating an electrical explosion that Arcs {number:%s} times, prioritising Armoured and Specialist Enemies, dealing massive damage and Impact. For each Elite or Specialist enemy killed by the Arc Grenade, generate {capacitance:%s} {capacitance_keyword:%s}.

**변경 전 기본 / 커스텀**

아크 수류탄을 던져 전기 폭발을 일으킵니다. 폭발은 {number:%s}회 연쇄되며, 장갑 적과 특수 적을 우선적으로 타격하여 막대한 피해와 충격을 가합니다. 아크 수류탄으로 엘리트 적 또는 특수 적을 처치할 때마다 {capacitance:%s}{capacitance_keyword:%s}를 생성합니다.

(두 모드 동일)

**변경 후**

아크 수류탄을 던져 전기 폭발을 일으킵니다. 폭발은 {number:%s}회 연쇄되며, 장갑 적과 스페셜리스트를 우선적으로 타격하여 막대한 대미지와 충격을 가합니다. 아크 수류탄으로 엘리트 또는 스페셜리스트를 처치할 때마다 {capacitance_keyword:%s}을 {capacitance:%s} 생성합니다.

**이유:** Specialist를 기존 모드의 스페셜리스트로 통일하고 정전용량의 수치·조사를 정리.

## loc_talent_cryptic_better_heavies_desc

**영문**

Uninterruptible while charging melee attacks. Gain {damage:%s} Heavy Melee Damage.

**변경 전 기본 / 커스텀**

근접 공격을 충전하는 동안 방해받지 않습니다. 강한 공격 근접 대미지가 {damage:%s} 증가합니다.

(두 모드 동일)

**변경 후**

근접 공격을 충전하는 동안 방해받지 않습니다. 근접 강한 공격의 대미지가 {damage:%s} 증가합니다.

**이유:** Heavy Melee Damage의 수식 관계를 명확히 정리.

## loc_talent_cryptic_crits_grant_power_desc

**영문**

Critical hits generate {power:%s} {capacitance_keyword:%s} over {duration:%s}s.

**변경 전 기본 / 커스텀**

치명타 적중 시 {duration:%s}초에 걸쳐 {power:%s}{capacitance_keyword:%s} 생성합니다.

(두 모드 동일)

**변경 후**

치명타 적중 시 {duration:%s}초에 걸쳐 {capacitance_keyword:%s}을 {power:%s} 생성합니다.

**이유:** 누락된 목적격 조사와 정전용량 수치의 띄어쓰기 수정.

## loc_talent_cryptic_crits_grant_tdr_desc

**영문**

Critical hits restore {toughness:%s} Toughness and grant {tdr:%s} Toughness Damage Reduction over {duration:%s}s.

**변경 전 기본 / 커스텀**

치명타 적중 시 강인함을 {toughness:%s} 회복하고 {duration:%s}초에 걸쳐 강인함 대미지 감소를 {tdr:%s} 얻습니다.

(두 모드 동일)

**변경 후**

치명타 적중 시 {duration:%s}초 동안 강인함을 총 {toughness:%s} 회복하며, 강인함 대미지 감소율이 {tdr:%s} 증가합니다.

**이유:** 강인함은 지속 회복되고 대미지 감소 효과는 같은 시간 동안 유지됨을 명확히 설명.

**대조 근거:** cryptic_buff_templates.lua: cryptic_crits_grant_tdr는 _toughness_regen_over_time_on_proc_generator를 사용하며 toughness_regen_per_second = toughness_restored / duration, proc_stat_buffs로 대미지 감소를 부여한다. 코드 스냅샷은 현재 실행 파일 자체가 아니므로 게임 내 확인은 별도.

## loc_talent_cryptic_disabled_allies_defense_post_boost_desc

**영문**

When an Ally in Coherency is Incapacitated, they have {damage_resistance:%s} Damage Resistance until freed. If you free them, they gain Stun Immunity and {damage_resistance_post:%s} Damage Resistance for {duration:%s}s.

**변경 전 기본 / 커스텀**

단결 내 아군이 무력화되었을 때, 풀려날 때까지 대상에게 대미지 저항을 {damage_resistance:%s} 부여합니다. 해당 아군을 구출하면 기절 면역을 얻으며, {duration:%s}초 동안 대미지 저항을 {damage_resistance_post:%s} 얻습니다.

(두 모드 동일)

**변경 후**

단결 내 아군이 무력화되면 구출될 때까지 해당 아군의 대미지 저항이 {damage_resistance:%s} 증가합니다. 자신이 직접 구출하면 해당 아군은 {duration:%s}초 동안 기절 면역을 얻고 대미지 저항이 {damage_resistance_post:%s} 증가합니다.

**이유:** 직접 구출해야 하는 추가 효과의 조건과 혜택을 받는 아군을 명시.

## loc_talent_cryptic_discharge_arc_bonus_desc

**영문**

When using {ability_name:%s}, you release {num_arcs:%s} forward-facing Arcs per Charge spent. Each deals high damage and Impact.

**변경 전 기본 / 커스텀**

{ability_name:%s} 사용 시, 소비한 충전 하나당 전방으로 아크를 {num_arcs:%s}개 방출합니다. 각각 높은 대미지를 주고 비틀거리게 합니다.

(두 모드 동일)

**변경 후**

{ability_name:%s} 사용 시 소비한 충전 하나당 전방으로 아크를 {num_arcs:%s}개 방출합니다. 각 아크는 높은 대미지와 충격을 가합니다.

**이유:** Impact를 확정 비틀거림 효과로 단정하지 않고 기존 능력치 용어인 충격으로 표기.

## loc_talent_cryptic_discharge_desc

**영문**

Unleash an Electric Discharge around you. Enemies within {range:%s}m are Electrocuted for {duration:%s}s, Stunning them and dealing damage.

When using {talent_name:%s} at {charge_two:%s} charges or above, Ranged Enemies, within {far_range:%s}m, have their weapons Malfunction for {malfunction_duration:%s}s.

When using {talent_name:%s} at {charge_three:%s} charges or above, for the next {buff_duration:%s}s your attacks Electrocute enemies hit for {short_duration:%s}s, dealing damage.

This is an enhanced version of the Voltaic Expander ability.

**변경 전 기본 / 커스텀**

주위에 전류 방출을 일으킵니다. {range:%s}m 내의 적은 {duration:%s}초 동안 감전되어 기절하고 대미지를 받습니다.

{talent_name:%s} 기술을 {charge_two:%s} 충전 이상에서 사용하면 {far_range:%s}m 내에 있는 원거리 적의 무기가 {malfunction_duration:%s}초 동안 고장 납니다.

{talent_name:%s} 기술을 {charge_three:%s} 충전 이상에서 사용하면 다음 {buff_duration:%s}초 동안 공격에 맞은 적이 {short_duration:%s}초 동안 감전되어 대미지를 받습니다.

전기 익스팬더 능력의 강화판입니다.

(두 모드 동일)

**변경 후**

주위에 전류 방출을 일으킵니다. {range:%s}미터 내의 적은 {duration:%s}초 동안 감전되어 기절하고 대미지를 받습니다.

충전이 {charge_two:%s}개 이상일 때 {talent_name:%s}을 사용하면 {far_range:%s}미터 내 원거리 적의 무기가 {malfunction_duration:%s}초 동안 고장 납니다.

충전이 {charge_three:%s}개 이상일 때 {talent_name:%s}을 사용하면, 이후 {buff_duration:%s}초 동안 자신의 공격이 적을 {short_duration:%s}초 동안 감전시켜 대미지를 줍니다.

전류 확장기 능력의 강화판입니다.

**이유:** Voltaic Expander의 실제 능력명인 전류 확장기와 참조 이름을 일치시키고 충전 조건을 정리.

## loc_talent_cryptic_dissector_desc

**영문**

You have up to {max_stacks:%s} stacks of {talent_name:%s}. Each stack grants {damage:%s} Damage and {tdr:%s} Toughness Damage Reduction.

Taking damage removes {removed_stacks:%s} stack(s). Can only occur once every {icd:%s}s. Elite and Specialist kills restore {elite_special_stack:%s} stack(s), and restore {toughness:%s} Toughness.

**변경 전 기본 / 커스텀**

{talent_name:%s} 기술 중첩을 최대 {max_stacks:%s}회까지 가질 수 있습니다. 각 중첩은 대미지를 {damage:%s} 증가시키고, 강인함 대미지 감소를 {tdr:%s} 부여합니다.

대미지를 받으면 중첩이 {removed_stacks:%s}회 제거됩니다. {icd:%s}초마다 한 번씩만 발생합니다. 엘리트 및 전문가 처치 시 중첩이 {elite_special_stack:%s}회 회복되고 강인함이 {toughness:%s} 회복됩니다.

(두 모드 동일)

**변경 후**

{talent_name:%s} 중첩을 최대 {max_stacks:%s}회까지 보유할 수 있습니다. 각 중첩은 대미지를 {damage:%s} 증가시키고 강인함 대미지 감소를 {tdr:%s} 부여합니다.

대미지를 받으면 중첩이 {removed_stacks:%s}회 제거됩니다. 이 효과는 {icd:%s}초마다 한 번씩만 발생합니다. 엘리트 또는 스페셜리스트를 처치하면 중첩이 {elite_special_stack:%s}회 회복되고 강인함이 {toughness:%s} 회복됩니다.

**이유:** Specialist의 전문가 오역을 스페셜리스트로 수정하고 개별 처치 조건을 분명히 표시.

## loc_talent_cryptic_dissector_power_desc

**영문**

Elite and Specialist kills restore an additional {power:%s} {capacitance_keyword:%s}.

**변경 전 기본 / 커스텀**

엘리트 및 전문가 처치 시 추가로 {power:%s}{capacitance_keyword:%s} 회복합니다.

(두 모드 동일)

**변경 후**

엘리트 또는 스페셜리스트를 처치하면 {capacitance_keyword:%s}을 추가로 {power:%s} 회복합니다.

**이유:** Specialist 용어와 목적격 조사를 수정.

## loc_talent_cryptic_increased_passive_cooldown_regen_desc

**영문**

Generate {power:%s} {capacitance_keyword:%s} each second.

**변경 전 기본 / 커스텀**

매초 {power:%s}{capacitance_keyword:%s}을(를) 생성합니다.

(두 모드 동일)

**변경 후**

매초 {capacitance_keyword:%s}을 {power:%s} 생성합니다.

**이유:** 자원 이름과 수치가 붙는 표기를 정리.

## loc_talent_cryptic_melee_cleave_and_impact_desc

**영문**

Gain {cleave:%s} Melee Cleave while above {toughness:%s} Toughness and {impact:%s} Melee Impact while below.

**변경 전 기본 / 커스텀**

강인함이 {toughness:%s} 이상일 때는 근접 쪼개기를 {cleave:%s} 얻고, 그 미만일 때는 근접 충격을 {impact:%s} 얻습니다.

(두 모드 동일)

**변경 후**

강인함이 {toughness:%s}를 초과하면 근접 쪼개기가 {cleave:%s} 증가하고, 그 이하이면 근접 충격이 {impact:%s} 증가합니다.

**이유:** 경계값 조건을 이상/미만에서 초과/이하로 수정.

**대조 근거:** 영문 above 및 cryptic_buff_templates.lua의 cryptic_cleave_while_above_stamina_threshold: current_toughness_percent > threshold, cryptic_impact_while_below_stamina_threshold: <= threshold를 대조. 실행 중인 게임에서 경계값 확인은 별도.

## loc_talent_cryptic_multi_hits_grant_power_desc

**영문**

Hitting {number:%s} or more enemies with an Attack restores {power:%s} {capacitance_keyword:%s}.

**변경 전 기본 / 커스텀**

공격으로 {number:%s}명 이상의 적을 명중하면 {power:%s}{capacitance_keyword:%s} 회복합니다.

(두 모드 동일)

**변경 후**

한 번의 공격으로 적을 {number:%s}명 이상 맞히면 {capacitance_keyword:%s}을 {power:%s} 회복합니다.

**이유:** 한 번의 공격이라는 발동 단위와 누락된 조사를 명확히 표기.

## loc_talent_cryptic_multi_hits_restore_toughness_desc

**영문**

Hitting {number:%s} or more enemies with an Attack restores {toughness:%s} Toughness over {duration:%s}s.

**변경 전 기본 / 커스텀**

공격으로 {number:%s}명 이상의 적을 명중하면 {duration:%s}초에 걸쳐 강인함을 {toughness:%s} 회복합니다.

(두 모드 동일)

**변경 후**

한 번의 공격으로 적을 {number:%s}명 이상 맞히면 {duration:%s}초에 걸쳐 강인함을 {toughness:%s} 회복합니다.

**이유:** 여러 공격의 누적 타격 수로 오해하지 않도록 한 번의 공격 조건을 명시.

## loc_talent_cryptic_no_braced_movement_penalty_desc

**영문**

{movement_speed_modifier:%s} movement speed penalty while bracing or aiming down sights. Additionally, you gain {spread:%s} Spread.

**변경 전 기본 / 커스텀**

버팀대 또는 조준 사격 시 이동 속도 페널티가 {movement_speed_modifier:%s} 수치가 됩니다. 추가로, 탄 분산이 {spread:%s} 감소합니다.

(두 모드 동일)

**변경 후**

지향 사격 또는 정조준 중 이동 속도 페널티: {movement_speed_modifier:%s}
탄 분산: {spread:%s}

**이유:** bracing을 버팀대로 번역한 오류를 수정. 부호가 포함된 변수에 감소를 중복 붙이지 않도록 능력치 형식으로 표시.

**대조 근거:** cryptic_talents.lua: movement_speed_modifier는 - 접두사, spread는 signed percentage. talent_settings_cryptic.lua 스냅샷 값으로 -50%, -30% 표시를 확인할 수 있으며 번역에 수치를 고정하지 않는다.

## loc_talent_cryptic_overload_keystone_coherency_desc

**영문**

Kills by you and allies in coherency grant {low_stack:%s} stacks of {talent_name:%s}. Elite and Specialist enemy kills grant {elite_stacks:%s} stacks. Max {max_stacks:%s} stacks. Reaching max stacks causes an overload and reset to {zero:%s} stacks.

The overload grants you and allies in Coherency {damage:%s} Damage and {tdr:%s} Toughness Damage Reduction, for {duration:%s}s.

**변경 전 기본 / 커스텀**

자신 및 단결 내 아군이 처치 시 {talent_name:%s} 기술 중첩을 {low_stack:%s}회 얻습니다. 엘리트 및 전문가 처치 시 {elite_stacks:%s} 얻습니다. 최대 {max_stacks:%s}회 중첩됩니다. 최대 중첩에 도달하면 과부하가 발생하고 중첩이 {zero:%s}회로 초기화됩니다.

과부하 시 {duration:%s}초 동안 자신과 단결 내 아군의 대미지가 {damage:%s} 증가하고 강인함 대미지 감소를 {tdr:%s} 얻습니다.

(두 모드 동일)

**변경 후**

자신 또는 단결 내 아군이 적을 처치하면 {talent_name:%s} 중첩을 {low_stack:%s}회 얻습니다. 엘리트 또는 스페셜리스트를 처치하면 {elite_stacks:%s}회 얻습니다. 최대 {max_stacks:%s}회 중첩됩니다. 최대 중첩에 도달하면 과부하가 발생하고 중첩이 {zero:%s}회로 초기화됩니다.

과부하가 발생하면 {duration:%s}초 동안 자신과 단결 내 아군의 대미지가 {damage:%s} 증가하고 강인함 대미지 감소를 {tdr:%s} 얻습니다.

**이유:** Specialist 용어, 누락된 중첩 단위, 처치 주체를 정리.

## loc_talent_cryptic_passive_cooldown_regen_desc

**영문**

Your Abilities are powered by your {talent_name:%s}.

You have {num_base_charges:%s} Base Charges. Abilities require at least {min_charge:%s} Charge(s) to be activated, and will Spend up to {max_charge:%s} Charge(s), providing additional effects for each Charge.

Generate {power:%s} {capacitance_keyword:%s} each second. At {max_power:%s} {capacitance_keyword:%s} you generate {gained_charges:%s} Charge and the {capacitance_keyword:%s} is reset. You also generate {kill_power:%s} {capacitance_keyword:%s} on Kills, increased to {elite_power:%s} on Elite or Specialist Kill.

**변경 전 기본 / 커스텀**

능력은 {talent_name:%s}에 의해 강화됩니다.

{num_base_charges:%s} 기본 충전을 보유합니다. 능력을 사용하려면 최소 {min_charge:%s} 이상의 충전이 필요하며, 최대 {max_charge:%s} 충전까지 사용하고 충전 단계별로 추가 효과를 줍니다.

매초 {power:%s} {capacitance_keyword:%s}을(를) 생성합니다. {max_power:%s} {capacitance_keyword:%s}에서 {gained_charges:%s} 충전을 생성하며 {capacitance_keyword:%s}은(는) 초기화됩니다. 또한 처치 시 {kill_power:%s}{capacitance_keyword:%s}을(를) 생성하며, 엘리트 또는 전문가 처치 시 {elite_power:%s}까지 증가합니다.

(두 모드 동일)

**변경 후**

능력은 {talent_name:%s}을 동력으로 사용합니다.

기본 충전은 {num_base_charges:%s}개입니다. 능력을 사용하려면 충전이 최소 {min_charge:%s}개 필요하며, 최대 {max_charge:%s}개를 소모합니다. 소모한 충전마다 추가 효과를 얻습니다.

매초 {capacitance_keyword:%s}을 {power:%s} 생성합니다. {capacitance_keyword:%s}이 {max_power:%s}에 도달하면 충전을 {gained_charges:%s}개 얻고 {capacitance_keyword:%s}이 초기화됩니다. 적을 처치할 때도 {capacitance_keyword:%s}을 {kill_power:%s} 생성하며, 엘리트 또는 스페셜리스트 처치 시 생성량이 {elite_power:%s}로 증가합니다.

**이유:** powered by를 단순 강화가 아닌 능력 사용 동력으로 설명하고 충전 수·소모량·생성량의 관계 및 Specialist 용어를 정리.

## loc_talent_cryptic_precision_stance_drain_cost_desc

**영문**

Spend {capacitance_instant:%s} {capacitance_keyword:%s} and Swap to your Secondary Weapon. Your weapon locks onto enemies close to your targeting reticule, granting you inhuman accuracy. You gain {spread:%s} Spread and {recoil:%s} Recoil for its duration.

While active, you drain {capacitance_drain:%s} {capacitance_keyword:%s} per second, and an additional {capacitance_shot:%s} per shot. The drain is paused while reloading.

The Ability is disabled if you switch from your Secondary Weapon, if you reach {zero_capacitance:%s} {capacitance_keyword:%s} and {zero_charges:%s} Charges, or if you reactivate it. Only usable if you have at least {charge_min:%s} Charge available.

No Cooldown.

**변경 전 기본 / 커스텀**

{capacitance_instant:%s} {capacitance_keyword:%s}을 소모하고 보조 무기로 교체합니다. 무기가 조준점 근처의 적을 고정하여 초월적인 명중률을 제공합니다. 지속 시간 동안 분산도 {spread:%s} 및 반동 {recoil:%s}을 획득합니다. 

활성화된 동안 초당 {capacitance_drain:%s} {capacitance_keyword:%s}을 소모하며, 사격당 추가로 {capacitance_shot:%s}을 소모합니다. 재장전 중에는 소모가 일시 중지됩니다.

보조 무기를 해제하거나, {zero_capacitance:%s} {capacitance_keyword:%s} 및 {zero_charges:%s} 충전량에 도달하거나, 능력을 재활성화하면 비활성화됩니다. 최소 {charge_min:%s} 충전량이 있어야 사용 가능합니다.

쿨다운이 없습니다.

(두 모드 동일)

**변경 후**

{capacitance_keyword:%s}을 {capacitance_instant:%s} 소모하고 보조 무기로 전환합니다. 무기가 조준점 근처의 적을 자동으로 조준하여 초인적인 명중률을 제공합니다. 활성화 중 탄 분산 {spread:%s}, 반동 {recoil:%s} 효과를 얻습니다.

활성화 중에는 매초 {capacitance_keyword:%s}을 {capacitance_drain:%s} 소모하며, 사격할 때마다 추가로 {capacitance_shot:%s} 소모합니다. 재장전 중에는 소모가 일시 중지됩니다.

보조 무기에서 다른 무기로 전환하거나, {capacitance_keyword:%s}이 {zero_capacitance:%s}이고 충전이 {zero_charges:%s}개가 되거나, 능력 입력을 다시 누르면 종료됩니다. 충전이 최소 {charge_min:%s}개 있어야 사용할 수 있습니다.

쿨다운은 없습니다.

**이유:** locks onto를 적의 이동을 고정하는 효과로 오해하지 않도록 자동 조준으로 설명. 자원 고갈의 AND 조건과 보조 무기 전환 조건을 명시하고 음수 능력치 변수의 부호를 보존.

## loc_talent_cryptic_precision_stance_fire_rate_increased_desc

**영문**

While {talent_name:%s} is active, gain {fire_rate:%s} Fire Rate, increased to {fire_rate_increased:%s} Fire Rate after {duration:%s}s.

**변경 전 기본 / 커스텀**

{talent_name:%s}이 활성화된 동안 {fire_rate:%s} 발사 속도를 획득하며, {duration:%s}초 후에는 연사 속도가 {fire_rate_increased:%s}로 증가합니다.

(두 모드 동일)

**변경 후**

{talent_name:%s} 활성화 중 연사 속도가 {fire_rate:%s} 증가하며, {duration:%s}초 후에는 증가량이 {fire_rate_increased:%s}로 높아집니다.

**이유:** Fire Rate의 발사 속도/연사 속도 혼용을 통일하고 이후 수치가 증가량임을 명시.

## loc_talent_cryptic_push_stagger_stamina_desc

**영문**

Your Pushes have {push_strength:%s} Impact when at or above {stamina:%s} Stamina.

**변경 전 기본 / 커스텀**

스태미나가 {push_strength:%s} 이상일 때 밀치기의 비틀거림 수치가 {stamina:%s} 증가합니다.

(두 모드 동일)

**변경 후**

스태미나가 {stamina:%s} 이상이면 밀치기의 충격이 {push_strength:%s} 증가합니다.

**이유:** 뒤바뀐 스태미나 조건 변수와 밀치기 충격 변수를 올바른 자리에 배치.

**대조 근거:** 영문 및 cryptic_talents.lua의 format_values: stamina=target_stamina_percent, push_strength=push_impact_modifier; cryptic_buff_templates.lua는 >= 조건.

## loc_talent_cryptic_revive_speed_and_dr_desc

**영문**

Gain {damage_reduction:%s} Damage Resistance while Reviving an Ally. Gain {revive_speed:%s} Revive Speed.

**변경 전 기본 / 커스텀**

아군 부활 중 대미지 저항이 {damage_reduction:%s} 증가합니다. 부활 속도가 {revive_speed:%s} 증가합니다.

(두 모드 동일)

**변경 후**

쓰러진 아군을 소생시키는 동안 대미지 저항이 {damage_reduction:%s} 증가합니다. 소생 속도가 {revive_speed:%s} 증가합니다.

**이유:** Revive를 사망 후 부활과 혼동하지 않도록 쓰러진 아군의 소생으로 설명.

## loc_talent_cryptic_servo_skull_flamethrower_new_desc

**영문**

You have an additional Servo-Skull equipped with a Flamer. Target an Area to deploy it. Use your Primary Action to switch between Dispersed or Focused Fire Mode.

If {flamer_talent:%s} and {medicae_talent:%s} are both selected, you gain {bonus_charge:%s} Charges.

**변경 전 기본 / 커스텀**

플레이머를 장착한 추가 서보스컬을 보유합니다. 대상 위치를 지정해 배치합니다. 기본 액션을 사용해 분산 사격 모드와 집중 사격 모드를 전환합니다.

{flamer_talent:%s}와 {medicae_talent:%s}를 모두 선택했다면 충전 횟수를 {bonus_charge:%s}회 획득합니다.

(두 모드 동일)

**변경 후**

플레이머를 장착한 추가 서보 스컬을 보유합니다. 대상 위치를 지정해 배치합니다. 기본 행동 입력으로 분산 사격과 집중 사격 모드를 전환합니다.

{flamer_talent:%s}와 {medicae_talent:%s}를 모두 선택하면 충전을 {bonus_charge:%s}개 추가로 얻습니다.

**이유:** Servo-Skull 띄어쓰기와 입력 안내를 통일하고 두 재능 선택 시 충전 증가가 추가 혜택임을 명시.

## loc_talent_cryptic_servo_skull_improved

**영문**

Artificer Servo-Skull

**변경 전 기본 / 커스텀**

종자 서보 스컬

(두 모드 동일)

**변경 후**

장인 서보 스컬

**이유:** Artificer를 종자로 옮긴 오류 수정. 장인이라는 제작·기술 의미를 반영.

## loc_talent_cryptic_servo_skull_inject_ally

**영문**

Medicae Servo-Skull

**변경 전 기본 / 커스텀**

약 서보 스컬

(두 모드 동일)

**변경 후**

의료 서보 스컬

**이유:** Medicae의 의료 기능을 반영하여 약 서보 스컬을 수정.

## loc_talent_cryptic_servo_skull_inject_ally_revive_new_desc

**영문**

You have an additional Servo-Skull equipped with Adapted Medicae Syringes. Target a Knocked Down, Hogtied, or Netted Ally to inject them.

The injection Revives them, as well as granting them {tdr:%s} Toughness Damage Reduction and {toughness_per_second:%s} Toughness per second. Lasts for {duration:%s}s.

If {flamer_talent:%s} and {medicae_talent:%s} are both selected, you gain {bonus_charge:%s} Charges.

**변경 전 기본 / 커스텀**

개조한 물약 주사기를 장착한 추가 서보스컬을 보유합니다. 다운되거나 포박되었거나 그물에 걸린 아군을 조준해 주사를 놓습니다.

주사 시 아군이 부활하며, 강인함 피해 감소 {tdr:%s} 및 초당 강인함 {toughness_per_second:%s}를 얻습니다. {duration:%s}초 동안 지속됩니다.

{flamer_talent:%s}와 {medicae_talent:%s}를 모두 선택했다면 충전 횟수를 {bonus_charge:%s}회 획득합니다.

(두 모드 동일)

**변경 후**

개조된 의료용 주사기를 장착한 추가 서보 스컬을 보유합니다. 쓰러졌거나 포박되었거나 그물에 걸린 아군을 조준해 주사합니다.

주사를 맞은 아군은 소생하며, {duration:%s}초 동안 강인함 대미지 감소를 {tdr:%s} 얻고 매초 강인함을 {toughness_per_second:%s} 회복합니다.

{flamer_talent:%s}와 {medicae_talent:%s}를 모두 선택하면 충전을 {bonus_charge:%s}개 추가로 얻습니다.

**이유:** Medicae Syringes의 물약 오역을 의료용 주사기로 수정하고 회복·감소 효과의 지속시간과 충전 증가를 명시.

## loc_talent_cryptic_specials_marking_desc

**영문**

Specialists that get within {range:%s}m of you are Marked.

**변경 전 기본 / 커스텀**

{range:%s}미터 이내에 접근하는 전문가에게 표식을 남깁니다.

(두 모드 동일)

**변경 후**

자신의 {range:%s}미터 이내에 접근한 스페셜리스트에게 표식이 표시됩니다.

**이유:** Specialists를 전문가에서 스페셜리스트로 통일.

## loc_talent_cryptic_stun_dr_power_desc

**영문**

You are Stun Immune and have {damage:%s} Damage Resistance. Taking Melee Damage spends {power:%s} {capacitance_keyword:%s}.

**변경 전 기본 / 커스텀**

기절에 면역이 되며 대미지 저항이 {damage:%s} 증가합니다. 근접 대미지를 받으면 {power:%s}{capacitance_keyword:%s} 소모합니다.

(두 모드 동일)

**변경 후**

기절에 면역이 되며 대미지 저항이 {damage:%s} 증가합니다. 근접 대미지를 받으면 {capacitance_keyword:%s}을 {power:%s} 소모합니다.

**이유:** 누락된 목적격 조사와 자원 수치 표기를 수정.

## loc_talent_cryptic_weakspot_damage

**영문**

Sureshot Cogitator Sync

**변경 전 기본 / 커스텀**

명사수 인지 동기화

(두 모드 동일)

**변경 후**

명사수 코지테이터 동기화

**이유:** Cogitator를 인지로 옮긴 의미 누락을 기존 모드의 코지테이터 용어로 수정.

## loc_talent_cryptic_weakspot_kills_grant_power_desc

**영문**

Weakspot Kills generate {power:%s} {capacitance_keyword:%s}.

**변경 전 기본 / 커스텀**

약점 처치 시 {power:%s}{capacitance_keyword:%s} 생성합니다.

(두 모드 동일)

**변경 후**

약점 공격으로 적을 처치하면 {capacitance_keyword:%s}을 {power:%s} 생성합니다.

**이유:** 누락된 목적격 조사와 자원 수치 표기를 수정.

## loc_talent_max_ammo_low

**영문**

Ammo Reserve Boost

**변경 전 기본 / 커스텀**

Ammo Reserve Boost

(두 모드 동일)

**변경 후**

탄약 보유량 증가

**이유:** 한국어 덤프에 영어로 남은 재능 이름 번역.

## loc_talent_max_ammo_low_desc

**영문**

Increase your Ammo Reserve by {ammo:%s}

**변경 전 기본 / 커스텀**

Increase your Ammo Reserve by {ammo:%s}

(두 모드 동일)

**변경 후**

탄약 보유량이 {ammo:%s} 증가합니다.

**이유:** 한국어 덤프에 영어로 남은 재능 설명 번역. 변수 보존.

## loc_talent_zealot_3_passive_3_description

**영문**

{corruption_reduction:%s} reduced Corruption suffered.

**변경 전 기본 / 커스텀**

받는 부패가 %d%% 감소합니다.

(두 모드 동일)

**변경 후**

받는 부패가 {corruption_reduction:%s} 감소합니다.

**이유:** 예전 printf 자리표시자 %d%%를 현재 영문의 이름 있는 변수로 교체.

## loc_talent_zealot_3_tier_2_ability_3_description

**영문**

{max_hit:%s} Increased Cleave.

**변경 전 기본 / 커스텀**

쪼개기가 %d%% 증가합니다.

(두 모드 동일)

**변경 후**

쪼개기가 {max_hit:%s} 증가합니다.

**이유:** 예전 printf 자리표시자 %d%%를 현재 영문의 이름 있는 변수로 교체.

## loc_tutorial_cryptic_capacitance_desc

**영문**

The Skitarii use Capacitance in order to power their Abilities. Once you've reached 100% Capacitance, you will generate a Charge.
You gain Capacitance passively over time, and by killing enemies.

**변경 전 기본 / 커스텀**

스키타리는 정전용량을 사용하여 능력을 강화합니다. 정전용량이 100%에 도달하면 충전이 하나 생성됩니다.
정전용량은 시간이 지남에 따라 자연적으로 회복되며, 적을 처치해도 얻을 수 있습니다.

(두 모드 동일)

**변경 후**

스키타리는 정전용량을 동력으로 능력을 사용합니다. 정전용량이 100%에 도달하면 충전이 하나 생성됩니다.
정전용량은 시간이 지남에 따라 자동으로 생성되며, 적을 처치해도 얻을 수 있습니다.

**이유:** 정전용량이 능력을 추가 강화하기만 하는 자원처럼 보이지 않도록 사용 동력임을 설명.

## loc_veteran_female_a__mission_strain_mid_event_conversation_two_c_01

**영문**

Emperor protect us!

**변경 전 기본 / 커스텀**

황제 폐하께서 우릴 지켜주신다!

(두 모드 동일)

**변경 후**

황제 폐하, 저희를 지켜주소서!

**이유:** 보호를 비는 기원문을 사실 진술로 옮긴 오류 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_veteran_female_b__mission_strain_mid_event_conversation_three_c_01

**영문**

Fine comfort that'll be once the projectile dysentery kicks in.

**변경 전 기본 / 커스텀**

발사형 이질균이 날아올 생각을 하니 마음이 참 편해지는군.

(두 모드 동일)

**변경 후**

이질로 설사를 쏟아내기 시작하면 참 위로도 되겠군.

**이유:** projectile dysentery는 격렬한 설사를 비유한 표현이며 발사형 병원균이 아님. 빈정대는 어조 유지.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_veteran_female_b__mission_strain_mid_event_conversation_two_c_02

**영문**

Oh, that's the stuff of nightmares, right there!

**변경 전 기본 / 커스텀**

저거야, 저게 그 악몽의 물질이야!

(두 모드 동일)

**변경 후**

오, 악몽에나 나올 얘기잖아!

**이유:** stuff of nightmares의 관용적 의미를 복원. 실제 악몽 물질이라는 뜻이 아님.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_veteran_female_c__mission_strain_mid_event_conversation_two_a_01

**영문**

What's the nature of the pathogen?

**변경 전 기본 / 커스텀**

병원체란 뭐지?

(두 모드 동일)

**변경 후**

이 병원체는 어떤 성질을 지녔지?

**이유:** 병원체라는 단어의 뜻이 아닌 해당 병원체의 성질을 묻는 질문으로 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_veteran_male_a__mission_strain_mid_event_conversation_two_c_01

**영문**

Emperor protect us!

**변경 전 기본 / 커스텀**

황제 폐하께서 우릴 지켜주신다!

(두 모드 동일)

**변경 후**

황제 폐하, 저희를 지켜주소서!

**이유:** 보호를 비는 기원문을 사실 진술로 옮긴 오류 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_veteran_male_b__mission_strain_mid_event_conversation_three_c_01

**영문**

Fine comfort that'll be once the projectile dysentery kicks in.

**변경 전 기본 / 커스텀**

발사형 이질균이 날아올 생각을 하니 마음이 참 편해지는군.

(두 모드 동일)

**변경 후**

이질로 설사를 쏟아내기 시작하면 참 위로도 되겠군.

**이유:** projectile dysentery는 격렬한 설사를 비유한 표현이며 발사형 병원균이 아님. 빈정대는 어조 유지.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_veteran_male_b__mission_strain_mid_event_conversation_two_c_02

**영문**

Oh, that's the stuff of nightmares, right there!

**변경 전 기본 / 커스텀**

저거야, 저게 그 악몽의 물질이야!

(두 모드 동일)

**변경 후**

오, 악몽에나 나올 얘기잖아!

**이유:** stuff of nightmares의 관용적 의미를 복원. 실제 악몽 물질이라는 뜻이 아님.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_veteran_male_c__mission_strain_mid_event_conversation_two_a_01

**영문**

What's the nature of the pathogen?

**변경 전 기본 / 커스텀**

병원체란 뭐지?

(두 모드 동일)

**변경 후**

이 병원체는 어떤 성질을 지녔지?

**이유:** 병원체라는 단어의 뜻이 아닌 해당 병원체의 성질을 묻는 질문으로 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_zealot_female_c__mission_strain_mid_event_conversation_three_a_01

**영문**

Do we know how this... pathogen spreads?

**변경 전 기본 / 커스텀**

이 병원체가 퍼지는 걸... 어떻게 알지?

(두 모드 동일)

**변경 후**

이... 병원체가 어떻게 퍼지는지는 알고 있나?

**이유:** 전파를 알아채는 방법이 아닌 전파 경로를 묻는 질문으로 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_zealot_female_c__mission_strain_mid_event_conversation_three_a_02

**영문**

What are the symptoms of this... contagion? Does anyone else feel warm?

**변경 전 기본 / 커스텀**

이... 오염의 증상은 뭐지? 따뜻하다고 느끼는 사람 없어?

(두 모드 동일)

**변경 후**

이... 전염병의 증상이 뭐지? 혹시 나 말고도 열이 나는 사람 있나?

**이유:** feel warm을 주변이 따뜻하다는 뜻이 아닌 감염을 걱정하는 맥락의 열감으로 옮김.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_zealot_male_c__mission_strain_mid_event_conversation_three_a_01

**영문**

Do we know how this... pathogen spreads?

**변경 전 기본 / 커스텀**

이 병원체가 퍼지는 걸... 어떻게 알지?

(두 모드 동일)

**변경 후**

이... 병원체가 어떻게 퍼지는지는 알고 있나?

**이유:** 전파를 알아채는 방법이 아닌 전파 경로를 묻는 질문으로 수정.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.

## loc_zealot_male_c__mission_strain_mid_event_conversation_three_a_02

**영문**

What are the symptoms of this... contagion? Does anyone else feel warm?

**변경 전 기본 / 커스텀**

이... 오염의 증상은 뭐지? 따뜻하다고 느끼는 사람 없어?

(두 모드 동일)

**변경 후**

이... 전염병의 증상이 뭐지? 혹시 나 말고도 열이 나는 사람 있나?

**이유:** feel warm을 주변이 따뜻하다는 뜻이 아닌 감염을 걱정하는 맥락의 열감으로 옮김.

**대조 근거:** 같은 인물 성격의 남녀 영문과 기존 한국어가 일치하는 대사 쌍을 함께 대조.
