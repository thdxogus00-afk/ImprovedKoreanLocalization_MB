const fs = require('fs');
const path = require('path');
const parser = require('./third_party_luaparse');
const root = path.resolve(__dirname, '../ImprovedKoreanLocalization');
const files = [];
function visit(dir) {
  for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) visit(p);
    else if (/\.(lua|mod)$/.test(p)) files.push(p);
  }
}
visit(root);
for (const file of files) {
  parser.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''), {luaVersion: '5.1'});
}
console.log(JSON.stringify({result:'PASS',lua_51_runtime_files:files.length}));
