"""Validate English/Korean exports and create an evidence-backed review queue.

python tests/compare_exports.py --old-en previous_en.jsonl \
    --en expanded_en.jsonl --ko expanded_ko.jsonl --output review_queue.jsonl
No translation is invented for a missing source or missing Korean lookup.
"""
import argparse
import collections
import json
from pathlib import Path


def read_dump(path):
    with Path(path).open(encoding="utf-8-sig") as stream:
        rows = [json.loads(line) for line in stream if line.strip()]
    if len(rows) < 2 or rows[0].get("record") != "meta" or rows[-1].get("record") != "end":
        raise ValueError(f"{path}: missing header/footer")
    meta, footer = rows[0], rows[-1]
    if meta.get("schema") not in (1, 2):
        raise ValueError(f"{path}: unsupported schema")
    if footer.get("complete") is not True:
        raise ValueError(f"{path}: incomplete export")
    entries, counts = {}, collections.Counter()
    for row in rows[1:-1]:
        key = row.get("key")
        status = row.get("status")
        if row.get("record") != "entry" or not isinstance(key, str) or key in entries:
            raise ValueError(f"{path}: invalid/duplicate entry {key!r}")
        if row.get("language") != meta.get("language") or status not in ("found", "missing", "error"):
            raise ValueError(f"{path}: invalid language/status for {key}")
        if status == "found" and not isinstance(row.get("raw"), str):
            raise ValueError(f"{path}: found entry has no raw text: {key}")
        entries[key] = row
        counts[status] += 1
    total = len(entries)
    if any(obj.get(field) != total for obj, field in
           ((meta, "total"), (footer, "total"), (footer, "processed"))):
        raise ValueError(f"{path}: total count mismatch")
    for field, status in (("found", "found"), ("missing", "missing"), ("errors", "error")):
        if footer.get(field) != counts[status]:
            raise ValueError(f"{path}: {field} count mismatch")
    if counts["error"]:
        raise ValueError(f"{path}: lookup errors present; inspect/re-export before review")
    return meta, entries


def review_queue(previous, english, korean):
    old_meta, old = previous
    en_meta, en = english
    ko_meta, ko = korean
    if en_meta.get("language") != "en" or ko_meta.get("language") != "ko":
        raise ValueError("Expected an English export and a Korean export")
    if old_meta.get("language") != "en":
        raise ValueError("Previous reference must be English")
    game_build = en_meta.get("build_identifier")
    if not game_build or game_build == "unavailable" or game_build != ko_meta.get("build_identifier"):
        raise ValueError("Current English/Korean game builds differ or are unknown")
    # Current paired exports must use the same baseline/catalogue. Their observed
    # IDs may legitimately differ after navigating different game screens.
    for field in ("baseline_sha256", "catalogue_sha256", "catalogue_source_commit"):
        if en_meta.get(field) != ko_meta.get(field):
            raise ValueError("Current English/Korean metadata differs: " + field)
    for key, row in sorted(en.items()):
        if row["status"] != "found":
            continue
        before = old.get(key)
        if before and before["status"] == "found" and before["raw"] == row["raw"]:
            continue
        ko_row = ko.get(key)
        yield {
            "key": key,
            "reason": "changed_english" if before and before["status"] == "found" else "newly_available_english",
            "current_en": row["raw"],
            "previous_en": before.get("raw") if before else None,
            "builtin_ko": ko_row.get("raw") if ko_row and ko_row["status"] == "found" else None,
            "ko_status": ko_row["status"] if ko_row else "not_in_korean_export",
            "game_build": game_build,
            "korean_resource_fallback_possible": ko_meta.get("language_fallback_may_apply", True),
            "decision": "pending_review",
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--old-en", type=Path, required=True)
    parser.add_argument("--en", type=Path, required=True)
    parser.add_argument("--ko", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    dumps = [read_dump(path) for path in (args.old_en, args.en, args.ko)]
    rows = list(review_queue(*dumps))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as file:
        for row in rows:
            file.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(json.dumps({"review_queue_entries": len(rows),
                      "current_en_ids": len(dumps[1][1]), "current_ko_ids": len(dumps[2][1]),
                      "queue_file": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
